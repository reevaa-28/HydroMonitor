# train_model.py
# PURPOSE: Train and SAVE the two regression models (Linear Regression and
# Random Forest) that predict power generation (MW) from sensor values.
# Run it alone with:  python train_model.py

import os
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_predict
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

import database
from sensor_simulator import ensure_dataset

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "models")
LINEAR_PATH = os.path.join(MODEL_DIR, "linear_model.pkl")
FOREST_PATH = os.path.join(MODEL_DIR, "random_forest_model.pkl")
CALIB_PATH = os.path.join(MODEL_DIR, "linear_residuals.pkl")   # small helper file for uncertainty

RANDOM_STATE = 42
FEATURE_COLUMNS = ["water_flow", "water_level", "hydraulic_head", "temperature",
                   "rainfall", "turbine_efficiency", "turbine_status"]
TARGET = "simulated_power"
MODEL_NAMES = ["Linear Regression", "Random Forest"]


def prepare_features(df):
    """Select the 7 feature columns and turn Running/Stopped into 1/0."""
    X = df[FEATURE_COLUMNS].copy()
    if not pd.api.types.is_numeric_dtype(X["turbine_status"]):
        X["turbine_status"] = (X["turbine_status"].astype(str) == "Running").astype(int)
    return X.astype(float)


def get_split(df=None):
    """The SAME 80:20 split every time (random_state fixed) -> same test rows for both models."""
    if df is None:
        df = ensure_dataset()
    X = prepare_features(df)
    y = df[TARGET].astype(float)
    return train_test_split(X, y, test_size=0.2, random_state=RANDOM_STATE)


def metrics_from_predictions(y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    mse = mean_squared_error(y_true, y_pred)
    span = float(np.max(y_true) - np.min(y_true))
    est = float(np.clip(100 * (1 - mae / span), 0, 100)) if span > 0 else 0.0
    return {"MAE": float(mae), "MSE": float(mse), "RMSE": float(np.sqrt(mse)),
            "R2": float(r2_score(y_true, y_pred)), "EstAccuracy": est}


def train_all():
    """Train both models, save them with Joblib, store metrics in SQLite."""
    os.makedirs(MODEL_DIR, exist_ok=True)
    X_train, X_test, y_train, y_test = get_split()

    linear = make_pipeline(StandardScaler(), LinearRegression())   # scale, then fit a line
    forest = RandomForestRegressor(n_estimators=150, min_samples_leaf=2,
                                   random_state=RANDOM_STATE, n_jobs=-1)
    linear.fit(X_train, y_train)
    forest.fit(X_train, y_train)
    joblib.dump(linear, LINEAR_PATH)
    joblib.dump(forest, FOREST_PATH)

    # Residuals of Linear Regression on HELD-OUT folds of the training data (5-fold cross validation).
    # Used later for the Linear Regression prediction interval.
    cv_pred = cross_val_predict(make_pipeline(StandardScaler(), LinearRegression()),
                                X_train, y_train, cv=5)
    residuals = (y_train.values - cv_pred)
    joblib.dump({"q05": float(np.quantile(residuals, 0.05)),
                 "q95": float(np.quantile(residuals, 0.95))}, CALIB_PATH)

    results = {}
    database.init_db()
    for name, model in [("Linear Regression", linear), ("Random Forest", forest)]:
        m = metrics_from_predictions(y_test.values, model.predict(X_test))
        results[name] = m
        database.save_metrics(name, m["MAE"], m["MSE"], m["RMSE"], m["R2"], m["EstAccuracy"])
    return results


def models_exist():
    return all(os.path.exists(p) for p in (LINEAR_PATH, FOREST_PATH, CALIB_PATH))


def ensure_models():
    if not models_exist():
        train_all()


def evaluate_models():
    """Calculate metrics from ACTUAL test predictions of the saved models."""
    ensure_models()
    _, X_test, _, y_test = get_split()
    linear, forest = joblib.load(LINEAR_PATH), joblib.load(FOREST_PATH)
    preds = {"Linear Regression": linear.predict(X_test), "Random Forest": forest.predict(X_test)}
    metrics = {n: metrics_from_predictions(y_test.values, p) for n, p in preds.items()}
    importance = dict(zip(FEATURE_COLUMNS, forest.feature_importances_))
    return {"metrics": metrics, "y_test": y_test.values, "predictions": preds,
            "importance": importance, "n_test": len(y_test)}


if __name__ == "__main__":
    res = train_all()
    for model_name, m in res.items():
        print(model_name, {k: round(v, 4) for k, v in m.items()})
    print("Models saved in the 'models' folder.")
