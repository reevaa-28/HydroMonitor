/* =====================================================================
   core.js  -  shared helpers for the whole front end
   - HM            : one global object that holds everything (no framework needed)
   - HM.get/post   : talk to the Flask API with fetch()
   - icons, small HTML "components" (kpi, badge, ...)
   - toast messages
   ===================================================================== */
const HM = {
  pages: {},            // every page registers itself here: HM.pages.dashboard = {...}
  live: { on: false, timer: null, busy: false },
  meta: null,           // /api/meta (labels, defaults ...) loaded once at start
  alertsOpen: 0,
};

/* ---------- talking to the server ---------- */
HM.api = async function (url, options = {}) {
  const opt = { headers: { 'Content-Type': 'application/json' }, ...options };
  if (opt.body && typeof opt.body !== 'string') opt.body = JSON.stringify(opt.body);
  let res;
  try { res = await fetch(url, opt); }
  catch (e) { throw new Error('Cannot reach the server. Is "python server.py" still running?'); }
  let data = null;
  try { data = await res.json(); } catch (e) { /* not JSON (e.g. a file) */ }
  if (!res.ok) throw new Error((data && data.error) || res.statusText);
  return data;
};
HM.get = (url) => HM.api(url);
HM.post = (url, body) => HM.api(url, { method: 'POST', body: body || {} });

/* ---------- tiny utilities ---------- */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
HM.fmt = (v, d = 1) => (v === null || v === undefined || isNaN(v)) ? '–' : Number(v).toFixed(d);
HM.esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
HM.tshort = (ts) => (ts || '').slice(5, 16);                       // "2026-11-20 10:30:00" -> "11-20 10:30"
HM.title = (s) => s.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
HM.tone = (score) => score >= 70 ? 'good' : score >= 50 ? 'warn' : 'bad';

/* ---------- icons (simple line icons drawn with SVG paths) ---------- */
const ICONS = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
  dash: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
  twin: '<path d="M3 20h18"/><path d="M5 20V9l7-5 7 5v11"/><circle cx="12" cy="14" r="3"/>',
  sensor: '<path d="M2 12h4l3-8 4 16 3-8h6"/>',
  bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  forecast: '<path d="M3 17l6-6 4 4 8-9"/><path d="M15 6h6v6"/>',
  heart: '<path d="M12 21s-8-5.2-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 5.8-8 11-8 11z"/>',
  scan: '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><path d="M7 12h10"/>',
  db: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
  drop: '<path d="M12 3c4 5 7 8 7 12a7 7 0 0 1-14 0c0-4 3-7 7-12z"/>',
  chart: '<path d="M4 20V4"/><path d="M4 20h16"/><rect x="7" y="11" width="3" height="6"/><rect x="12" y="7" width="3" height="10"/><rect x="17" y="13" width="3" height="4"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10 21a2 2 0 0 0 4 0"/>',
  file: '<path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h6"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>',
  moon: '<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4 8.5 8.5 0 1 0 20 14.5z"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  temp: '<path d="M14 14.8V5a2 2 0 0 0-4 0v9.8a4 4 0 1 0 4 0z"/>',
  rain: '<path d="M7 16a4 4 0 0 1-.5-8A5.5 5.5 0 0 1 17 9a3.5 3.5 0 0 1 0 7z"/><path d="M8 19l-1 2M12 19l-1 2M16 19l-1 2"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9L7 7M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
  play: '<path d="M7 4l13 8-13 8z"/>',
  alert: '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/>',
  check: '<path d="M4 12l5 5L20 6"/>',
  down: '<path d="M12 3v13M6 12l6 6 6-6M4 21h16"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
  code: '<path d="M8 7l-5 5 5 5M16 7l5 5-5 5"/>',
};
HM.icon = (name) => `<svg class="i" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ''}</svg>`;

/* ---------- small HTML "components" (functions that return HTML text) ---------- */
HM.kpi = ({ label, value, unit = '', sub = '', icon = 'bolt', tone = '' }) => `
  <div class="card kpi">
    <div class="ic ${tone}">${HM.icon(icon)}</div>
    <div style="min-width:0">
      <div class="l">${label}</div>
      <div class="v num">${value}${unit ? `<small>${unit}</small>` : ''}</div>
      <div class="s">${sub || '&nbsp;'}</div>
    </div>
  </div>`;
HM.badge = (text, tone = '') => `<span class="badge ${tone}">${HM.esc(text)}</span>`;
HM.chartCard = (id, title, sub = '', cls = '', extra = '') => `
  <div class="card"><div class="card-h"><div><h3>${title}</h3>${sub ? `<p>${sub}</p>` : ''}</div>${extra}</div>
  <div class="chart ${cls}" id="${id}"></div></div>`;
HM.note = (html, cls = '') => `<div class="note ${cls}">${html}</div>`;
HM.empty = (title, text, actions = true) => `
  <div class="card empty">
    <h3>${title}</h3><p>${text}</p>
    ${actions ? `<div class="row">
      <button class="btn btn-primary" data-act="gen1">${HM.icon('bolt')} Generate 1 reading</button>
      <button class="btn" data-act="gen24">${HM.icon('layers')} Add 24 demo readings</button></div>` : ''}
  </div>`;
HM.loading = (n = 4) => `<div class="grid g4">${Array(n).fill('<div class="skeleton"></div>').join('')}</div>`;

/* ---------- toast messages ---------- */
HM.toast = function (msg, type = '') {
  const t = document.createElement('div');
  t.className = 'toast ' + type;
  t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 300); }, 3200);
};
HM.error = (e) => HM.toast(e.message || String(e), 'bad');

/* ---------- button helper: show spinner while a promise runs ---------- */
HM.busy = async function (btn, fn) {
  if (btn) btn.classList.add('busy');
  try { return await fn(); }
  catch (e) { HM.error(e); }
  finally { if (btn) btn.classList.remove('busy'); }
};

/* ---------- actions used on many pages (generate readings) ---------- */
HM.generate = async function (kind) {
  const res = await HM.post('/api/sim/next', kind ? { kind } : {});
  HM.lastResult = res;                 // the anomaly page shows this
  HM.afterNewData(res);
  return res;
};
HM.generateMany = async function (n) {
  await HM.post('/api/sim/history', { n });
  HM.toast(`${n} demo readings added`, 'good');
  HM.afterNewData();
};
/* After any new reading: update the alert counter and let the current page refresh itself */
HM.afterNewData = function (res) {
  if (res && res.alerts && res.alerts.length) {
    const crit = res.alerts.some((a) => a.severity === 'Critical');
    HM.toast(`${res.alerts.length} new alert${res.alerts.length > 1 ? 's' : ''}: ${res.alerts[0].message.slice(0, 60)}…`, crit ? 'bad' : 'warn');
  }
  HM.refreshBadge();
  const p = HM.current;
  if (p && p.refresh) p.refresh();
};
HM.refreshBadge = async function () {
  try {
    const d = await HM.get('/api/dashboard');
    HM.alertsOpen = d.alerts_open;
    const el = $('#navAlertCount');
    if (el) { el.textContent = d.alerts_open; el.style.display = d.alerts_open ? '' : 'none'; }
  } catch (e) { /* ignore */ }
};

/* Buttons in empty states use data-act so we can wire them in one place */
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]');
  if (!b) return;
  if (b.dataset.act === 'gen1') HM.busy(b, () => HM.generate());
  if (b.dataset.act === 'gen24') HM.busy(b, () => HM.generateMany(24));
});

/* ---------- live simulation (top bar button) ---------- */
HM.setLive = function (on) {
  HM.live.on = on;
  $('#liveBtn').classList.toggle('on', on);
  $('#liveTxt').textContent = on ? 'Live simulation ON' : 'Start live simulation';
  clearInterval(HM.live.timer);
  if (on) {
    HM.toast('Live simulation started – a new reading every 3 seconds', 'good');
    HM.live.timer = setInterval(async () => {
      if (HM.live.busy || document.hidden) return;          // skip if the last one is still running
      HM.live.busy = true;
      try { await HM.generate(); } catch (e) { HM.error(e); HM.setLive(false); }
      HM.live.busy = false;
    }, 3000);
  }
};
