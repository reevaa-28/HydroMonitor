/* =====================================================================
   pages_data.js  -  Historical Data, Reservoir Analysis, Alert Monitoring, Reports
   ===================================================================== */

const isoDate = (d) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const daysAgo = (n) => isoDate(new Date(Date.now() - n * 86400000));

HM.download = async function (url, filename) {
  const res = await fetch(url);
  if (!res.ok) { let m = res.statusText; try { m = (await res.json()).error; } catch (e) { } throw new Error(m); }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(await res.blob()); a.download = filename; document.body.appendChild(a); a.click(); a.remove();
};

/* ============================ HISTORICAL DATA ============================ */
HM.pages.history = {
  title: 'Historical Data', sub: 'Readings stored permanently in SQLite',
  start: daysAgo(7), end: daysAgo(0), page: 0, param: 'simulated_power', rows: [],
  mount(view) {
    view.innerHTML = `<div class="card"><div class="row spread">
        <div class="row">
          <div class="field"><label>From</label><input type="date" id="hFrom" value="${this.start}"></div>
          <div class="field"><label>To</label><input type="date" id="hTo" value="${this.end}"></div>
          <button class="btn btn-primary" id="hGo" style="align-self:flex-end">Apply</button></div>
        <button class="btn" id="hCsv" style="align-self:flex-end">${HM.icon('down')} Download CSV</button></div></div>
      <div id="hBodyData" class="mt"></div>`;
    $('#hGo').onclick = () => { this.start = $('#hFrom').value; this.end = $('#hTo').value; this.page = 0; this.refresh(); };
    $('#hCsv').onclick = (e) => HM.busy(e.currentTarget, () => HM.download(`/api/report/csv?start=${this.start}&end=${this.end}`, `hydro_readings_${this.start}_${this.end}.csv`));
  },
  async refresh() {
    const d = await HM.get(`/api/history?start=${this.start}&end=${this.end}`), el = $('#hBodyData'); if (!el) return;
    this.rows = d.readings;
    if (!this.rows.length) { el.innerHTML = HM.empty('No readings in this date range', 'Change the dates or generate new readings.'); return; }
    if (!$('#hParam')) {
      el.innerHTML = `<div class="card"><div class="card-h"><div><h3 id="hCount"></h3></div>
          <div class="field" style="min-width:210px"><select id="hParam">${['simulated_power', 'water_flow', 'water_level', 'hydraulic_head', 'temperature', 'rainfall', 'turbine_efficiency'].map((p) => `<option value="${p}" ${p === this.param ? 'selected' : ''}>${HM.title(p)}</option>`).join('')}</select></div></div>
          <div class="chart tall" id="hChart"></div></div>
        <div class="card mt"><div class="table-wrap" id="hTable"></div><div class="pager" id="hPager"></div></div>`;
      $('#hParam').onchange = (e) => { this.param = e.target.value; this.chart(); };
    }
    $('#hCount').textContent = `${this.rows.length} readings found`;
    this.chart(); this.table();
  },
  chart() { HM.trend('#hChart', this.rows, this.param, '', 0); },
  table() {
    const desc = this.rows.slice().reverse(), per = 12, pages = Math.ceil(desc.length / per);
    this.page = Math.min(this.page, pages - 1);
    const part = desc.slice(this.page * per, this.page * per + per);
    $('#hTable').innerHTML = `<table><thead><tr><th>ID</th><th>Time</th><th>Flow</th><th>Level</th><th>Head</th><th>Temp</th><th>Rain</th><th>Eff %</th><th>Status</th><th>MW</th></tr></thead><tbody>` +
      part.map((r) => `<tr><td>${r.id}</td><td>${r.timestamp}</td><td class="num">${HM.fmt(r.water_flow)}</td><td class="num">${HM.fmt(r.water_level)}</td><td class="num">${HM.fmt(r.hydraulic_head)}</td><td class="num">${HM.fmt(r.temperature)}</td><td class="num">${HM.fmt(r.rainfall)}</td><td class="num">${HM.fmt(r.turbine_efficiency)}</td><td>${HM.badge(r.turbine_status, r.turbine_status === 'Running' ? 'good' : 'bad')}</td><td class="num"><b>${HM.fmt(r.simulated_power, 2)}</b></td></tr>`).join('') + '</tbody></table>';
    $('#hPager').innerHTML = `<button class="btn btn-sm" id="hPrev" ${this.page === 0 ? 'disabled' : ''}>‹ Prev</button><span>Page ${this.page + 1} of ${pages}</span><button class="btn btn-sm" id="hNext" ${this.page >= pages - 1 ? 'disabled' : ''}>Next ›</button>`;
    $('#hPrev').onclick = () => { this.page--; this.table(); };
    $('#hNext').onclick = () => { this.page++; this.table(); };
  },
};

/* ============================ RESERVOIR ANALYSIS ============================ */
HM.pages.reservoir = {
  title: 'Reservoir Analysis', sub: 'Water conditions and their relationship with power',
  source: 'Stored readings',
  mount(view) {
    view.innerHTML = `<div class="card"><div class="row"><span class="small muted">Data source</span>
      ${HM.segment('rvSrc', ['Stored readings', 'Training dataset (6000 rows)'], this.source)}</div></div><div id="rvBody" class="mt"></div>`;
    HM.onSegment('rvSrc', (v) => { this.source = v; this.refresh(); });
  },
  async refresh() {
    const d = await HM.get('/api/reservoir?source=' + (this.source.startsWith('Training') ? 'dataset' : 'stored')), el = $('#rvBody'); if (!el) return;
    if (!d.enough) { el.innerHTML = HM.empty('Need at least 5 readings', `Only ${d.rows} stored so far.`); return; }
    const rows = d.data, c = HM.palette().c;
    if (!$('#rv1')) {
      el.innerHTML = `<div class="grid g2">
          ${HM.chartCard('rv1', 'Water level trend', 'm')}${HM.chartCard('rv2', 'Water flow trend', 'm³/s')}
          ${HM.chartCard('rv3', 'Rainfall', 'mm per reading')}${HM.chartCard('rv4', 'Hydraulic head trend', 'm')}</div>
        <h3 style="margin:24px 0 12px">Relationship with power generation</h3>
        <div class="grid g3">${HM.chartCard('rs1', 'Water flow vs power', '', 'tall')}${HM.chartCard('rs2', 'Hydraulic head vs power', '', 'tall')}
          <div class="card"><div class="card-h"><div><h3>Correlation with power</h3><p>+1 = rise together, 0 = no linear relationship</p></div></div><div class="chart tall" id="rcorr"></div></div></div>`;
    }
    HM.trend('#rv1', rows, 'water_level', 'm', 0); HM.trend('#rv2', rows, 'water_flow', 'm³/s', 1);
    HM.trend('#rv3', rows, 'rainfall', 'mm', 1); HM.trend('#rv4', rows, 'hydraulic_head', 'm', 4);
    const sc = (k, color) => ({ xLabel: HM.title(k), yLabel: 'Simulated power (MW)', series: [{ name: 'Readings', points: rows.map((r) => [r[k], r.simulated_power]), color, r: 3 }] });
    HM.scatter($('#rs1'), sc('water_flow', c[0])); HM.scatter($('#rs2'), sc('hydraulic_head', c[4]));
    const cr = Object.entries(d.corr);
    HM.hbar($('#rcorr'), { labels: cr.map((x) => HM.title(x[0])), values: cr.map((x) => x[1]), colors: cr.map((x) => x[1] >= 0 ? c[1] : c[3]), format: (v) => v.toFixed(2) });
  },
};

/* ============================ ALERT MONITORING ============================ */
HM.pages.alerts = {
  title: 'Alert Monitoring', sub: 'Threshold-based alerts (academic demonstration thresholds)',
  showAck: false,
  mount(view) {
    view.innerHTML = `${HM.note('Thresholds are demonstration values, <b>not</b> certified plant safety limits. The 10 % predicted-vs-actual deviation check is only used when an independent actual power measurement exists; simulator power is not an independent measurement, so it is not applied here.')}
      <div class="grid g4 mt" id="alKpi" style="grid-template-columns:repeat(5,minmax(0,1fr))"></div>
      <details class="card mt" id="thBox"><summary>${HM.icon('gear')} Configure thresholds <span class="muted small">click to open</span></summary><div id="thBody"></div></details>
      <div class="card mt"><div class="card-h"><div><h3>Alerts</h3><p id="alCount"></p></div>
        <div class="row"><label class="row small muted" style="cursor:pointer"><input type="checkbox" id="alShow"> Show acknowledged</label>
        <button class="btn btn-sm" id="alAll">${HM.icon('check')} Acknowledge all</button></div></div><div id="alList"></div></div>`;
    $('#alShow').onchange = (e) => { this.showAck = e.target.checked; this.refresh(); };
    $('#alAll').onclick = (e) => HM.busy(e.currentTarget, async () => { await HM.post('/api/alerts/ack-all'); HM.toast('All alerts acknowledged', 'good'); HM.refreshBadge(); this.refresh(); });
    $('#thBox').addEventListener('toggle', (e) => { if (e.target.open) this.loadThresholds(); });
  },
  async refresh() {
    const d = await HM.get('/api/alerts'), el = $('#alList'); if (!el) return;
    $('#alKpi').innerHTML = HM.kpi({ label: 'Total alerts', value: d.total, icon: 'bell' }) + HM.kpi({ label: 'Warning', value: d.warning, icon: 'alert', tone: 'warn' }) +
      HM.kpi({ label: 'Critical', value: d.critical, icon: 'alert', tone: 'bad' }) + HM.kpi({ label: 'Acknowledged', value: d.acknowledged, icon: 'check', tone: 'good' }) +
      HM.kpi({ label: 'Unacknowledged', value: d.open, icon: 'bell', tone: d.open ? 'bad' : 'good' });
    const view = d.alerts.filter((a) => this.showAck || !a.acknowledged);
    $('#alCount').textContent = `Showing ${Math.min(view.length, 30)} of ${view.length}`;
    if (!d.total) { el.innerHTML = '<div class="empty"><h3>No alerts yet</h3><p>Generate readings or an abnormal test reading to create alerts.</p></div>'; return; }
    if (!view.length) { el.innerHTML = '<div class="empty"><h3>All clear 🎉</h3><p>Every alert has been acknowledged.</p></div>'; return; }
    el.innerHTML = view.slice(0, 30).map((a) => `<div class="alert-row ${a.acknowledged ? 'acked' : ''}"><div class="bar ${a.severity}"></div>
      <span class="small muted num">${a.timestamp}</span><span>${HM.badge(a.severity, a.severity === 'Critical' ? 'bad' : 'warn')} <b class="small">${HM.esc(a.parameter)}</b></span>
      <span class="small">${HM.esc(a.message)}</span>
      ${a.acknowledged ? '<span class="badge good">✔ Acknowledged</span>' : `<button class="btn btn-sm" data-ack="${a.id}">Acknowledge</button>`}</div>`).join('');
    $$('[data-ack]', el).forEach((b) => b.onclick = () => HM.busy(b, async () => { await HM.post(`/api/alerts/${b.dataset.ack}/ack`); HM.refreshBadge(); this.refresh(); }));
  },
  async loadThresholds() {
    const d = await HM.get('/api/thresholds'), el = $('#thBody');
    el.innerHTML = Object.entries(d.thresholds).map(([key, vals]) => {
      if (typeof vals !== 'object') return `<div class="field" style="margin:14px 0;max-width:340px"><label>Power deviation % (only with an independent actual measurement)</label><input type="number" data-th="${key}" value="${vals}"></div>`;
      return `<div style="margin-bottom:14px"><b>${d.names[key]}</b> <span class="muted small">(${d.units[key]})</span><div class="th-grid" style="margin-top:6px">
        ${Object.entries(vals).map(([k, v]) => `<div class="field"><label>${k.replace('_', ' ')}</label><input type="number" data-th="${key}.${k}" value="${v}"></div>`).join('')}</div></div>`;
    }).join('') + `<div class="row"><button class="btn btn-primary" id="thSave">Save thresholds</button><button class="btn" id="thReset">Reset to defaults</button></div>`;
    $('#thSave').onclick = (e) => HM.busy(e.currentTarget, async () => {
      const out = {};
      $$('[data-th]', el).forEach((i) => { const [k, s] = i.dataset.th.split('.'); if (s) (out[k] = out[k] || {})[s] = +i.value; else out[k] = +i.value; });
      await HM.post('/api/thresholds', { thresholds: out }); HM.toast('Thresholds saved – new readings use them', 'good');
    });
    $('#thReset').onclick = () => HM.busy($('#thReset'), async () => { await HM.api('/api/thresholds', { method: 'DELETE' }); HM.toast('Thresholds reset', 'good'); this.loadThresholds(); });
  },
};

/* ============================ REPORTS ============================ */
HM.pages.reports = {
  title: 'Reports', sub: 'Generate a PDF report and download CSV data',
  start: daysAgo(7), end: daysAgo(0),
  mount(view) {
    view.innerHTML = `<div class="grid g21"><div class="card"><div class="card-h"><div><h3>1. Choose a date range</h3></div></div>
        <div class="row"><div class="field"><label>From</label><input type="date" id="rpFrom" value="${this.start}"></div>
          <div class="field"><label>To</label><input type="date" id="rpTo" value="${this.end}"></div></div>
        <div class="grid g3 mt" id="rpSummary"></div>
        <div class="card-h" style="margin-top:22px"><h3>2. Download</h3></div>
        <div class="row"><button class="btn btn-primary btn-lg" id="rpPdf">${HM.icon('file')} Generate PDF report</button>
          <button class="btn btn-lg" id="rpCsv">${HM.icon('down')} Download CSV</button></div></div>
      <div class="card"><div class="card-h"><h3>What is inside the PDF?</h3></div>
        <ol class="muted" style="padding-left:18px;margin:0;line-height:1.9"><li>Sensor readings summary</li><li>Power predictions</li><li>Model comparison</li><li>Anomaly summary</li><li>Turbine health summary</li><li>Alerts</li><li>Historical charts</li></ol>
        <p class="small muted" style="margin-top:12px">A copy of every PDF is also saved in the <code>reports</code> folder of the project.</p></div></div>`;
    const read = () => { this.start = $('#rpFrom').value; this.end = $('#rpTo').value; };
    $('#rpFrom').onchange = $('#rpTo').onchange = () => { read(); this.refresh(); };
    $('#rpPdf').onclick = (e) => HM.busy(e.currentTarget, async () => { read(); await HM.download(`/api/report/pdf?start=${this.start}&end=${this.end}`, `hydromonitor_report_${this.start}_${this.end}.pdf`); HM.toast('PDF report created', 'good'); });
    $('#rpCsv').onclick = (e) => HM.busy(e.currentTarget, async () => { read(); await HM.download(`/api/report/csv?start=${this.start}&end=${this.end}`, `hydromonitor_data_${this.start}_${this.end}.csv`); });
  },
  async refresh() {
    if (this.start > this.end) { $('#rpSummary').innerHTML = '<div class="badge bad" style="grid-column:1/-1">The start date must be before the end date.</div>'; return; }
    const d = await HM.get(`/api/report/summary?start=${this.start}&end=${this.end}`);
    $('#rpSummary').innerHTML = [['Readings', d.readings, 'db'], ['Predictions', d.predictions, 'bolt'], ['Alerts', d.alerts, 'bell']]
      .map((x) => HM.kpi({ label: x[0], value: x[1], icon: x[2] })).join('');
  },
};
