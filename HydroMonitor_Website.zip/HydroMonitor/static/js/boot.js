/* =====================================================================
   boot.js  -  starts the app: sidebar, hash router (#/dashboard), theme, live button
   ===================================================================== */
(function () {
  const NAV = [
    ['Overview', [['home', 'Home', 'home'], ['dashboard', 'Dashboard', 'dash'], ['twin', 'Digital Twin', 'twin'], ['sensors', 'Sensor Monitoring', 'sensor']]],
    ['Machine learning', [['prediction', 'Power Prediction', 'bolt'], ['forecast', 'Future Forecast', 'forecast'], ['health', 'Turbine Health', 'heart'],
                          ['anomaly', 'Anomaly Detection', 'scan'], ['confidence', 'Prediction Confidence', 'target'], ['models', 'Model Comparison', 'chart']]],
    ['Data & operations', [['history', 'Historical Data', 'db'], ['reservoir', 'Reservoir Analysis', 'drop'], ['alerts', 'Alert Monitoring', 'bell'], ['reports', 'Reports', 'file']]],
  ];

  /* ---------- sidebar ---------- */
  $('#nav').innerHTML = NAV.map(([group, items]) => `<div class="nav-group">${group}</div>` +
    items.map(([key, label, icon]) => `<a href="#/${key}" data-key="${key}">${HM.icon(icon)}<span>${label}</span>${key === 'alerts' ? '<span class="count" id="navAlertCount" style="display:none">0</span>' : ''}</a>`).join('')).join('');
  $('#brandLogo').innerHTML = HM.icon('drop').replace('class="i"', 'class="i" style="width:22px;height:22px"');
  $('#menuBtn').innerHTML = HM.icon('menu');

  /* ---------- theme (light / dark) ---------- */
  function setTheme(t) {
    document.documentElement.dataset.theme = t;
    try { localStorage.setItem('hm-theme', t); } catch (e) { }
    $('#themeBtn').innerHTML = HM.icon(t === 'dark' ? 'sun' : 'moon');
    HM.redrawCharts();
  }
  setTheme(document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light');
  $('#themeBtn').onclick = () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');

  /* ---------- mobile menu ---------- */
  const side = $('#sidebar'), scrim = $('#scrim') || document.body.appendChild(Object.assign(document.createElement('div'), { id: 'scrim' }));
  const closeMenu = () => { side.classList.remove('open'); scrim.classList.remove('show'); };
  $('#menuBtn').onclick = () => { side.classList.add('open'); scrim.classList.add('show'); };
  scrim.onclick = closeMenu;

  $('#liveBtn').onclick = () => HM.setLive(!HM.live.on);

  /* ---------- router ---------- */
  let token = 0;                                   // protects against slow pages finishing late
  async function route() {
    const key = (location.hash.replace(/^#\//, '') || 'home').split('?')[0];
    const page = HM.pages[key] || HM.pages.home;
    const my = ++token;
    HM.current = page;
    closeMenu();
    $$('#nav a').forEach((a) => a.classList.toggle('active', a.dataset.key === key));
    $('#pageTitle').textContent = page.title; $('#pageSub').textContent = page.sub;
    document.title = page.title + ' · HydroMonitor';
    const view = $('#view');
    view.innerHTML = '';
    window.scrollTo(0, 0);
    try {
      await page.mount(view);
      if (my === token && page.refresh) await page.refresh();
    } catch (e) {
      if (my === token) view.innerHTML = `<div class="card empty"><h3>Something went wrong</h3><p>${HM.esc(e.message)}</p></div>`;
    }
  }
  window.addEventListener('hashchange', route);

  /* ---------- start ---------- */
  (async function start() {
    try {
      HM.meta = await HM.get('/api/meta');
      HM.refreshBadge();
      route();
    } catch (e) {
      $('#view').innerHTML = `<div class="card empty"><h3>Cannot reach the server</h3><p>${HM.esc(e.message)}</p></div>`;
    }
  })();
})();
