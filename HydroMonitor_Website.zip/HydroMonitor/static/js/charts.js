/* =====================================================================
   charts.js  -  our own small chart library (HTML canvas, no internet needed)
   Usage:   HM.line(element, { labels:[...], series:[{name, data:[...], color}] })
            HM.bar(element, ...)   HM.hbar(element, ...)   HM.scatter(element, ...)
   Every chart redraws itself when the window is resized, the mouse moves
   (tooltip) or the theme changes. Calling the same function again on the same
   element simply UPDATES that chart (this is how live data refreshes).
   ===================================================================== */
(function () {
  const all = new Set();                       // every chart on screen

  /* colours come from CSS variables so charts follow the light/dark theme */
  function palette() {
    const s = getComputedStyle(document.documentElement);
    const v = (n) => s.getPropertyValue(n).trim();
    return { text: v('--text-2'), faint: v('--text-3'), grid: v('--grid'), surface: v('--surface'),
             c: [v('--c1'), v('--c2'), v('--c3'), v('--c4'), v('--c5')], primary: v('--primary') };
  }

  /* "nice" axis numbers: turns 0.37..93.2 into 0,20,40,60,80,100 */
  function niceTicks(lo, hi, count = 5) {
    if (lo === hi) { lo -= 1; hi += 1; }
    const span = hi - lo, raw = span / count;
    const mag = Math.pow(10, Math.floor(Math.log10(raw)));
    const f = raw / mag, step = (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * mag;
    const out = [];
    for (let v = Math.floor(lo / step) * step; v <= Math.ceil(hi / step) * step + 1e-9; v += step) out.push(+v.toFixed(10));
    return out;
  }
  const extent = (arr) => arr.length ? [Math.min(...arr), Math.max(...arr)] : [0, 1];
  const nf = (v) => Math.abs(v) >= 1000 ? v.toFixed(0) : Math.abs(v) >= 100 ? v.toFixed(0) : Math.abs(v) >= 10 ? v.toFixed(1) : v.toFixed(2).replace(/\.?0+$/, '');

  /* ---------- create / reuse the canvas inside the element ---------- */
  function mount(el, kind, cfg) {
    if (!el) return;
    if (!el._hm) {
      const canvas = document.createElement('canvas');
      const tip = document.createElement('div'); tip.className = 'tip';
      el.innerHTML = ''; el.append(canvas, tip);
      const st = { el, canvas, tip, hover: null };
      el._hm = st; all.add(st);
      new ResizeObserver(() => draw(st)).observe(el);
      canvas.addEventListener('mousemove', (e) => {
        const r = canvas.getBoundingClientRect();
        st.hover = { x: e.clientX - r.left, y: e.clientY - r.top }; draw(st);
      });
      canvas.addEventListener('mouseleave', () => { st.hover = null; draw(st); });
    }
    el._hm.kind = kind; el._hm.cfg = cfg;
    draw(el._hm);
  }

  function draw(st) {
    const { el, canvas, kind, cfg } = st;
    if (!cfg || !el.isConnected) return;
    const w = el.clientWidth, h = el.clientHeight;
    if (!w || !h) return;
    const dpr = window.devicePixelRatio || 1;
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    ctx.font = '12px "Segoe UI", system-ui, sans-serif';
    st.tip.style.display = 'none';
    const col = palette();
    ({ line: drawLine, bar: drawBar, hbar: drawHBar, scatter: drawScatter })[kind](ctx, w, h, cfg, st, col);
  }

  function noData(ctx, w, h, col, msg = 'No data yet') {
    ctx.fillStyle = col.faint; ctx.textAlign = 'center'; ctx.fillText(msg, w / 2, h / 2); ctx.textAlign = 'left';
  }

  function showTip(st, html, x, y) {
    const t = st.tip; t.innerHTML = html; t.style.display = 'block';
    const w = t.offsetWidth, W = st.el.clientWidth;
    t.style.left = Math.max(4, Math.min(W - w - 4, x + 14)) + 'px';
    t.style.top = Math.max(2, y - 10) + 'px';
  }

  /* shared: grid + y axis labels. returns scale helpers */
  function yAxis(ctx, pad, w, h, lo, hi, col, label) {
    const ticks = niceTicks(lo, hi, 5);
    lo = ticks[0]; hi = ticks[ticks.length - 1];
    const y = (v) => pad.t + (hi - v) / (hi - lo) * (h - pad.t - pad.b);
    ctx.strokeStyle = col.grid; ctx.lineWidth = 1; ctx.fillStyle = col.faint; ctx.textAlign = 'right';
    ticks.forEach((t) => {
      const yy = Math.round(y(t)) + .5;
      ctx.beginPath(); ctx.moveTo(pad.l, yy); ctx.lineTo(w - pad.r, yy); ctx.stroke();
      ctx.fillText(nf(t), pad.l - 8, yy + 4);
    });
    ctx.textAlign = 'left';
    if (label) { ctx.save(); ctx.translate(12, pad.t + (h - pad.t - pad.b) / 2); ctx.rotate(-Math.PI / 2);
      ctx.textAlign = 'center'; ctx.fillText(label, 0, 0); ctx.restore(); }
    return { y, lo, hi };
  }

  /* ================= LINE chart (also bands + dots) ================= */
  function drawLine(ctx, w, h, cfg, st, col) {
    const n = cfg.labels.length;
    if (!n) return noData(ctx, w, h, col);
    const pad = { l: cfg.yLabel ? 56 : 46, r: 14, t: 12, b: cfg.xLabel ? 46 : 28 };
    let vals = [];
    cfg.series.forEach((s) => vals.push(...s.data.filter((v) => v != null)));
    (cfg.bands || []).forEach((b) => vals.push(...b.lower, ...b.upper));
    let [lo, hi] = extent(vals);
    if (cfg.yMin != null) lo = cfg.yMin;
    if (cfg.yMax != null) hi = cfg.yMax;
    if (cfg.yMin == null && lo > 0 && lo < (hi - lo) * 1.2) lo = 0;      // start at zero if it looks natural
    const { y } = yAxis(ctx, pad, w, h, lo, hi, col, cfg.yLabel);
    const pw = w - pad.l - pad.r;
    const x = (i) => pad.l + (n === 1 ? pw / 2 : i * pw / (n - 1));

    // x labels (about 6)
    ctx.fillStyle = col.faint; ctx.textAlign = 'center';
    const step = Math.max(1, Math.ceil(n / Math.max(2, Math.floor(pw / 95))));
    for (let i = 0; i < n; i += step) {
      const lbl = String(cfg.labels[i]);
      ctx.fillText(lbl, Math.min(w - 24, Math.max(pad.l + 10, x(i))), h - pad.b + 18);
    }
    if (cfg.xLabel) ctx.fillText(cfg.xLabel, pad.l + pw / 2, h - 6);
    ctx.textAlign = 'left';

    // bands (uncertainty ranges)
    (cfg.bands || []).forEach((b) => {
      ctx.beginPath();
      b.upper.forEach((v, i) => i ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v)));
      for (let i = n - 1; i >= 0; i--) ctx.lineTo(x(i), y(b.lower[i]));
      ctx.closePath(); ctx.fillStyle = (b.color || col.c[0]) + '33'; ctx.fill();
    });

    // series
    cfg.series.forEach((s, k) => {
      const color = s.color || col.c[k % 5];
      if (s.dots) {
        ctx.fillStyle = color;
        s.data.forEach((v, i) => { if (v == null) return; ctx.beginPath(); ctx.arc(x(i), y(v), s.r || 2.6, 0, 7); ctx.fill(); });
        return;
      }
      ctx.beginPath();
      let started = false;
      s.data.forEach((v, i) => { if (v == null) return; started ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v)); started = true; });
      if (cfg.area && k === 0) {
        ctx.save();
        const g = ctx.createLinearGradient(0, pad.t, 0, h - pad.b);
        g.addColorStop(0, color + '55'); g.addColorStop(1, color + '00');
        ctx.lineTo(x(n - 1), y(Math.max(0, cfg.yMin ?? 0))); ctx.lineTo(x(0), y(Math.max(0, cfg.yMin ?? 0)));
        ctx.closePath(); ctx.fillStyle = g; ctx.fill(); ctx.restore();
        ctx.beginPath(); started = false;
        s.data.forEach((v, i) => { if (v == null) return; started ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v)); started = true; });
      }
      ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.lineJoin = 'round';
      if (s.dash) ctx.setLineDash([6, 5]);
      ctx.stroke(); ctx.setLineDash([]);
      if (cfg.markers) { ctx.fillStyle = color; s.data.forEach((v, i) => { ctx.beginPath(); ctx.arc(x(i), y(v), 3.5, 0, 7); ctx.fill(); }); }
    });

    // horizontal reference line
    if (cfg.hline != null) {
      ctx.strokeStyle = col.c[3]; ctx.setLineDash([5, 5]); ctx.beginPath();
      ctx.moveTo(pad.l, y(cfg.hline)); ctx.lineTo(w - pad.r, y(cfg.hline)); ctx.stroke(); ctx.setLineDash([]);
      if (cfg.hlineLabel) { ctx.fillStyle = col.c[3]; ctx.fillText(cfg.hlineLabel, pad.l + 6, y(cfg.hline) - 5); }
    }

    // hover: vertical line + tooltip
    if (st.hover && st.hover.x >= pad.l && st.hover.x <= w - pad.r) {
      const i = Math.max(0, Math.min(n - 1, Math.round((st.hover.x - pad.l) / pw * (n - 1))));
      ctx.strokeStyle = col.faint; ctx.lineWidth = 1; ctx.beginPath();
      ctx.moveTo(x(i) + .5, pad.t); ctx.lineTo(x(i) + .5, h - pad.b); ctx.stroke();
      let html = `<b>${HM.esc(cfg.labels[i])}</b>`;
      cfg.series.forEach((s, k) => {
        const v = s.data[i]; if (v == null) return;
        const color = s.color || col.c[k % 5];
        ctx.fillStyle = color; ctx.beginPath(); ctx.arc(x(i), y(v), 4.5, 0, 7); ctx.fill();
        html += `<br><span style="color:${color}">●</span> ${HM.esc(s.name || '')} ${nf(v)}${cfg.unit ? ' ' + cfg.unit : ''}`;
      });
      (cfg.bands || []).forEach((b) => { html += `<br>range ${nf(b.lower[i])} – ${nf(b.upper[i])}`; });
      showTip(st, html, x(i), st.hover.y);
    }
  }

  /* ================= vertical BAR chart ================= */
  function drawBar(ctx, w, h, cfg, st, col) {
    const n = cfg.labels.length;
    if (!n) return noData(ctx, w, h, col);
    const pad = { l: 46, r: 12, t: 22, b: 28 };
    const { y } = yAxis(ctx, pad, w, h, Math.min(0, ...cfg.values), Math.max(...cfg.values) * 1.08, col, cfg.yLabel);
    const slot = (w - pad.l - pad.r) / n, bw = Math.min(54, slot * 0.6);
    cfg.values.forEach((v, i) => {
      const cx = pad.l + slot * (i + .5), color = (cfg.colors && cfg.colors[i]) || col.c[i % 5];
      ctx.fillStyle = color;
      const top = y(v), base = y(0);
      roundRect(ctx, cx - bw / 2, top, bw, base - top, 6); ctx.fill();
      ctx.fillStyle = col.text; ctx.textAlign = 'center';
      ctx.fillText(cfg.format ? cfg.format(v) : nf(v), cx, top - 6);
      ctx.fillStyle = col.faint; ctx.fillText(cfg.labels[i], cx, h - 9);
    });
    ctx.textAlign = 'left';
  }

  /* ================= horizontal BAR chart ================= */
  function drawHBar(ctx, w, h, cfg, st, col) {
    const n = cfg.labels.length;
    if (!n) return noData(ctx, w, h, col);
    const lw = Math.max(...cfg.labels.map((l) => ctx.measureText(l).width)) + 14;
    const pad = { l: lw, r: 56, t: 6, b: 6 };
    const mx = Math.max(...cfg.values.map(Math.abs), 1e-9);
    const slot = (h - pad.t - pad.b) / n, bh = Math.min(26, slot * 0.62);
    cfg.values.forEach((v, i) => {
      const cy = pad.t + slot * (i + .5), len = Math.abs(v) / mx * (w - pad.l - pad.r);
      ctx.fillStyle = col.text; ctx.textAlign = 'right'; ctx.fillText(cfg.labels[i], pad.l - 10, cy + 4);
      ctx.fillStyle = (cfg.colors && cfg.colors[i]) || cfg.color || col.c[0];
      roundRect(ctx, pad.l, cy - bh / 2, Math.max(len, 2), bh, 5); ctx.fill();
      ctx.fillStyle = col.text; ctx.textAlign = 'left';
      ctx.fillText(cfg.format ? cfg.format(v) : nf(v), pad.l + len + 8, cy + 4);
    });
    ctx.textAlign = 'left';
  }

  /* ================= SCATTER chart ================= */
  function drawScatter(ctx, w, h, cfg, st, col) {
    const pts = cfg.series.flatMap((s) => s.points);
    if (!pts.length) return noData(ctx, w, h, col);
    const pad = { l: 56, r: 14, t: 12, b: 38 };
    let [xl, xh] = extent(pts.map((p) => p[0])), [yl, yh] = extent(pts.map((p) => p[1]));
    if (cfg.diag) { xl = yl = Math.min(xl, yl); xh = yh = Math.max(xh, yh); }
    const { y, lo: ylo, hi: yhi } = yAxis(ctx, pad, w, h, yl, yh, col, cfg.yLabel);
    const xt = niceTicks(xl, xh, 6), xlo = xt[0], xhi = xt[xt.length - 1];
    const pw = w - pad.l - pad.r;
    const x = (v) => pad.l + (v - xlo) / (xhi - xlo) * pw;
    ctx.fillStyle = col.faint; ctx.textAlign = 'center';
    xt.forEach((t) => ctx.fillText(nf(t), x(t), h - 20));
    if (cfg.xLabel) ctx.fillText(cfg.xLabel, pad.l + pw / 2, h - 4);
    ctx.textAlign = 'left';
    if (cfg.diag) {
      ctx.strokeStyle = col.c[3]; ctx.setLineDash([6, 5]); ctx.beginPath();
      ctx.moveTo(x(xlo), y(Math.max(xlo, ylo))); ctx.lineTo(x(xhi), y(Math.min(xhi, yhi))); ctx.stroke(); ctx.setLineDash([]);
    }
    if (cfg.hline != null) {
      ctx.strokeStyle = col.c[3]; ctx.setLineDash([6, 5]); ctx.beginPath();
      ctx.moveTo(pad.l, y(cfg.hline)); ctx.lineTo(w - pad.r, y(cfg.hline)); ctx.stroke(); ctx.setLineDash([]);
    }
    let best = null;
    cfg.series.forEach((s, k) => {
      const color = s.color || col.c[k % 5];
      ctx.fillStyle = color + 'aa';
      s.points.forEach((p) => {
        const px = x(p[0]), py = y(p[1]);
        ctx.beginPath(); ctx.arc(px, py, s.r || 3, 0, 7); ctx.fill();
        if (st.hover) { const d = Math.hypot(px - st.hover.x, py - st.hover.y); if (d < 14 && (!best || d < best.d)) best = { d, px, py, p, s, color }; }
      });
    });
    if (best) {
      ctx.strokeStyle = best.color; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(best.px, best.py, 6, 0, 7); ctx.stroke();
      showTip(st, `<b>${HM.esc(best.s.name || '')}</b><br>x: ${nf(best.p[0])}<br>y: ${nf(best.p[1])}`, best.px, best.py);
    }
  }

  function roundRect(ctx, x, y, w, h, r) {
    r = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, 0); ctx.arcTo(x, y + h, x, y, 0); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }

  /* ---------- public functions ---------- */
  HM.line = (el, cfg) => mount(el, 'line', cfg);
  HM.bar = (el, cfg) => mount(el, 'bar', cfg);
  HM.hbar = (el, cfg) => mount(el, 'hbar', cfg);
  HM.scatter = (el, cfg) => mount(el, 'scatter', cfg);
  HM.redrawCharts = () => { all.forEach((st) => { if (!st.el.isConnected) all.delete(st); else draw(st); }); };

  /* A line chart straight from the readings table:  HM.trend('#id', rows, 'water_flow', 'm³/s') */
  HM.trend = (el, rows, key, unit, colorIdx = 0, area = true) => {
    const color = palette().c[colorIdx];
    HM.line(typeof el === 'string' ? $(el) : el, {
      labels: rows.map((r) => HM.tshort(r.timestamp)),
      series: [{ name: HM.title(key), data: rows.map((r) => r[key]), color }], unit, area,
    });
  };

  /* ---------- small SVG helpers (gauge + sparkline) ---------- */
  HM.spark = (values, color = 'var(--primary)') => {
    if (!values || values.length < 2) return '';
    const [lo, hi] = extent(values), span = (hi - lo) || 1;
    const pts = values.map((v, i) => `${(i / (values.length - 1) * 100).toFixed(1)},${(30 - (v - lo) / span * 26 - 2).toFixed(1)}`).join(' ');
    return `<svg class="spark" viewBox="0 0 100 30" preserveAspectRatio="none"><polyline points="${pts}" fill="none" stroke="${color}" stroke-width="2" vector-effect="non-scaling-stroke" stroke-linejoin="round"/></svg>`;
  };

  HM.gauge = (score, label = '') => {
    const tone = score >= 70 ? 'var(--good)' : score >= 50 ? 'var(--warn)' : 'var(--bad)';
    const r = 90, c = Math.PI * r, off = c * (1 - Math.max(0, Math.min(100, score)) / 100);
    return `<div class="gauge"><svg viewBox="0 0 220 125">
      <path d="M20 110 A90 90 0 0 1 200 110" fill="none" stroke="var(--surface-2)" stroke-width="18" stroke-linecap="round"/>
      <path d="M20 110 A90 90 0 0 1 200 110" fill="none" stroke="${tone}" stroke-width="18" stroke-linecap="round"
            stroke-dasharray="${c}" stroke-dashoffset="${off}" style="transition:stroke-dashoffset .8s"/></svg>
      <div class="val"><b class="num">${HM.fmt(score, 0)}</b><span>${label}</span></div></div>`;
  };

  /* range bar (prediction with lower / upper estimate), plain HTML */
  HM.rangeBar = (lower, pred, upper) => {
    const lo = Math.max(0, lower - (upper - lower) * 0.6 - 0.5), hi = upper + (upper - lower) * 0.6 + 0.5;
    const p = (v) => ((v - lo) / (hi - lo) * 100).toFixed(2) + '%';
    return `<div class="range-bar"><div class="track"></div>
      <div class="span" style="left:${p(lower)};width:calc(${p(upper)} - ${p(lower)})"></div>
      <div class="pt" style="left:${p(pred)}"></div>
      <div class="lbl" style="left:${p(lower)}">${HM.fmt(lower, 2)}</div>
      <div class="lbl b" style="left:${p(pred)}"><b>${HM.fmt(pred, 2)} MW</b></div>
      <div class="lbl" style="left:${p(upper)}">${HM.fmt(upper, 2)}</div></div>`;
  };

  HM.palette = palette;
})();
