/* =====================================================================
   twin.js  -  the animated Digital Twin (an SVG picture of the plant)
   HM.twin(container)  builds the picture once and returns { update(reading, predictedMW) }.
   update() changes: reservoir water level, speed of water in the pipe,
   turbine spinning (stops when "Stopped"), generator glow, power lines.
   ===================================================================== */
HM.twin = function (container) {
  container.innerHTML = `
  <svg viewBox="0 0 1000 500" role="img" aria-label="Hydropower plant digital twin">
    <defs>
      <linearGradient id="tSky" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="var(--twin-sky-1)"/><stop offset="1" stop-color="var(--twin-sky-2)"/>
      </linearGradient>
      <linearGradient id="tWater" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="var(--twin-water)"/><stop offset="1" stop-color="var(--twin-water-2)"/>
      </linearGradient>
      <clipPath id="tReservoirClip"><rect x="14" y="110" width="296" height="330" rx="6"/></clipPath>
    </defs>

    <rect width="1000" height="500" fill="url(#tSky)"/>
    <!-- hill + reservoir basin -->
    <path d="M0 160 L110 95 L250 120 L312 100 L312 450 L0 450Z" fill="var(--twin-hill)"/>
    <rect x="14" y="110" width="296" height="330" rx="6" fill="var(--twin-sky-1)" opacity=".55"/>
    <g clip-path="url(#tReservoirClip)">
      <rect id="twWater" x="14" y="300" width="296" height="200" fill="url(#tWater)"/>
      <g id="twWave" class="t-wave"><path id="twWavePath" fill="var(--twin-water)" opacity=".9"/></g>
    </g>
    <text id="twLevel" x="162" y="330" text-anchor="middle" font-size="15" font-weight="700" fill="#fff"></text>
    <text x="162" y="468" text-anchor="middle" font-size="13" font-weight="600" fill="var(--twin-text)" opacity=".7">RESERVOIR</text>

    <!-- dam -->
    <path d="M310 100 L372 100 L392 450 L310 450Z" fill="var(--twin-dam)"/>
    <path d="M322 130h40M326 180h44M330 230h48M334 280h52M338 330h56M342 380h60" stroke="rgba(255,255,255,.18)" stroke-width="2"/>
    <text x="352" y="90" text-anchor="middle" font-size="13" font-weight="600" fill="var(--twin-text)" opacity=".7">DAM</text>

    <!-- power house -->
    <rect x="590" y="318" width="300" height="132" rx="8" fill="var(--twin-house)" stroke="var(--twin-dam)" stroke-width="2"/>
    <path d="M580 322 L740 268 L900 322Z" fill="var(--twin-dam)"/>
    <text x="740" y="302" text-anchor="middle" font-size="12" font-weight="700" fill="#fff" letter-spacing="2">POWER HOUSE</text>

    <!-- penstock (pipe): dark outer pipe + animated water inside -->
    <path id="twPipe" d="M392 330 C 480 330 540 400 650 392" fill="none" stroke="var(--twin-pipe)" stroke-width="26" stroke-linecap="round"/>
    <path id="twPipeWater" d="M392 330 C 480 330 540 400 650 392" fill="none" stroke="var(--twin-water)" stroke-width="14" stroke-linecap="round" class="t-flow"/>
    <text x="495" y="438" text-anchor="middle" font-size="13" font-weight="600" fill="var(--twin-text)" opacity=".7">PENSTOCK</text>

    <!-- turbine -->
    <g transform="translate(700 392)">
      <circle r="46" fill="var(--surface)" stroke-width="5" id="twTurbRing" stroke="var(--good)"/>
      <g id="twBlades" class="t-blades">
        <circle r="40" fill="transparent"/>
        <g stroke-width="7" stroke-linecap="round" id="twBladeLines" stroke="var(--good)">
          <path d="M0 0 L0 -36"/><path d="M0 0 L31 -18"/><path d="M0 0 L31 18"/>
          <path d="M0 0 L0 36"/><path d="M0 0 L-31 18"/><path d="M0 0 L-31 -18"/>
        </g>
      </g>
      <circle r="9" fill="var(--twin-dam)"/>
    </g>
    <text x="700" y="468" text-anchor="middle" font-size="13" font-weight="700" fill="var(--twin-text)">TURBINE</text>
    <text id="twStatus" x="700" y="486" text-anchor="middle" font-size="12" font-weight="700" fill="var(--good)">RUNNING</text>

    <!-- shaft + generator -->
    <rect x="746" y="388" width="58" height="9" fill="var(--twin-pipe)"/>
    <rect id="twGen" x="804" y="352" width="70" height="80" rx="10" fill="var(--primary)" stroke="var(--twin-dam)" stroke-width="2"/>
    <text x="839" y="387" text-anchor="middle" font-size="22" fill="#fff" font-weight="700" id="twBolt">⚡</text>
    <text x="839" y="412" text-anchor="middle" font-size="11" fill="#fff" font-weight="700">GENERATOR</text>
    <circle id="twGlow" cx="839" cy="392" r="62" fill="var(--primary)" opacity=".18" class="t-glow"/>

    <!-- tail race water -->
    <path d="M900 472 Q 925 464 950 472 T 1000 472 L1000 500 L900 500Z" fill="var(--twin-water)" opacity=".85"/>

    <!-- transmission tower + power line -->
    <path d="M892 380 Q 925 360 955 300" fill="none" stroke="var(--twin-text)" stroke-width="2.5" opacity=".8"/>
    <path id="twLine" d="M892 380 Q 925 360 955 300" fill="none" stroke="var(--good)" stroke-width="3" class="t-pulse"/>
    <g stroke="var(--twin-text)" stroke-width="3" fill="none" opacity=".85">
      <path d="M955 450 L955 230"/><path d="M930 270 H980"/><path d="M938 310 H972"/>
      <path d="M955 450 L938 310M955 450 L972 310"/>
    </g>
    <text x="955" y="214" text-anchor="middle" font-size="12" font-weight="700" fill="var(--twin-text)" opacity=".7">GRID</text>

    <!-- floating information label -->
    <g transform="translate(420 40)">
      <rect width="250" height="86" rx="14" fill="var(--surface)" stroke="var(--border)" opacity=".96"/>
      <text x="16" y="26" font-size="12" font-weight="700" fill="var(--text-3)" letter-spacing="1">PREDICTED POWER</text>
      <text id="twMW" x="16" y="62" font-size="34" font-weight="700" fill="var(--primary)">– MW</text>
      <text id="twFlowTxt" x="234" y="62" text-anchor="end" font-size="13" font-weight="600" fill="var(--text-2)"></text>
    </g>
  </svg>`;

  const $t = (id) => container.querySelector('#' + id);
  const wavePath = (() => {                      // a long wavy line that we slide sideways
    let d = 'M-120 0';
    for (let x = -120; x < 480; x += 60) d += ` q 15 -10 30 0 t 30 0`;
    return d + ' V 16 H -120 Z';
  })();
  $t('twWavePath').setAttribute('d', wavePath);

  return {
    update(r, predictedMW) {
      if (!r) return;
      const running = r.turbine_status === 'Running';
      const color = running ? 'var(--good)' : 'var(--bad)';

      // water level: 135 m .. 185 m  ->  fills 25% .. 95% of the reservoir
      const frac = Math.max(0, Math.min(1, (r.water_level - 135) / 50));
      const top = 440 - (80 + 230 * frac);                       // y of water surface
      $t('twWater').setAttribute('y', top);
      $t('twWater').setAttribute('height', 450 - top);
      $t('twWave').setAttribute('transform', `translate(0 ${top - 4})`);
      $t('twLevel').setAttribute('y', top + 32);
      $t('twLevel').textContent = `${HM.fmt(r.water_level, 1)} m`;

      // flow -> speed of the water animation in the pipe + spin speed of the turbine
      const flow = Number(r.water_flow);
      const flowing = flow > 3 && running;
      const pipeWater = $t('twPipeWater');
      pipeWater.style.animationDuration = `${Math.max(0.35, 2.4 - flow / 55)}s`;
      pipeWater.style.opacity = flow > 3 ? 1 : 0.15;
      const blades = $t('twBlades');
      blades.style.animationDuration = `${Math.max(0.5, 3.4 - flow / 30)}s`;
      blades.classList.toggle('paused', !running);

      $t('twTurbRing').setAttribute('stroke', color);
      $t('twBladeLines').setAttribute('stroke', color);
      $t('twStatus').textContent = running ? 'RUNNING' : 'STOPPED';
      $t('twStatus').setAttribute('fill', color);
      $t('twGen').setAttribute('fill', running ? 'var(--primary)' : 'var(--text-3)');
      $t('twGlow').style.display = running ? '' : 'none';
      $t('twLine').setAttribute('stroke', running ? 'var(--good)' : 'var(--text-3)');
      $t('twLine').classList.toggle('paused', !running);
      $t('twMW').textContent = predictedMW != null ? `${HM.fmt(predictedMW, 1)} MW` : '– MW';
      $t('twFlowTxt').textContent = `${HM.fmt(flow, 1)} m³/s`;
    },
  };
};
