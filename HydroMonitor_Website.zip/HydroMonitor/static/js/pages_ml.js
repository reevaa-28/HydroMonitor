/* =====================================================================
   pages_ml.js  -  the machine-learning pages
   Power Prediction, Future Forecast, Turbine Health, Anomaly Detection,
   Prediction Confidence, Model Comparison
   ===================================================================== */

/* ---------- shared: the 7-input form used by Prediction and Confidence ---------- */
const FIELDS = [
  ['water_flow', 'Water flow (m³/s)', 0, 200, 0.1], ['water_level', 'Water level (m)', 100, 220, 0.1],
  ['hydraulic_head', 'Hydraulic head (m)', 10, 120, 0.1], ['temperature', 'Temperature (°C)', 0, 150, 0.1],
  ['rainfall', 'Rainfall (mm)', 0, 200, 0.1], ['turbine_efficiency', 'Turbine efficiency (%)', 0, 100, 0.1],
];
HM.inputForm = (prefix, v) => `<div class="form-grid">
  ${FIELDS.map((f) => `<div class="field"><label for="${prefix}_${f[0]}">${f[1]}</label>
    <input type="number" id="${prefix}_${f[0]}" min="${f[2]}" max="${f[3]}" step="${f[4]}" value="${HM.fmt(v[f[0]], 1)}"></div>`).join('')}
  <div class="field"><label for="${prefix}_turbine_status">Turbine status</label>
    <select id="${prefix}_turbine_status"><option ${v.turbine_status === 'Running' ? 'selected' : ''}>Running</option><option ${v.turbine_status === 'Stopped' ? 'selected' : ''}>Stopped</option></select></div></div>`;
HM.readForm = (prefix) => {
  const o = {};
  FIELDS.forEach((f) => { o[f[0]] = $('#' + prefix + '_' + f[0]).value; });
  o.turbine_status = $('#' + prefix + '_turbine_status').value;
  return o;
};
HM.fillForm = (prefix, v) => {
  FIELDS.forEach((f) => { $('#' + prefix + '_' + f[0]).value = HM.fmt(v[f[0]], 1); });
  $('#' + prefix + '_turbine_status').value = v.turbine_status;
};
HM.segment = (id, options, current) => `<div class="seg" id="${id}">${options.map((o) => `<button data-v="${HM.esc(o)}" class="${o == current ? 'on' : ''}">${HM.esc(o)}</button>`).join('')}</div>`;
HM.onSegment = (id, fn) => $('#' + id).addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  $$('button', $('#' + id)).forEach((x) => x.classList.toggle('on', x === b)); fn(b.dataset.v);
});
HM.segValue = (id) => ($('#' + id + ' .on') || {}).dataset?.v;

/* ============================ POWER PREDICTION ============================ */
HM.pages.prediction = {
  title: 'Power Prediction', sub: 'Predict power generation (MW) with Linear Regression or Random Forest',
  async mount(view) {
    const latest = (await HM.get('/api/readings?limit=1')).latest;
    const start = latest || HM.meta.defaults;
    view.innerHTML = `
      <div class="grid g21">
        <div class="card">
          <div class="card-h"><div><h3>Inputs</h3><p>Enter sensor values or load the latest stored reading</p></div>
            <button class="btn btn-sm" id="ppLoad" ${latest ? '' : 'disabled'}>${HM.icon('down')} Load latest reading</button></div>
          ${HM.inputForm('pp', start)}
          <div class="row spread" style="margin-top:18px">
            <div class="row"><span class="small muted">Model</span>${HM.segment('ppModel', HM.meta.models, 'Random Forest')}</div>
            <button class="btn btn-primary btn-lg" id="ppGo">${HM.icon('bolt')} Predict power</button>
          </div>
        </div>
        <div class="card" id="ppResult"><div class="empty"><h3>No prediction yet</h3><p>Fill the inputs and press <b>Predict power</b>.</p></div></div>
      </div>
      <div class="grid g2 mt" id="ppExtra"></div>`;
    $('#ppLoad').onclick = () => HM.fillForm('pp', latest);
    $('#ppGo').onclick = (e) => HM.busy(e.currentTarget, async () => {
      const model = HM.segValue('ppModel');
      const r = await HM.post('/api/predict', { model, inputs: HM.readForm('pp') });
      const x = r.result;
      $('#ppResult').innerHTML = `<div class="card-h"><div><h3>Result</h3><p>${model}</p></div></div>
        <div class="big-result"><b class="num">${HM.fmt(x.prediction, 2)}</b> <small>MW</small></div>
        <p class="small muted" style="text-align:center">Estimated range ${HM.fmt(x.lower, 2)} – ${HM.fmt(x.upper, 2)} MW</p>
        ${HM.rangeBar(x.lower, x.prediction, x.upper)}`;
      $('#ppExtra').innerHTML = `
        <div class="card"><div class="card-h"><div><h3>Model comparison</h3><p>Same inputs, three answers</p></div></div><div class="chart short" id="ppBars"></div></div>
        <div class="card"><div class="card-h"><h3>What does this mean?</h3></div>
          ${HM.note(`The <b>Equation</b> bar is the physics formula P = ρ·g·Q·H·η for these inputs (it was used to create the synthetic data). It is shown for comparison only.`)}
          <p class="small muted" style="margin-top:12px">Prediction saved to the database (table <code>predictions</code>).</p></div>`;
      HM.hbar($('#ppBars'), { labels: ['Linear Regression', 'Random Forest', 'Equation'],
        values: [r.both['Linear Regression'], r.both['Random Forest'], r.formula],
        colors: [HM.palette().c[1], HM.palette().c[0], HM.palette().c[4]], format: (v) => v.toFixed(2) + ' MW' });
    });
  },
};

/* ============================ FUTURE FORECAST ============================ */
HM.pages.forecast = {
  title: 'Future Forecast', sub: 'Scenario-based estimates of future power generation',
  scenario: null, horizon: '24',
  mount(view) {
    const desc = { Steady: 'Recent average flow and level continue.', Rising: 'Flow +25 %, level +4 m, 8 mm/h rain.', Dry: 'Flow −25 %, level −5 m, no rain.' };
    const icons = { Steady: 'sensor', Rising: 'rain', Dry: 'sun' };
    this.scenario = this.scenario || HM.meta.scenarios[0];
    view.innerHTML = `
      ${HM.note('<b>Important:</b> ' + HM.esc(HM.meta.forecast_explanation), 'warn')}
      <div class="card mt"><div class="card-h"><h3>1. Choose a future scenario</h3></div>
        <div class="grid g3" id="fcChoices">${HM.meta.scenarios.map((s) => {
          const k = s.split(' ')[0]; return `<div class="choice ${s === this.scenario ? 'on' : ''}" data-s="${HM.esc(s)}"><b>${HM.icon(icons[k])} ${HM.esc(s)}</b><span>${desc[k] || ''}</span></div>`; }).join('')}</div>
        <div class="row spread" style="margin-top:18px"><div class="row"><span class="small muted">2. Time horizon (hours)</span>${HM.segment('fcHz', HM.meta.horizons.map(String), this.horizon)}</div>
          <button class="btn btn-primary btn-lg" id="fcGo">${HM.icon('forecast')} Generate forecast</button></div></div>
      <div id="fcOut"></div>
      <details class="card mt"><summary>Saved forecast records (SQLite) <span class="muted small">click to open</span></summary><div class="table-wrap" id="fcSaved"></div></details>`;
    $('#fcChoices').onclick = (e) => { const c = e.target.closest('.choice'); if (!c) return; this.scenario = c.dataset.s; $$('.choice', view).forEach((x) => x.classList.toggle('on', x === c)); };
    HM.onSegment('fcHz', (v) => { this.horizon = v; });
    $('#fcGo').onclick = (e) => HM.busy(e.currentTarget, async () => {
      const f = await HM.post('/api/forecast', { scenario: this.scenario });
      const hz = Number(this.horizon), sel = f.rows.filter((r) => r.hours <= hz);
      const show = f.rows.filter((r) => HM.meta.horizons.includes(r.hours) && r.hours <= hz);
      const c = HM.palette().c;
      $('#fcOut').innerHTML = `<div class="grid g21 mt">
        <div class="card"><div class="card-h"><div><h3>Scenario: ${HM.esc(f.scenario)}</h3><p>Based on the average of the latest ${f.based_on} readings</p></div>
          <div class="legend"><span><i style="background:${c[0]}"></i>Linear Regression</span><span><i style="background:${c[1]}"></i>Random Forest</span></div></div>
          <div class="chart tall" id="fcChart"></div></div>
        <div class="card"><div class="card-h"><h3>Estimates</h3></div><div class="table-wrap"><table><thead><tr><th>Time</th><th>Hours</th><th>Linear</th><th>Forest</th></tr></thead><tbody>
          ${show.map((r) => `<tr><td>${r.time.slice(5)}</td><td>+${r.hours}</td><td class="num">${HM.fmt(r.linear, 2)}</td><td class="num"><b>${HM.fmt(r.forest, 2)}</b></td></tr>`).join('')}</tbody></table></div>
          <p class="small muted" style="margin-top:10px">Values in MW. Scenario-based estimates, not verified measurements.</p></div></div>`;
      HM.line($('#fcChart'), { labels: sel.map((r) => '+' + r.hours + ' h'), xLabel: 'Hours ahead', yLabel: 'MW', unit: 'MW', markers: sel.length < 10,
        series: [{ name: 'Linear Regression', data: sel.map((r) => r.linear), color: c[0] }, { name: 'Random Forest', data: sel.map((r) => r.forest), color: c[1] }] });
      this.loadSaved();
    });
    this.loadSaved();
  },
  async loadSaved() {
    const d = await HM.get('/api/forecast/saved'), el = $('#fcSaved'); if (!el) return;
    el.innerHTML = d.rows.length ? `<table><thead><tr><th>Created</th><th>Forecast time</th><th>Hours</th><th>Scenario</th><th>Linear</th><th>Forest</th></tr></thead><tbody>${d.rows.map((r) => `<tr><td>${HM.tshort(r.created_at)}</td><td>${HM.tshort(r.forecast_time)}</td><td>${r.horizon_hours}</td><td>${HM.esc(r.scenario)}</td><td class="num">${HM.fmt(r.linear_power, 2)}</td><td class="num">${HM.fmt(r.forest_power, 2)}</td></tr>`).join('')}</tbody></table>` : '<p class="muted small">No forecasts saved yet.</p>';
  },
};

/* ============================ TURBINE HEALTH ============================ */
HM.pages.health = {
  title: 'Turbine Health', sub: 'Illustrative rule-based score (0–100)',
  mount(view) {
    view.innerHTML = `${HM.note('An academic monitoring score using transparent rules. It is <b>not</b> a certified engineering diagnosis.')}
      <div id="hBody" class="mt">${HM.loading(3)}</div>`;
  },
  async refresh(first) {
    const d = await HM.get('/api/health');
    this.render(d);
  },
  render(d) {
    const el = $('#hBody'); if (!el) return;
    if (d.empty) { el.innerHTML = HM.empty('No readings yet', 'The score is calculated from the latest reading.'); return; }
    const h = d.health, tone = HM.tone(h.score), c = HM.palette().c;
    const stateTone = { Good: 'good', Watch: 'warn', Poor: 'bad' };
    el.innerHTML = `<div class="grid g12">
      <div class="card" style="text-align:center"><div class="card-h"><div style="text-align:left"><h3>Health score</h3><p>Reading ${HM.tshort(d.reading_time)}</p></div>${HM.badge(h.category, tone)}</div>
        ${HM.gauge(h.score, 'out of 100')}</div>
      <div class="card"><div class="card-h"><h3>Parameter-wise status</h3></div><div class="table-wrap"><table><thead><tr><th>Parameter</th><th>Value</th><th>Score</th><th>Weight</th><th>State</th></tr></thead><tbody>
        ${h.parameters.map((p) => `<tr><td><b>${p.Parameter}</b><br><span class="small muted">${p.Rule}</span></td><td class="num">${HM.esc(p.Value)}</td>
          <td style="min-width:130px"><div class="progress"><i style="width:${p['Score (0-100)']}%;background:var(--${stateTone[p.State]})"></i></div><span class="small num">${p['Score (0-100)']}</span></td>
          <td>${p.Weight}</td><td>${HM.badge(p.State, stateTone[p.State])}</td></tr>`).join('')}</tbody></table></div></div></div>
      <div class="grid g2 mt">
        <div class="card"><div class="card-h"><h3>Reasons for score reduction</h3></div>
          ${h.reasons.length ? `<ul style="margin:0;padding-left:18px">${h.reasons.map((r) => `<li style="margin-bottom:6px">${HM.esc(r)}</li>`).join('')}</ul>` : '<p class="badge good">All parameters are inside the ideal ranges</p>'}
          ${h.checks.length ? `<div class="card-h" style="margin-top:18px"><h3>Suggested checks</h3></div><ul style="margin:0;padding-left:18px">${[...new Set(h.checks)].map((r) => `<li style="margin-bottom:6px">${HM.esc(r)}</li>`).join('')}</ul>` : ''}</div>
        <div class="card"><div class="card-h"><div><h3>Scoring weights</h3><p>Configurable – normalised to sum to 1</p></div></div>
          ${Object.entries(d.weights).map(([k, v]) => `<div class="field" style="margin-bottom:10px"><label>${HM.title(k)} <b class="num" id="wv_${k}">${v.toFixed(2)}</b></label>
            <input type="range" min="0" max="1" step="0.05" value="${v}" data-w="${k}"></div>`).join('')}</div></div>
      ${HM.chartCard('hHist', 'Stored health score history', 'Latest 100 readings', '', '').replace('class="card"', 'class="card mt"')}`;
    HM.line($('#hHist'), { labels: d.history.map((r) => HM.tshort(r.timestamp)), yMin: 0, yMax: 100, unit: '/100',
      series: [{ name: 'Health score', data: d.history.map((r) => r.health_score), color: c[4] }], area: true });
    let t; $$('[data-w]', el).forEach((s) => s.oninput = () => {
      $('#wv_' + s.dataset.w).textContent = (+s.value).toFixed(2);
      clearTimeout(t);
      t = setTimeout(async () => {
        const w = {}; $$('[data-w]', el).forEach((x) => { w[x.dataset.w] = +x.value; });
        try { this.render(await HM.post('/api/health/weights', { weights: w })); } catch (e) { HM.error(e); }
      }, 350);
    });
  },
};

/* ============================ ANOMALY DETECTION ============================ */
HM.pages.anomaly = {
  title: 'Anomaly Detection', sub: 'Isolation Forest + simple safety rules',
  mount(view) {
    view.innerHTML = `${HM.note('An anomaly means an <b>unusual reading</b>. It does not automatically mean equipment failure.')}
      <div class="card mt"><div class="card-h"><div><h3>Controlled abnormal test</h3><p>Inject a deliberately abnormal reading to see the detector react</p></div></div>
        <div class="row">${HM.meta.abnormal_kinds.map((k) => `<button class="btn btn-danger" data-kind="${HM.esc(k)}">${HM.icon('alert')} ${HM.esc(k)}</button>`).join('')}
          <button class="btn btn-primary" id="anNormal">${HM.icon('check')} Generate normal reading</button></div></div>
      <div id="anResult"></div><div id="anHist" class="mt">${HM.loading(3)}</div>`;
    $$('[data-kind]', view).forEach((b) => b.onclick = () => HM.busy(b, () => HM.generate(b.dataset.kind)));
    $('#anNormal').onclick = (e) => HM.busy(e.currentTarget, () => HM.generate());
  },
  async refresh() {
    const r = HM.lastResult;
    if ($('#anResult') && r) {
      const a = r.anomaly, bad = a.status === 'Anomaly';
      $('#anResult').innerHTML = `<div class="card mt" style="border-left:5px solid var(--${bad ? 'bad' : 'good'})">
        <div class="row spread"><div class="row"><h3>Status:</h3>${HM.badge(a.status, bad ? 'bad' : 'good')}</div>
          <span class="small muted">${r.reading.timestamp} · score <b class="num">${a.score.toFixed(3)}</b> (lower = more unusual; below 0 = flagged)</span></div>
        <p style="margin-top:10px"><b>Affected sensors:</b> ${a.affected.length ? a.affected.map((x) => HM.badge(HM.title(x), 'bad')).join(' ') : 'none'}</p>
        <p style="margin-top:8px"><b>Explanation:</b> <span class="muted">${HM.esc(a.explanation)}</span></p></div>`;
    }
    const d = await HM.get('/api/anomalies'), el = $('#anHist'); if (!el) return;
    if (!d.history.length) { el.innerHTML = '<div class="card empty"><h3>No detections yet</h3><p>Generate a reading above.</p></div>'; return; }
    const c = HM.palette().c, hist = d.history.slice().reverse();
    if (!$('#anChart')) {
      el.innerHTML = `<div class="grid g3" id="anKpi"></div>
        <div class="grid g21 mt">${HM.chartCard('anChart', 'Anomaly score history', 'Red dots = flagged readings, dashed line = decision boundary (0)', 'tall')}
        <div class="card"><div class="card-h"><div><h3>Flagged readings</h3><p>Most recent first</p></div></div><div id="anList" style="max-height:330px;overflow:auto"></div></div></div>`;
    }
    $('#anKpi').innerHTML = HM.kpi({ label: 'Readings checked', value: d.checked, icon: 'scan' }) +
      HM.kpi({ label: 'Anomalies', value: d.count, icon: 'alert', tone: d.count ? 'bad' : 'good' }) +
      HM.kpi({ label: 'Latest status', value: d.history[0].status, icon: 'check', tone: d.history[0].status === 'Anomaly' ? 'bad' : 'good' });
    HM.line($('#anChart'), { labels: hist.map((r) => HM.tshort(r.timestamp)), hline: 0, hlineLabel: 'boundary', unit: '',
      series: [{ name: 'Score', data: hist.map((r) => r.anomaly_score), color: c[0] },
               { name: 'Anomaly', data: hist.map((r) => r.status === 'Anomaly' ? r.anomaly_score : null), color: c[3], dots: true, r: 5 }] });
    const an = d.history.filter((r) => r.status === 'Anomaly');
    $('#anList').innerHTML = an.length ? an.map((r) => `<div class="mini-alert"><div class="bar Critical"></div><div><b>${HM.tshort(r.timestamp)}</b> · <span class="muted">${HM.esc(r.affected_parameters || 'combination of values')}</span><br><span class="muted">${HM.esc(r.explanation).slice(0, 120)}…</span></div></div>`).join('') : '<p class="muted small">No anomalies so far.</p>';
  },
};

/* ============================ PREDICTION CONFIDENCE ============================ */
HM.pages.confidence = {
  title: 'Prediction Confidence', sub: 'Estimated lower and upper prediction range',
  async mount(view) {
    const latest = (await HM.get('/api/readings?limit=1')).latest;
    this.start = latest || HM.meta.defaults;
    view.innerHTML = `<div class="card"><div class="row spread">
        <div class="row"><span class="small muted">Model</span>${HM.segment('cfModel', HM.meta.models, 'Random Forest')}
          <span class="small muted" style="margin-left:10px">Input</span>${HM.segment('cfSrc', ['Latest reading', 'Manual input'], 'Latest reading')}</div></div>
        <div id="cfForm" style="display:none;margin-top:16px">${HM.inputForm('cf', this.start)}<button class="btn btn-primary" id="cfGo" style="margin-top:14px">Calculate range</button></div></div>
      <div id="cfBody" class="mt">${HM.loading(4)}</div>`;
    const run = () => this.run();
    HM.onSegment('cfModel', run);
    HM.onSegment('cfSrc', (v) => { $('#cfForm').style.display = v === 'Manual input' ? '' : 'none'; if (v !== 'Manual input') run(); });
    $('#cfGo').onclick = (e) => HM.busy(e.currentTarget, run);
    run();
  },
  async run() {
    const manual = HM.segValue('cfSrc') === 'Manual input';
    const model = HM.segValue('cfModel');
    let d;
    try { d = await HM.post('/api/confidence', { model, source: manual ? 'manual' : 'latest', inputs: manual ? HM.readForm('cf') : undefined }); }
    catch (e) { return HM.error(e); }
    const el = $('#cfBody'); if (!el) return;
    if (d.empty) { el.innerHTML = HM.empty('No readings yet', 'Generate a reading or switch to manual input.'); return; }
    const r = d.result, v = d.validation, c = HM.palette().c;
    el.innerHTML = `<div class="grid g4">
        ${HM.kpi({ label: 'Model', value: model.split(' ')[0], sub: model, icon: 'chart' })}
        ${HM.kpi({ label: 'Predicted power', value: HM.fmt(r.prediction, 2), unit: 'MW', icon: 'bolt' })}
        ${HM.kpi({ label: 'Lower estimate', value: HM.fmt(r.lower, 2), unit: 'MW', icon: 'down', tone: 'aqua' })}
        ${HM.kpi({ label: 'Upper estimate', value: HM.fmt(r.upper, 2), unit: 'MW', icon: 'forecast', tone: 'aqua' })}</div>
      <div class="grid g2 mt">
        <div class="card"><div class="card-h"><div><h3>Prediction (dot) and estimated range (bar)</h3></div></div>${HM.rangeBar(r.lower, r.prediction, r.upper)}</div>
        <div class="card"><div class="card-h"><h3>How the range is calculated</h3></div><p class="muted">${HM.esc(d.method)}</p></div></div>
      <h3 style="margin:24px 0 12px">Validation on held-out synthetic test data</h3>
      <div class="grid g3">
        ${HM.kpi({ label: 'Test rows inside range', value: HM.fmt(v.coverage, 1), unit: '%', icon: 'target', tone: 'good' })}
        ${HM.kpi({ label: 'Average range width', value: HM.fmt(v.width, 2), unit: 'MW', icon: 'layers' })}
        ${HM.kpi({ label: 'Test rows', value: v.n_test, icon: 'db' })}</div>
      <div class="card mt"><div class="card-h"><div><h3>${HM.esc(model)}: test rows sorted by prediction</h3><p>Shaded band = estimated range</p></div>
        <div class="legend"><span><i style="background:${c[0]}"></i>Prediction</span><span><i style="background:${c[3]}"></i>Actual (simulated)</span></div></div><div class="chart tall" id="cfChart"></div></div>
      <div class="note warn mt">${HM.esc(HM.meta.confidence_limits)}</div>`;
    HM.line($('#cfChart'), { labels: v.mean.map((_, i) => '#' + (i + 1)), unit: 'MW',
      bands: [{ lower: v.lower, upper: v.upper, color: c[0] }],
      series: [{ name: 'Prediction', data: v.mean, color: c[0] }, { name: 'Actual', data: v.actual, color: c[3], dots: true }] });
  },
};

/* ============================ MODEL COMPARISON ============================ */
HM.pages.models = {
  title: 'Model Comparison', sub: 'Linear Regression vs Random Forest (same 20 % test rows)',
  mount(view) { view.innerHTML = '<div id="mBody">' + HM.loading(4) + '</div>'; },
  async refresh() {
    const d = await HM.get('/api/models'), el = $('#mBody'); if (!el) return;
    const names = Object.keys(d.metrics), m = d.metrics, c = HM.palette().c, cols = [c[1], c[0]];
    const best = (k, low) => names.reduce((a, b) => (low ? m[a][k] <= m[b][k] : m[a][k] >= m[b][k]) ? a : b);
    el.innerHTML = `
      <div class="card"><div class="card-h"><div><h3>Test-set metrics</h3><p>${d.n_test} test rows · 80:20 split · random_state = 42 · calculated from real predictions</p></div></div>
        <div class="table-wrap"><table><thead><tr><th>Model</th><th>MAE (MW)</th><th>MSE</th><th>RMSE (MW)</th><th>R²</th><th>Est. accuracy %</th></tr></thead><tbody>
        ${names.map((n) => `<tr><td><b>${n}</b></td>${[['MAE', 1], ['MSE', 1], ['RMSE', 1], ['R2', 0], ['EstAccuracy', 0]].map(([k, low]) => `<td class="num">${m[n][k].toFixed(k === 'EstAccuracy' ? 2 : 4)} ${best(k, low) === n ? '<span class="badge good">best</span>' : ''}</td>`).join('')}</tr>`).join('')}</tbody></table></div></div>
      <div class="grid g4 mt">${['MAE', 'MSE', 'RMSE', 'R2'].map((k) => HM.chartCard('mb_' + k, k, k === 'R2' ? 'higher is better' : 'lower is better', 'short')).join('')}</div>
      <div class="grid g2 mt">
        ${HM.chartCard('mScatter', 'Actual vs predicted', 'Points on the dashed line = perfect prediction', 'tall')}
        ${HM.chartCard('mResid', 'Residual (error) plot', 'Error = actual − predicted', 'tall')}</div>
      <div class="grid g21 mt">
        ${HM.chartCard('mImp', 'Random Forest feature importance', 'How much each input helped the trees split', 'short')}
        <div class="card"><div class="card-h"><h3>Estimated regression accuracy</h3></div>
          ${names.map((n, i) => `<div style="margin-bottom:14px"><div class="row spread"><b>${n}</b><b class="num">${m[n].EstAccuracy.toFixed(2)} %</b></div><div class="progress"><i style="width:${m[n].EstAccuracy}%;background:${cols[i]}"></i></div></div>`).join('')}</div></div>
      <div class="note mt">Project-defined estimate = 100 × (1 − MAE / (max test target − min test target)). It is <b>not</b> classification accuracy and <b>not</b> R². Because the data is synthetic and created from the same equation the models learn, scores are high and do not show real-plant accuracy.</div>`;
    ['MAE', 'MSE', 'RMSE', 'R2'].forEach((k) => HM.bar($('#mb_' + k), { labels: ['Linear', 'Forest'], values: names.map((n) => m[n][k]), colors: cols, format: (v) => v.toFixed(3) }));
    const pts = (n) => d.actual.map((a, i) => [a, d.pred[n][i]]);
    HM.scatter($('#mScatter'), { diag: true, xLabel: 'Actual (simulated) MW', yLabel: 'Predicted MW', series: names.map((n, i) => ({ name: n, points: pts(n), color: cols[i], r: 2.6 })) });
    HM.scatter($('#mResid'), { hline: 0, xLabel: 'Predicted MW', yLabel: 'Error (MW)', series: names.map((n, i) => ({ name: n, points: d.actual.map((a, j) => [d.pred[n][j], a - d.pred[n][j]]), color: cols[i], r: 2.6 })) });
    const imp = Object.entries(d.importance).sort((a, b) => b[1] - a[1]);
    HM.hbar($('#mImp'), { labels: imp.map((x) => HM.title(x[0])), values: imp.map((x) => x[1]), color: c[0], format: (v) => (v * 100).toFixed(1) + ' %' });
  },
};
