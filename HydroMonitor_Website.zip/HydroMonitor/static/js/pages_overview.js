/* =====================================================================
   pages_overview.js  -  Home, Dashboard, Digital Twin, Sensor Monitoring
   Every page is an object:  { title, sub, mount(view), refresh() }
     mount()   draws the empty page structure once
     refresh() loads data from the API and fills the page (called again on live updates)
   ===================================================================== */

/* ============================ HOME (landing page) ============================ */
HM.pages.home = {
  title: 'Welcome', sub: 'ML-Based Hydropower Plant Monitoring and Power Generation Prediction',
  mount(view) {
    const wave = (c, cls) => `<svg class="waves ${cls}" viewBox="0 0 1440 80" preserveAspectRatio="none">
      <path fill="${c}" d="M0 40 C 120 10 240 10 360 40 S 600 70 720 40 S 960 10 1080 40 S 1320 70 1440 40 V80 H0Z"/></svg>`;
    const features = [
      ['dashboard', 'dash', 'Dashboard', 'Live KPIs, trends and plant status at a glance.'],
      ['twin', 'twin', 'Digital Twin', 'Animated plant that reacts to every reading.'],
      ['sensors', 'sensor', 'Sensor Monitoring', 'Simulated sensors, live simulation, history table.'],
      ['prediction', 'bolt', 'Power Prediction', 'Linear Regression and Random Forest in MW.'],
      ['forecast', 'forecast', 'Future Forecast', 'Scenario-based estimates for 1, 3, 6 and 24 hours.'],
      ['health', 'heart', 'Turbine Health', 'Transparent 0–100 score with reasons and checks.'],
      ['anomaly', 'scan', 'Anomaly Detection', 'Isolation Forest plus simple safety rules.'],
      ['history', 'db', 'Historical Data', 'SQLite records, date filter, CSV download.'],
      ['reservoir', 'drop', 'Reservoir Analysis', 'Water behaviour and correlation with power.'],
      ['models', 'chart', 'Model Comparison', 'MAE, RMSE, R², residuals, feature importance.'],
      ['confidence', 'target', 'Prediction Confidence', 'Lower / upper range and measured coverage.'],
      ['alerts', 'bell', 'Alert Monitoring', 'Configurable thresholds and acknowledgements.'],
      ['reports', 'file', 'Reports', 'One-click PDF report and CSV export.'],
    ];
    const steps = [['sensor', 'Simulate', 'Sensor reading'], ['db', 'Store', 'SQLite'], ['bolt', 'Predict', 'ML models'],
                   ['scan', 'Detect', 'Anomaly check'], ['heart', 'Score', 'Health 0–100'], ['bell', 'Alert', 'Thresholds'], ['file', 'Report', 'PDF / CSV']];
    view.innerHTML = `
      <section class="hero">
        <span class="eyebrow">${HM.icon('drop')} Final-year MCA project</span>
        <h1>Monitor a hydropower plant and <span>predict its power with machine learning</span></h1>
        <p class="lead">HydroMonitor simulates plant sensors, stores readings in a database, predicts electricity
          generation, flags unusual behaviour and scores turbine health — all in one web dashboard.</p>
        <div class="row" style="margin-top:26px">
          <a class="btn btn-primary btn-lg" href="#/dashboard">${HM.icon('dash')} Open dashboard</a>
          <a class="btn btn-lg" href="#/twin">${HM.icon('twin')} See the digital twin</a>
        </div>
        ${wave('rgba(255,255,255,.18)', 'w2')}${wave('var(--bg)', '')}
      </section>

      <div class="stat-strip">
        <div class="card"><b>13</b><span>Web pages</span></div>
        <div class="card"><b>3</b><span>ML algorithms</span></div>
        <div class="card"><b>6,000</b><span>Training records</span></div>
        <div class="card"><b>7</b><span>SQLite tables</span></div>
      </div>

      <h2 class="section-title mt2">How one reading flows through the system</h2>
      <p class="section-sub">Every new reading automatically goes through all of these steps.</p>
      <div class="card"><div class="flow">
        ${steps.map((s, i) => `<div class="step"><div class="n">${HM.icon(s[0])}</div><b>${i + 1}. ${s[1]}</b><span>${s[2]}</span></div>`).join('')}
      </div></div>

      <h2 class="section-title mt2">Explore the modules</h2>
      <p class="section-sub">Click any card to open that page.</p>
      <div class="grid g4">
        ${features.map((f) => `<a class="card feature" href="#/${f[0]}"><div class="ic">${HM.icon(f[1])}</div><h4>${f[2]}</h4><p>${f[3]}</p></a>`).join('')}
      </div>

      <div class="grid g2 mt2">
        <div class="card"><div class="card-h"><div><h3>Technology stack</h3><p>What the project is built with</p></div></div>
          <div class="chips">${['Python 3.12', 'Flask', 'HTML5', 'CSS3', 'JavaScript', 'Canvas / SVG', 'SQLite', 'Pandas', 'NumPy', 'Scikit-learn', 'Joblib', 'ReportLab'].map((t) => `<span class="chip">${t}</span>`).join('')}</div>
          <p class="small muted" style="margin-top:14px">Front end: plain HTML, CSS and JavaScript (no framework, no internet needed).
          Back end: Flask exposes the Python machine-learning modules as a JSON API.</p></div>
        <div class="card"><div class="card-h"><div><h3>The core equation</h3><p>Used to create the synthetic dataset</p></div></div>
          <div class="note" style="font-size:18px;text-align:center;font-weight:600">P = (ρ × g × Q × H × η) / 1,000,000</div>
          <p class="small muted" style="margin-top:12px">ρ water density 1000 kg/m³ · g gravity 9.81 · Q flow (m³/s) · H head (m) · η efficiency. Result in megawatts (MW).</p></div>
      </div>
      <div class="note warn mt2"><b>Academic demonstration:</b> all sensor data is generated by a Python simulator. No physical plant or sensor is connected, and the very high model scores come from the synthetic, equation-based data.</div>`;
  },
};

/* ============================ DASHBOARD ============================ */
HM.pages.dashboard = {
  title: 'Dashboard', sub: 'Overview of the simulated hydropower plant',
  mount(view) { view.innerHTML = '<div id="dashBody">' + HM.loading(8) + '</div>'; },
  async refresh() {
    const d = await HM.get('/api/dashboard');
    const body = $('#dashBody'); if (!body) return;
    if (!d.latest) { body.innerHTML = HM.empty('No sensor readings yet', 'Generate readings to see the dashboard come alive.'); return; }
    const L = d.latest, h = d.health, rf = d.prediction;
    const s = d.series;
    // Build the page structure only once; later refreshes just update numbers and charts
    if (!$('#kpiRow', body)) {
      body.innerHTML = `
        <div class="grid g4" id="kpiRow"></div>
        <div class="grid g21 mt">
          <div class="grid" style="gap:16px">
            ${HM.chartCard('chPower', 'Power generation trend', 'Simulated power (MW), latest 100 readings', '', '<span class="badge primary">MW</span>')}
            <div class="grid g2">
              ${HM.chartCard('chFlow', 'Water flow', 'm³/s', 'short')}
              ${HM.chartCard('chTemp', 'Temperature', '°C', 'short')}
            </div>
          </div>
          <div class="grid" style="gap:16px;align-content:start">
            <div class="card"><div class="card-h"><div><h3>Turbine health</h3><p>Illustrative rule-based score</p></div><span id="hBadge"></span></div><div id="hGauge"></div>
              <a class="btn btn-sm" style="margin-top:14px" href="#/health">View details</a></div>
            <div class="card"><div class="card-h"><div><h3>Latest alerts</h3><p>Unacknowledged only</p></div><a class="small" href="#/alerts">All alerts</a></div><div id="miniAlerts"></div></div>
            <div class="card"><div class="card-h"><h3>Quick actions</h3></div><div class="row">
              <button class="btn btn-primary" data-act="gen1">${HM.icon('bolt')} New reading</button>
              <button class="btn" data-act="gen24">${HM.icon('layers')} Add 24</button></div></div>
          </div>
        </div>`;
    }
    const running = L.turbine_status === 'Running';
    $('#kpiRow').innerHTML =
      HM.kpi({ label: 'Predicted generation', value: rf ? HM.fmt(rf.predicted_power, 1) : '–', unit: 'MW', sub: 'Random Forest', icon: 'bolt' }) +
      HM.kpi({ label: 'Water flow', value: HM.fmt(L.water_flow, 1), unit: 'm³/s', sub: HM.tshort(L.timestamp), icon: 'drop', tone: 'aqua' }) +
      HM.kpi({ label: 'Water level', value: HM.fmt(L.water_level, 1), unit: 'm', sub: `Head ${HM.fmt(L.hydraulic_head, 1)} m`, icon: 'layers', tone: 'aqua' }) +
      HM.kpi({ label: 'Temperature', value: HM.fmt(L.temperature, 1), unit: '°C', sub: `Rainfall ${HM.fmt(L.rainfall, 1)} mm`, icon: 'temp', tone: L.temperature > 65 ? 'warn' : '' }) +
      HM.kpi({ label: 'Turbine', value: L.turbine_status, sub: `Efficiency ${HM.fmt(L.turbine_efficiency, 1)} %`, icon: 'gear', tone: running ? 'good' : 'bad' }) +
      HM.kpi({ label: 'Total readings', value: d.count.toLocaleString(), sub: 'stored in SQLite', icon: 'db' }) +
      HM.kpi({ label: 'Anomalies found', value: d.anomalies, sub: 'unusual readings', icon: 'scan', tone: d.anomalies ? 'warn' : 'good' }) +
      HM.kpi({ label: 'Open alerts', value: d.alerts_open, sub: 'not yet acknowledged', icon: 'bell', tone: d.alerts_open ? 'bad' : 'good' });

    HM.trend('#chPower', s, 'simulated_power', 'MW', 0);
    HM.trend('#chFlow', s, 'water_flow', 'm³/s', 1);
    HM.trend('#chTemp', s, 'temperature', '°C', 3);
    $('#hGauge').innerHTML = h ? HM.gauge(h.health_score, h.category) : '<p class="muted">n/a</p>';
    $('#hBadge').innerHTML = h ? HM.badge(h.category.split(' ')[0], HM.tone(h.health_score)) : '';
    $('#miniAlerts').innerHTML = d.recent_alerts.length
      ? d.recent_alerts.map((a) => `<div class="mini-alert"><div class="bar ${a.severity}"></div><div><b>${HM.esc(a.parameter)}</b> · <span class="muted">${HM.tshort(a.timestamp)}</span><br><span class="muted">${HM.esc(a.message).slice(0, 90)}</span></div></div>`).join('')
      : '<p class="muted small">No open alerts. 🎉</p>';
  },
};

/* ============================ DIGITAL TWIN ============================ */
HM.pages.twin = {
  title: 'Digital Twin', sub: 'Software model of the plant, updated from the latest simulated reading',
  mount(view) {
    view.innerHTML = `
      <div class="note" id="twNote"></div>
      <div class="card twin mt" id="twCard"><div id="twScene"></div>
        <div class="twin-chips" id="twChips"></div></div>
      <div class="grid g2 mt">
        <div class="card"><div class="card-h"><h3>How it works</h3></div>
          <p class="muted">Water stored in the <b>reservoir</b> flows down the <b>penstock</b> (pipe), spins the <b>turbine</b>,
          which drives the <b>generator</b>. The picture changes with the newest reading: the water level rises or falls,
          the water in the pipe speeds up with flow, and the turbine stops when its status is <i>Stopped</i>.</p></div>
        <div class="card"><div class="card-h"><h3>Try it</h3></div>
          <div class="row"><button class="btn btn-primary" data-act="gen1">${HM.icon('bolt')} Generate new reading</button>
          <button class="btn" id="twStop">${HM.icon('alert')} Inject high-flow surge</button></div>
          <p class="small muted" style="margin-top:10px">Tip: start the <b>live simulation</b> (top right) and watch the plant move.</p></div>
      </div>`;
    $('#twNote').textContent = HM.meta.twin_disclaimer;
    this.scene = HM.twin($('#twScene'));
    $('#twStop').onclick = (e) => HM.busy(e.currentTarget, () => HM.generate('Water flow surge'));
  },
  async refresh() {
    const d = await HM.get('/api/dashboard');
    if (!d.latest) { $('#twChips').innerHTML = '<div style="grid-column:1/-1">No readings yet – generate one below.</div>'; return; }
    this.scene.update(d.latest, d.prediction ? d.prediction.predicted_power : null);
    const L = d.latest;
    $('#twChips').innerHTML = [['Reservoir level', HM.fmt(L.water_level, 1) + ' m'], ['Water flow', HM.fmt(L.water_flow, 1) + ' m³/s'],
      ['Turbine', L.turbine_status], ['Predicted power', d.prediction ? HM.fmt(d.prediction.predicted_power, 1) + ' MW' : 'n/a']]
      .map((c) => `<div><small>${c[0]}</small><b class="num">${c[1]}</b></div>`).join('');
  },
};

/* ============================ SENSOR MONITORING ============================ */
HM.pages.sensors = {
  title: 'Sensor Monitoring', sub: 'Simulated sensor readings and history',
  page: 0,
  mount(view) {
    view.innerHTML = `
      <div class="card"><div class="row spread">
        <div class="row">
          <button class="btn btn-primary" data-act="gen1">${HM.icon('bolt')} Generate new reading</button>
          <button class="btn" data-act="gen24">${HM.icon('layers')} Add 24 demo readings</button>
        </div>
        <span class="muted small" id="sensorInfo">Loading…</span></div></div>
      <div class="grid g4 mt" id="tiles"></div>
      <div class="grid g2 mt">
        ${HM.chartCard('s1', 'Water flow', 'm³/s')}${HM.chartCard('s2', 'Water level', 'm')}
        ${HM.chartCard('s3', 'Temperature', '°C')}${HM.chartCard('s4', 'Hydraulic head', 'm')}
      </div>
      <div class="card mt"><div class="card-h"><div><h3>Reading history</h3><p>Newest first</p></div></div>
        <div class="table-wrap" id="sTable"></div><div class="pager" id="sPager"></div></div>`;
  },
  async refresh() {
    const d = await HM.get('/api/readings?limit=100');
    const rows = d.readings, L = d.latest;
    if (!L) { $('#tiles').innerHTML = `<div style="grid-column:1/-1">${HM.empty('No readings yet', 'Use the buttons above to generate some.', false)}</div>`; return; }
    $('#sensorInfo').textContent = `Latest: ${L.timestamp} · Source: ${L.data_source}`;
    const tile = (label, key, unit, color, dec = 1) => `<div class="card tile"><div class="l"><span>${label}</span></div>
      <div class="v num">${HM.fmt(L[key], dec)} <small>${unit}</small></div>${HM.spark(rows.slice(-30).map((r) => r[key]), color)}</div>`;
    $('#tiles').innerHTML =
      tile('Water flow', 'water_flow', 'm³/s', 'var(--c2)') + tile('Water level', 'water_level', 'm', 'var(--c1)') +
      tile('Hydraulic head', 'hydraulic_head', 'm', 'var(--c5)') + tile('Temperature', 'temperature', '°C', 'var(--c4)') +
      tile('Rainfall', 'rainfall', 'mm', 'var(--c2)') + tile('Efficiency', 'turbine_efficiency', '%', 'var(--c3)') +
      `<div class="card tile"><div class="l"><span>Turbine status</span></div><div class="v">${HM.badge(L.turbine_status, L.turbine_status === 'Running' ? 'good' : 'bad')}</div><p class="small muted" style="margin-top:8px">Stopped turbine = 0 MW</p></div>` +
      tile('Simulated power', 'simulated_power', 'MW', 'var(--c1)');
    HM.trend('#s1', rows, 'water_flow', 'm³/s', 1);
    HM.trend('#s2', rows, 'water_level', 'm', 0);
    HM.trend('#s3', rows, 'temperature', '°C', 3);
    HM.trend('#s4', rows, 'hydraulic_head', 'm', 4);

    const desc = rows.slice().reverse(), per = 10, pages = Math.ceil(desc.length / per);
    this.page = Math.min(this.page, pages - 1);
    const part = desc.slice(this.page * per, this.page * per + per);
    $('#sTable').innerHTML = `<table><thead><tr><th>Time</th><th>Flow</th><th>Level</th><th>Head</th><th>Temp</th><th>Rain</th><th>Eff %</th><th>Status</th><th>Power MW</th></tr></thead><tbody>` +
      part.map((r) => `<tr><td>${HM.tshort(r.timestamp)}</td><td class="num">${HM.fmt(r.water_flow)}</td><td class="num">${HM.fmt(r.water_level)}</td><td class="num">${HM.fmt(r.hydraulic_head)}</td><td class="num">${HM.fmt(r.temperature)}</td><td class="num">${HM.fmt(r.rainfall)}</td><td class="num">${HM.fmt(r.turbine_efficiency)}</td><td>${HM.badge(r.turbine_status, r.turbine_status === 'Running' ? 'good' : 'bad')}</td><td class="num"><b>${HM.fmt(r.simulated_power, 2)}</b></td></tr>`).join('') + '</tbody></table>';
    $('#sPager').innerHTML = `<button class="btn btn-sm" id="pPrev" ${this.page === 0 ? 'disabled' : ''}>‹ Prev</button><span>Page ${this.page + 1} of ${pages}</span><button class="btn btn-sm" id="pNext" ${this.page >= pages - 1 ? 'disabled' : ''}>Next ›</button>`;
    $('#pPrev').onclick = () => { this.page--; this.refresh(); };
    $('#pNext').onclick = () => { this.page++; this.refresh(); };
  },
};
