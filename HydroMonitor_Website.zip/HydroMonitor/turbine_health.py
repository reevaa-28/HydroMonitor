# turbine_health.py
# PURPOSE: Illustrative turbine health score (0-100). Transparent, rule-based,
# configurable weights. NOT a certified engineering diagnosis.

DEFAULT_WEIGHTS = {"temperature": 0.25, "efficiency": 0.30, "flow": 0.15,
                   "head": 0.10, "status": 0.20}


def _lin(value, good, bad):
    """100 when value is at `good`, 0 when at `bad`, straight line in between."""
    if good == bad:
        return 100.0
    t = (value - bad) / (good - bad)
    return float(max(0.0, min(1.0, t)) * 100)


def _band(value, low, high, hard_low, hard_high):
    """100 inside [low, high]; falls to 0 at hard_low / hard_high."""
    if low <= value <= high:
        return 100.0
    if value < low:
        return _lin(value, low, hard_low)
    return _lin(value, high, hard_high)


def category_for(score):
    if score >= 85:
        return "Excellent"
    if score >= 70:
        return "Good"
    if score >= 50:
        return "Fair - Attention Advised"
    return "Poor - Inspection Advised"


def calculate_health(reading, weights=None):
    w = dict(DEFAULT_WEIGHTS)
    if weights:
        w.update(weights)
    total_w = sum(w.values()) or 1.0
    running = reading.get("turbine_status") == "Running"
    temp, eff = float(reading["temperature"]), float(reading["turbine_efficiency"])
    flow, head = float(reading["water_flow"]), float(reading["hydraulic_head"])

    sub = {
        "temperature": _lin(temp, 60, 90),
        "efficiency": _lin(eff, 90, 70),
        "flow": _band(flow, 30, 110, 10, 140),
        "head": _band(head, 40, 80, 25, 95),
        "status": 100.0 if running else 0.0,
    }
    if not running:           # a stopped turbine is not "healthy"
        sub["efficiency"] = 0.0

    rules = {
        "temperature": ("Temperature", f"{temp:.1f} °C", "Ideal up to 60 °C, poor at 90 °C",
                        "Check cooling system and bearing lubrication"),
        "efficiency": ("Turbine efficiency", f"{eff:.1f} %", "Ideal 90 % and above, poor at 70 %",
                       "Inspect runner/blades for wear or deposits"),
        "flow": ("Water flow", f"{flow:.1f} m3/s", "Ideal band 30-110 m3/s",
                 "Check intake gates, screens and flow sensor"),
        "head": ("Hydraulic head", f"{head:.1f} m", "Ideal band 40-80 m",
                 "Verify level/head sensors and penstock condition"),
        "status": ("Turbine status", reading.get("turbine_status", "Unknown"), "Should be Running",
                   "Confirm whether the shutdown is planned; check start-up conditions"),
    }
    parameters, reasons, checks = [], [], []
    for key, (label, value, rule, check) in rules.items():
        s = sub[key]
        state = "Good" if s >= 80 else ("Watch" if s >= 50 else "Poor")
        parameters.append({"Parameter": label, "Value": value, "Score (0-100)": round(s, 1),
                           "Weight": f"{w[key] / total_w * 100:.0f}%", "State": state,
                           "Rule": rule})
        if s < 80:
            reasons.append(f"{label} is {value} (score {s:.0f}/100). Rule: {rule}.")
            checks.append(check)

    score = sum(sub[k] * w[k] for k in sub) / total_w
    if not running:
        score = min(score, 40.0)
        reasons.append("Turbine is stopped, so the score is capped at 40.")
    score = round(float(score), 1)
    return {"score": score, "category": "Not Operating" if not running else category_for(score),
            "parameters": parameters, "reasons": reasons, "checks": checks}
