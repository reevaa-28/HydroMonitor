# sensor_simulator.py
# PURPOSE: Create SIMULATED hydropower sensor data.
#   1) generate_dataset()      -> big training dataset saved in data/hydro_data.csv
#   2) generate_next_reading() -> one new "live-looking" reading (used by the app)
# IMPORTANT: Nothing here comes from a real plant. It is synthetic data.

import os
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "data", "hydro_data.csv")

DATA_LABEL = "SIMULATED SENSOR DATA – NO PHYSICAL SENSORS CONNECTED"

RHO = 1000.0   # water density (kg/m3)
G = 9.81       # gravity (m/s2)
TIME_FORMAT = "%Y-%m-%d %H:%M:%S"

ABNORMAL_KINDS = [
    "High temperature",
    "Water flow surge",
    "Low turbine efficiency",
    "Level / head mismatch",
]


def calculate_power(flow, head, efficiency_percent, running):
    """Hydropower equation: P = (rho * g * Q * H * eta) / 1,000,000  (result in MW).
    A stopped turbine gives 0 MW."""
    power = RHO * G * np.asarray(flow, dtype=float) * np.asarray(head, dtype=float) \
        * (np.asarray(efficiency_percent, dtype=float) / 100.0) / 1_000_000
    power = np.where(np.asarray(running, dtype=bool), power, 0.0)
    return float(power) if power.ndim == 0 else power


def efficiency_from_flow(flow):
    """Turbines are most efficient near their design flow (~70 m3/s here)."""
    return 93.0 - 0.0012 * (np.asarray(flow, dtype=float) - 70.0) ** 2


def head_from_level(level):
    """Hydraulic head is roughly the reservoir level minus the turbine level."""
    return 0.85 * (np.asarray(level, dtype=float) - 90.0)


def temperature_from_flow(flow):
    """Machine temperature rises a little with load."""
    return 40.0 + 0.12 * np.asarray(flow, dtype=float)


def generate_dataset(n_records=6000, seed=42, save=True):
    """Create a synthetic hourly dataset with realistic relationships."""
    rng = np.random.default_rng(seed)
    end = datetime.now().replace(minute=0, second=0, microsecond=0)
    times = [end - timedelta(hours=n_records - i) for i in range(n_records)]

    rows = []
    level_noise = 0.0
    stop_left = 0
    for t in times:
        day = t.timetuple().tm_yday
        season = np.sin(2 * np.pi * (day - 170) / 365.0)      # monsoon-like cycle
        rain_prob = 0.10 + 0.20 * max(season, 0)
        rainfall = rng.exponential(6.0) if rng.random() < rain_prob else 0.0

        level_noise = 0.95 * level_noise + rng.normal(0, 0.6)  # slow changes
        level = float(np.clip(158 + 12 * season + level_noise, 135, 185))
        head = float(head_from_level(level) + rng.normal(0, 0.6))

        flow = 62 + 25 * season + 8 * np.sin(2 * np.pi * t.hour / 24) \
            + 0.5 * rainfall + rng.normal(0, 6)
        flow = float(np.clip(flow, 15, 125))

        # turbine stops occasionally (maintenance blocks of 6-48 hours)
        if stop_left == 0 and rng.random() < 0.0015:
            stop_left = int(rng.integers(6, 49))
        if stop_left > 0:
            stop_left -= 1
            status = "Stopped"
            flow = float(rng.uniform(0, 2))
            eff = 0.0
            temp = float(rng.normal(31, 2))
        else:
            status = "Running"
            eff = float(np.clip(efficiency_from_flow(flow) + rng.normal(0, 0.8), 80, 95))
            temp = float(temperature_from_flow(flow) + 4 * np.sin(2 * np.pi * t.hour / 24)
                         + rng.normal(0, 1.2))

        power = calculate_power(flow, head, eff, status == "Running")
        rows.append([t.strftime(TIME_FORMAT), round(flow, 2), round(level, 2), round(head, 2),
                     round(temp, 2), round(rainfall, 2), round(eff, 2), status, round(power, 3)])

    df = pd.DataFrame(rows, columns=[
        "timestamp", "water_flow", "water_level", "hydraulic_head", "temperature",
        "rainfall", "turbine_efficiency", "turbine_status", "simulated_power"])
    if save:
        os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)
        df.to_csv(DATA_PATH, index=False)
    return df


def ensure_dataset():
    """Create data/hydro_data.csv if it does not exist, then load it."""
    if not os.path.exists(DATA_PATH):
        generate_dataset()
    return pd.read_csv(DATA_PATH)


def default_state():
    """Starting values when the database has no reading yet."""
    return {"water_flow": 65.0, "water_level": 158.0, "hydraulic_head": 57.8,
            "temperature": 48.0, "rainfall": 0.0, "turbine_efficiency": 92.5,
            "turbine_status": "Running"}


def generate_next_reading(previous=None, timestamp=None, rng=None):
    """Make the next simulated reading as a small random change from the previous one."""
    rng = rng or np.random.default_rng()
    prev = previous if previous else default_state()
    timestamp = timestamp or datetime.now()

    flow_prev = max(float(prev["water_flow"]), 20.0)
    level_prev = float(prev["water_level"])

    rainfall = float(rng.exponential(4.0)) if rng.random() < 0.3 else 0.0
    flow = flow_prev + 0.1 * (65 - flow_prev) + rng.normal(0, 3.5) + 0.2 * rainfall
    flow = float(np.clip(flow, 20, 120))
    level = float(np.clip(level_prev + 0.1 * (158 - level_prev) + rng.normal(0, 0.5), 138, 182))
    head = float(head_from_level(level) + rng.normal(0, 0.6))

    status = prev.get("turbine_status", "Running")
    if status == "Running" and rng.random() < 0.005:
        status = "Stopped"
    elif status == "Stopped" and rng.random() < 0.3:
        status = "Running"

    if status == "Running":
        eff = float(np.clip(efficiency_from_flow(flow) + rng.normal(0, 0.8), 80, 95))
        temp = float(temperature_from_flow(flow) + rng.normal(0, 1.0))
    else:
        flow, eff, temp = float(rng.uniform(0, 2)), 0.0, float(rng.normal(31, 1.5))

    return _finish(timestamp, flow, level, head, temp, rainfall, eff, status, "SIMULATED")


def generate_abnormal_reading(kind, previous=None, timestamp=None):
    """Controlled ABNORMAL test reading, used to demonstrate anomaly detection."""
    base = generate_next_reading(previous, timestamp)
    base.update({"turbine_status": "Running"})
    flow, level, head = 70.0, 158.0, 57.8
    temp, eff, rain = 52.0, 92.0, 0.0
    if kind == "High temperature":
        temp = 96.0
    elif kind == "Water flow surge":
        flow = 150.0
    elif kind == "Low turbine efficiency":
        eff = 58.0
    else:  # Level / head mismatch
        level, head = 175.0, 40.0
    return _finish(base["timestamp"], flow, level, head, temp, rain, eff, "Running",
                   f"SIMULATED (abnormal test: {kind})", parse=False)


def _finish(timestamp, flow, level, head, temp, rain, eff, status, source, parse=True):
    if isinstance(timestamp, datetime):
        timestamp = timestamp.strftime(TIME_FORMAT)
    power = calculate_power(flow, head, eff, status == "Running")
    return {"timestamp": timestamp, "water_flow": round(flow, 2), "water_level": round(level, 2),
            "hydraulic_head": round(head, 2), "temperature": round(temp, 2),
            "rainfall": round(rain, 2), "turbine_efficiency": round(eff, 2),
            "turbine_status": status, "simulated_power": round(power, 3),
            "data_source": source}


if __name__ == "__main__":
    data = generate_dataset()
    print(DATA_LABEL)
    print("Records created:", len(data))
    print(data.head())
    print(data.describe().round(2))
