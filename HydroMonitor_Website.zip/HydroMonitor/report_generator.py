# report_generator.py
# PURPOSE: Build a downloadable PDF report (ReportLab) and a CSV export for a date range.

import io
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                Image, PageBreak)

import database
from train_model import evaluate_models
from sensor_simulator import DATA_LABEL

PURPLE = colors.HexColor("#8050C8")
DARK = colors.HexColor("#5B328F")
LIGHT = colors.HexColor("#E9DDF8")


def readings_csv(start, end):
    """CSV text of sensor readings (with RF prediction) for the date range."""
    df = database.get_readings(start, end)
    if df.empty:
        return None
    pred = database.get_predictions(start, end)
    if not pred.empty:
        for name, col in [("Linear Regression", "linear_pred_mw"), ("Random Forest", "forest_pred_mw")]:
            p = pred[pred["model_name"] == name][["reading_id", "predicted_power"]]
            p = p.drop_duplicates("reading_id").rename(columns={"predicted_power": col})
            df = df.merge(p, left_on="id", right_on="reading_id", how="left").drop(columns="reading_id")
    return df.to_csv(index=False)


def _chart(df, column, title, ylabel, color="#8050C8"):
    fig, ax = plt.subplots(figsize=(7, 2.6))
    ax.plot(df["timestamp"], df[column], color=color, lw=1.6)
    ax.set_title(title, fontsize=10, color="#5B328F"); ax.set_ylabel(ylabel, fontsize=8)
    step = max(1, len(df) // 6)
    ax.set_xticks(range(0, len(df), step))
    ax.set_xticklabels([t[5:16] for t in df["timestamp"].iloc[::step]], fontsize=7, rotation=20)
    ax.grid(alpha=0.25)
    fig.tight_layout()
    buf = io.BytesIO(); fig.savefig(buf, format="png", dpi=130); plt.close(fig); buf.seek(0)
    return Image(buf, width=16 * cm, height=5.9 * cm)


def _table(data, col_widths=None, font=8):
    t = Table(data, colWidths=col_widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), DARK), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("FONTSIZE", (0, 0), (-1, -1), font),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F7F5FA")]),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#CFC7DA")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
    return t


def build_pdf(start, end):
    """Return PDF bytes. Raises ValueError if there are no readings in the range."""
    readings = database.get_readings(start, end)
    if readings.empty:
        raise ValueError("No sensor readings found in the selected date range.")

    styles = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=styles["Heading1"], textColor=DARK, fontSize=15)
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], textColor=PURPLE, fontSize=12)
    body = ParagraphStyle("b", parent=styles["Normal"], fontSize=9, leading=12)
    small = ParagraphStyle("s", parent=styles["Normal"], fontSize=7.5, textColor=colors.grey)
    cell = ParagraphStyle("c", parent=styles["Normal"], fontSize=7.5, leading=9)

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm,
                            topMargin=1.8 * cm, bottomMargin=1.8 * cm,
                            title="HydroMonitor Report")
    s = []
    s.append(Paragraph("HydroMonitor", ParagraphStyle("t", parent=styles["Title"], textColor=DARK)))
    s.append(Paragraph("ML-Based Hydropower Plant Monitoring and Power Generation Prediction", body))
    s.append(Spacer(1, 6))
    s.append(Paragraph(f"<b>{DATA_LABEL}</b>", ParagraphStyle("d", parent=body, textColor=PURPLE)))
    s.append(Spacer(1, 6))
    s.append(_table([["Report generated", datetime.now().strftime("%Y-%m-%d %H:%M")],
                     ["Selected date range", f"{start} to {end}"],
                     ["Readings in range", str(len(readings))]],
                    [5 * cm, 11 * cm], 9))

    # --- 1 sensor summary
    s.append(Paragraph("1. Sensor Readings Summary (simulated)", h2))
    cols = [("water_flow", "Water flow (m3/s)"), ("water_level", "Water level (m)"),
            ("hydraulic_head", "Hydraulic head (m)"), ("temperature", "Temperature (C)"),
            ("rainfall", "Rainfall (mm)"), ("turbine_efficiency", "Efficiency (%)"),
            ("simulated_power", "Simulated power (MW)")]
    rows = [["Parameter", "Mean", "Min", "Max", "Latest"]]
    for c, label in cols:
        rows.append([label, f"{readings[c].mean():.2f}", f"{readings[c].min():.2f}",
                     f"{readings[c].max():.2f}", f"{readings[c].iloc[-1]:.2f}"])
    s.append(_table(rows, [5.5 * cm, 2.6 * cm, 2.6 * cm, 2.6 * cm, 2.6 * cm]))
    stopped = int((readings["turbine_status"] != "Running").sum())
    s.append(Spacer(1, 4))
    s.append(Paragraph(f"Turbine stopped in {stopped} of {len(readings)} readings.", body))

    # --- 2 predictions
    s.append(Paragraph("2. Power Generation Predictions", h2))
    pred = database.get_predictions(start, end)
    if pred.empty:
        s.append(Paragraph("No stored predictions in this range.", body))
    else:
        rows = [["Model", "Predictions", "Mean MW", "Min MW", "Max MW", "Avg lower", "Avg upper"]]
        for name, g in pred.groupby("model_name"):
            rows.append([name, str(len(g)), f"{g.predicted_power.mean():.2f}",
                         f"{g.predicted_power.min():.2f}", f"{g.predicted_power.max():.2f}",
                         f"{g.lower_estimate.mean():.2f}", f"{g.upper_estimate.mean():.2f}"])
        s.append(_table(rows))
        s.append(Paragraph("Lower/upper values are estimated uncertainty ranges, not guarantees.", small))

    # --- 3 model comparison
    s.append(Paragraph("3. Linear Regression vs Random Forest (held-out test data)", h2))
    ev = evaluate_models()
    rows = [["Model", "MAE", "RMSE", "R2", "Est. Accuracy (%) - Normalized MAE"]]
    for name, m in ev["metrics"].items():
        rows.append([name, f"{m['MAE']:.4f}", f"{m['RMSE']:.4f}", f"{m['R2']:.4f}",
                     f"{m['EstAccuracy']:.2f}"])
    s.append(_table(rows, [3.5 * cm, 2.2 * cm, 2.2 * cm, 2.2 * cm, 6.9 * cm]))
    s.append(Paragraph("Metrics are computed on synthetic data generated from the hydropower "
                       "equation, so scores are high and do not represent real-plant accuracy. "
                       "The accuracy estimate is a project-defined value, not classification accuracy.",
                       small))

    # --- 4 anomalies
    s.append(Paragraph("4. Anomaly Detection Summary", h2))
    an = database.get_anomalies(False, start, end)
    n_an = int((an["status"] == "Anomaly").sum()) if not an.empty else 0
    s.append(Paragraph(f"Readings checked: {len(an)}. Anomalies flagged: {n_an}. "
                       "An anomaly means 'unusual reading', not automatic equipment failure.", body))
    if n_an:
        rows = [["Time", "Score", "Affected", "Explanation"]]
        for _, r in an[an.status == "Anomaly"].head(8).iterrows():
            rows.append([r.timestamp, f"{r.anomaly_score:.3f}", Paragraph(r.affected_parameters or "-", cell),
                         Paragraph(r.explanation[:170], cell)])
        s.append(_table(rows, [3.2 * cm, 1.5 * cm, 3 * cm, 9.3 * cm]))

    # --- 5 health
    s.append(Paragraph("5. Turbine Health Summary (illustrative score)", h2))
    hl = database.get_health(start, end)
    if hl.empty:
        s.append(Paragraph("No health records in this range.", body))
    else:
        cats = hl["category"].value_counts().to_dict()
        s.append(Paragraph(f"Average score: {hl.health_score.mean():.1f}/100; lowest: "
                           f"{hl.health_score.min():.1f}; latest: {hl.health_score.iloc[0]:.1f} "
                           f"({hl.category.iloc[0]}). Categories: "
                           + ", ".join(f"{k}: {v}" for k, v in cats.items())
                           + ". This is an academic monitoring score, not a certified diagnosis.", body))

    # --- 6 alerts
    s.append(Paragraph("6. Alerts", h2))
    al = database.get_alerts(None, start, end)
    if al.empty:
        s.append(Paragraph("No alerts in this range.", body))
    else:
        s.append(Paragraph(f"Total: {len(al)} | Warning: {(al.severity == 'Warning').sum()} | "
                           f"Critical: {(al.severity == 'Critical').sum()} | "
                           f"Unacknowledged: {(al.acknowledged == 0).sum()}", body))
        rows = [["Time", "Severity", "Parameter", "Message"]]
        for _, r in al.head(12).iterrows():
            rows.append([r.timestamp, r.severity, Paragraph(r.parameter, cell), Paragraph(r.message[:150], cell)])
        s.append(_table(rows, [3.2 * cm, 1.8 * cm, 3 * cm, 9 * cm]))
        s.append(Paragraph("Thresholds are academic demonstration values, not certified safety limits.", small))

    # --- 7 charts
    s.append(PageBreak())
    s.append(Paragraph("7. Historical Charts", h2))
    s.append(_chart(readings, "simulated_power", "Simulated power generation", "MW"))
    s.append(_chart(readings, "water_flow", "Water flow", "m3/s", "#5DA9E9"))
    s.append(_chart(readings, "temperature", "Temperature", "deg C", "#C0392B"))
    s.append(Spacer(1, 6))
    s.append(Paragraph("Simulated power is calculated by the simulator from the hydropower equation; "
                       "it is not an independently measured actual value.", small))
    doc.build(s)
    return buf.getvalue()
