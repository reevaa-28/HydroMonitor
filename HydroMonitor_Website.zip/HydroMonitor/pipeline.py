# pipeline.py  (small supporting file)
# PURPOSE: Connects ALL modules in the order described in the project flow:
#   reading -> database -> prediction -> uncertainty -> anomaly -> health -> alerts -> save.

import numpy as np
from datetime import datetime, timedelta

import database
import sensor_simulator as sim
import train_model
import anomaly_detection
import prediction
import prediction_confidence as pconf
import turbine_health
import alert_manager


def initialize():
    """Steps 2-6 of the execution flow. Safe to call many times."""
    database.init_db()
    sim.ensure_dataset()
    train_model.ensure_models()
    anomaly_detection.ensure_anomaly_model()
    prediction.load_models()
    anomaly_detection.load_bundle()
    return True


def process_reading(reading, thresholds=None, weights=None):
    """Run one reading through the whole pipeline and save every result."""
    reading_id = database.insert_reading(reading)
    ts = reading["timestamp"]

    results = {}
    for name in train_model.MODEL_NAMES:
        r = pconf.predict_with_interval(reading, name)
        database.save_prediction(reading_id, name, r["prediction"], r["lower"], r["upper"], ts)
        results[name] = r

    anomaly = anomaly_detection.detect_anomaly(reading)
    database.save_anomaly(reading_id, anomaly["status"], anomaly["score"],
                          ", ".join(anomaly["affected"]), anomaly["explanation"], ts)

    health = turbine_health.calculate_health(reading, weights)
    database.save_health(reading_id, health["score"], health["category"],
                         " | ".join(health["reasons"]), ts)

    alerts = alert_manager.check_reading(reading, anomaly, thresholds)
    alert_manager.save_alerts(reading_id, alerts, ts)

    return {"reading_id": reading_id, "reading": reading, "predictions": results,
            "anomaly": anomaly, "health": health, "alerts": alerts}


def generate_and_process(abnormal_kind=None, thresholds=None, weights=None):
    previous = database.get_latest_reading()
    if abnormal_kind:
        reading = sim.generate_abnormal_reading(abnormal_kind, previous)
    else:
        reading = sim.generate_next_reading(previous)
    return process_reading(reading, thresholds, weights)


def generate_history(n=24, step_minutes=60, thresholds=None, weights=None):
    """Create n readings spread over the past (handy for demos). Each goes through the pipeline."""
    previous = database.get_latest_reading()
    rng = np.random.default_rng()
    now = datetime.now()
    count = 0
    for i in range(n, 0, -1):
        ts = now - timedelta(minutes=step_minutes * i)
        reading = sim.generate_next_reading(previous, ts, rng)
        process_reading(reading, thresholds, weights)
        previous = reading
        count += 1
    return count
