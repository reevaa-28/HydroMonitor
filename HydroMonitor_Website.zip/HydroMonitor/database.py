# database.py
# PURPOSE: ALL SQLite code lives here. Other files call these functions
# instead of writing SQL themselves. The database file is permanent:
# database/hydromonitor.db  (it is NOT deleted when the app closes).

import os
import sqlite3
import pandas as pd
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "database", "hydromonitor.db")


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    return sqlite3.connect(DB_PATH)


def init_db():
    """Create the 7 tables if they do not exist yet."""
    conn = get_connection()
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS sensor_readings (
        id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT, water_flow REAL,
        water_level REAL, hydraulic_head REAL, temperature REAL, rainfall REAL,
        turbine_efficiency REAL, turbine_status TEXT, simulated_power REAL, data_source TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS predictions (
        id INTEGER PRIMARY KEY AUTOINCREMENT, reading_id INTEGER, timestamp TEXT,
        model_name TEXT, predicted_power REAL, lower_estimate REAL, upper_estimate REAL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT, reading_id INTEGER,
        parameter TEXT, message TEXT, severity TEXT, acknowledged INTEGER DEFAULT 0)""")
    c.execute("""CREATE TABLE IF NOT EXISTS anomaly_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT, reading_id INTEGER, timestamp TEXT,
        status TEXT, anomaly_score REAL, affected_parameters TEXT, explanation TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS turbine_health (
        id INTEGER PRIMARY KEY AUTOINCREMENT, reading_id INTEGER, timestamp TEXT,
        health_score REAL, category TEXT, details TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS forecast_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, forecast_time TEXT,
        horizon_hours INTEGER, scenario TEXT, linear_power REAL, forest_power REAL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS model_metrics (
        id INTEGER PRIMARY KEY AUTOINCREMENT, trained_at TEXT, model_name TEXT,
        mae REAL, mse REAL, rmse REAL, r2 REAL, est_accuracy REAL)""")
    conn.commit()
    conn.close()


def _run(sql, params=()):
    """Run an INSERT/UPDATE and return the new row id."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(sql, params)
    conn.commit()
    new_id = cur.lastrowid
    conn.close()
    return new_id


def _query(sql, params=()):
    conn = get_connection()
    df = pd.read_sql_query(sql, conn, params=params)
    conn.close()
    return df


def _date_filter(start, end, column="timestamp"):
    """Build a 'WHERE' piece for a date range (dates as 'YYYY-MM-DD')."""
    clauses, params = [], []
    if start:
        clauses.append(f"{column} >= ?")
        params.append(f"{start} 00:00:00")
    if end:
        clauses.append(f"{column} <= ?")
        params.append(f"{end} 23:59:59")
    where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
    return where, params


# ---------------- sensor readings ----------------
def insert_reading(r):
    return _run("""INSERT INTO sensor_readings (timestamp, water_flow, water_level, hydraulic_head,
        temperature, rainfall, turbine_efficiency, turbine_status, simulated_power, data_source)
        VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (r["timestamp"], r["water_flow"], r["water_level"], r["hydraulic_head"],
                 r["temperature"], r["rainfall"], r["turbine_efficiency"], r["turbine_status"],
                 r["simulated_power"], r.get("data_source", "SIMULATED")))


def get_readings(start=None, end=None, limit=None):
    """Return readings oldest -> newest. If limit is given, the LATEST `limit` rows."""
    where, params = _date_filter(start, end)
    if limit:
        df = _query(f"SELECT * FROM sensor_readings{where} ORDER BY timestamp DESC, id DESC LIMIT ?",
                    params + [int(limit)])
        return df.iloc[::-1].reset_index(drop=True)
    return _query(f"SELECT * FROM sensor_readings{where} ORDER BY timestamp ASC, id ASC", params)


def get_latest_reading():
    df = _query("SELECT * FROM sensor_readings ORDER BY timestamp DESC, id DESC LIMIT 1")
    return None if df.empty else df.iloc[0].to_dict()


def count_readings():
    return int(_query("SELECT COUNT(*) AS n FROM sensor_readings")["n"][0])


# ---------------- predictions ----------------
def save_prediction(reading_id, model_name, predicted, lower=None, upper=None, timestamp=None):
    return _run("""INSERT INTO predictions (reading_id, timestamp, model_name, predicted_power,
        lower_estimate, upper_estimate) VALUES (?,?,?,?,?,?)""",
                (reading_id, timestamp or _now(), model_name, predicted, lower, upper))


def get_predictions(start=None, end=None, limit=None):
    where, params = _date_filter(start, end)
    sql = f"SELECT * FROM predictions{where} ORDER BY timestamp DESC, id DESC"
    if limit:
        sql += " LIMIT ?"
        params = params + [int(limit)]
    return _query(sql, params)


def get_latest_prediction(model_name="Random Forest"):
    df = _query("SELECT * FROM predictions WHERE model_name = ? AND reading_id IS NOT NULL "
                "ORDER BY id DESC LIMIT 1", (model_name,))
    return None if df.empty else df.iloc[0].to_dict()


# ---------------- alerts ----------------
def save_alert(reading_id, parameter, message, severity, timestamp=None):
    return _run("""INSERT INTO alerts (timestamp, reading_id, parameter, message, severity, acknowledged)
        VALUES (?,?,?,?,?,0)""", (timestamp or _now(), reading_id, parameter, message, severity))


def get_alerts(acknowledged=None, start=None, end=None, limit=None):
    where, params = _date_filter(start, end)
    if acknowledged is not None:
        where += (" AND " if where else " WHERE ") + "acknowledged = ?"
        params.append(int(acknowledged))
    sql = f"SELECT * FROM alerts{where} ORDER BY timestamp DESC, id DESC"
    if limit:
        sql += " LIMIT ?"
        params = params + [int(limit)]
    return _query(sql, params)


def acknowledge_alert(alert_id):
    _run("UPDATE alerts SET acknowledged = 1 WHERE id = ?", (int(alert_id),))


def acknowledge_all_alerts():
    _run("UPDATE alerts SET acknowledged = 1 WHERE acknowledged = 0")


# ---------------- anomalies ----------------
def save_anomaly(reading_id, status, score, affected, explanation, timestamp=None):
    return _run("""INSERT INTO anomaly_records (reading_id, timestamp, status, anomaly_score,
        affected_parameters, explanation) VALUES (?,?,?,?,?,?)""",
                (reading_id, timestamp or _now(), status, score, affected, explanation))


def get_anomalies(only_anomalies=False, start=None, end=None, limit=None):
    where, params = _date_filter(start, end)
    if only_anomalies:
        where += (" AND " if where else " WHERE ") + "status = 'Anomaly'"
    sql = f"SELECT * FROM anomaly_records{where} ORDER BY timestamp DESC, id DESC"
    if limit:
        sql += " LIMIT ?"
        params = params + [int(limit)]
    return _query(sql, params)


# ---------------- turbine health ----------------
def save_health(reading_id, score, category, details, timestamp=None):
    return _run("""INSERT INTO turbine_health (reading_id, timestamp, health_score, category, details)
        VALUES (?,?,?,?,?)""", (reading_id, timestamp or _now(), score, category, details))


def get_health(start=None, end=None, limit=None):
    where, params = _date_filter(start, end)
    sql = f"SELECT * FROM turbine_health{where} ORDER BY timestamp DESC, id DESC"
    if limit:
        sql += " LIMIT ?"
        params = params + [int(limit)]
    return _query(sql, params)


# ---------------- forecasts ----------------
def save_forecast(forecast_time, horizon, scenario, linear_power, forest_power):
    return _run("""INSERT INTO forecast_records (created_at, forecast_time, horizon_hours, scenario,
        linear_power, forest_power) VALUES (?,?,?,?,?,?)""",
                (_now(), forecast_time, int(horizon), scenario, linear_power, forest_power))


def get_forecasts(limit=50):
    return _query("SELECT * FROM forecast_records ORDER BY id DESC LIMIT ?", (int(limit),))


# ---------------- model metrics ----------------
def save_metrics(model_name, mae, mse, rmse, r2, est_accuracy):
    return _run("""INSERT INTO model_metrics (trained_at, model_name, mae, mse, rmse, r2, est_accuracy)
        VALUES (?,?,?,?,?,?,?)""", (_now(), model_name, mae, mse, rmse, r2, est_accuracy))


def get_metrics():
    return _query("SELECT * FROM model_metrics ORDER BY id DESC LIMIT 10")
