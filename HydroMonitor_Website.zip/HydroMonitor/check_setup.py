# check_setup.py - checks that libraries and folders are ready. Changes nothing.
import sys, os, platform
print("Python:", sys.version.split()[0], "| Machine:", platform.machine())
ok = True
for name in ["flask", "pandas", "numpy", "sklearn", "matplotlib", "joblib", "reportlab", "sqlite3"]:
    try:
        m = __import__(name); print(f"[OK]     {name:11s}", getattr(m, "__version__", "built-in"))
    except Exception as e:
        print(f"[FAILED] {name:11s}", e); ok = False
for f in ["data", "models", "database", "reports", "assets"]:
    exists = os.path.isdir(f); ok = ok and exists
    print(("[OK]     " if exists else "[MISSING] ") + "folder " + f)
print("RESULT:", "ready" if ok else "fix the lines marked FAILED/MISSING")
