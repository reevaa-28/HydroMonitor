# prediction_confidence.py
# PURPOSE: Give a prediction AND an estimated uncertainty range (lower / upper).
#  - Random Forest : look at how much the individual trees disagree.
#  - Linear Regression : use the typical errors (residuals) measured on held-out
#                        folds of the training data.
# The range is an ESTIMATE, not a guarantee.

import joblib
import numpy as np

from prediction import load_models, reading_to_frame
from train_model import CALIB_PATH, get_split, ensure_models

Z90 = 1.645   # about 90% range if tree predictions were roughly bell-shaped
_calib = {}


def _get_calibration():
    if not _calib:
        ensure_models()
        _calib.update(joblib.load(CALIB_PATH))
    return _calib


def interval_from_frame(X, model_name):
    """Return (prediction, lower, upper) arrays for a table of features X."""
    models = load_models()
    if model_name == "Random Forest":
        forest = models["Random Forest"]
        tree_preds = np.array([t.predict(X.values) for t in forest.estimators_])  # trees x rows
        mean, std = tree_preds.mean(axis=0), tree_preds.std(axis=0)
        lower, upper = mean - Z90 * std, mean + Z90 * std
    else:
        pred = models["Linear Regression"].predict(X)
        cal = _get_calibration()
        mean, lower, upper = pred, pred + cal["q05"], pred + cal["q95"]
    lower = np.clip(lower, 0, None)
    mean = np.clip(mean, 0, None)
    upper = np.maximum(upper, mean)
    return mean, lower, upper


def predict_with_interval(reading, model_name="Random Forest"):
    mean, lower, upper = interval_from_frame(reading_to_frame(reading), model_name)
    return {"model": model_name, "prediction": float(mean[0]),
            "lower": float(lower[0]), "upper": float(upper[0])}


def validate_on_test_set(model_name):
    """Check how often the TRUE (simulated) test value falls inside the estimated range."""
    _, X_test, _, y_test = get_split()
    mean, lower, upper = interval_from_frame(X_test, model_name)
    inside = (y_test.values >= lower) & (y_test.values <= upper)
    return {"coverage_percent": float(inside.mean() * 100),
            "average_width": float(np.mean(upper - lower)),
            "n_test": int(len(y_test)),
            "mean": mean, "lower": lower, "upper": upper, "actual": y_test.values}


METHOD_TEXT = {
    "Random Forest": ("The forest contains 150 trees. Each tree gives its own prediction. "
                      "We take the average as the final value and use the spread (standard "
                      "deviation) of the trees to build a range: average ± 1.645 × spread."),
    "Linear Regression": ("Linear Regression gives one number only, so we use its past mistakes. "
                          "Using 5-fold cross-validation on the training data, we collect the "
                          "errors (residuals) on rows the model did not see, and take their 5th "
                          "and 95th percentiles. Range = prediction + those two error values."),
}
LIMITATIONS = ("The range is an estimate based on synthetic data. It is not a guaranteed "
               "probability of correctness. The 'coverage' shown below is measured on held-out "
               "synthetic test rows and can differ on other data.")
