# anomaly_detection.py
# PURPOSE: Find unusual sensor readings using an Isolation Forest.
# Idea: unusual points are "easy to isolate" with random splits, so they get a LOW score.
# We add two simple safety rules (extreme value / level-head mismatch) next to the forest.

import os
import joblib
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from sensor_simulator import ensure_dataset, head_from_level

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ANOMALY_PATH = os.path.join(BASE_DIR, "models", "anomaly_model.pkl")
ANOMALY_FEATURES = ["water_flow", "water_level", "hydraulic_head", "temperature",
                    "turbine_efficiency"]
LABELS = {"water_flow": "water flow", "water_level": "water level",
          "hydraulic_head": "hydraulic head", "temperature": "temperature",
          "turbine_efficiency": "turbine efficiency"}
_cache = {}


def train_anomaly_model():
    """Train on RUNNING-turbine rows of the synthetic dataset and save with Joblib."""
    df = ensure_dataset()
    df = df[df["turbine_status"] == "Running"]
    X = df[ANOMALY_FEATURES]
    model = make_pipeline(StandardScaler(),
                          IsolationForest(n_estimators=200, contamination=0.01, random_state=42))
    model.fit(X)
    resid = df["hydraulic_head"] - head_from_level(df["water_level"])
    bundle = {"model": model,
              "mean": X.mean().to_dict(), "std": X.std().to_dict(),
              "head_resid_std": float(resid.std())}
    joblib.dump(bundle, ANOMALY_PATH)
    return bundle


def ensure_anomaly_model():
    if not os.path.exists(ANOMALY_PATH):
        train_anomaly_model()


def load_bundle():
    if not _cache:
        ensure_anomaly_model()
        _cache.update(joblib.load(ANOMALY_PATH))
    return _cache


def detect_anomaly(reading):
    """Return a dict: status, score, affected parameters, explanation."""
    if reading.get("turbine_status") != "Running":
        return {"status": "Normal", "score": 0.0, "affected": [],
                "explanation": "Turbine is stopped, so the detector (trained on running "
                               "readings) was not applied. A 'turbine stopped' alert is handled "
                               "separately."}
    b = load_bundle()
    import pandas as pd
    X = pd.DataFrame([{f: float(reading[f]) for f in ANOMALY_FEATURES}])
    score = float(b["model"].decision_function(X)[0])      # below 0 = anomaly
    is_anomaly = int(b["model"].predict(X)[0]) == -1

    # Extra safety rules (an Isolation Forest can miss a value that is far OUTSIDE the
    # training range in only one sensor), so we also use two simple checks:
    #   rule 1: any sensor more than 3.5 standard deviations from the training average
    #   rule 2: hydraulic head not consistent with water level
    rule_hit = False
    affected, notes = [], []
    for f in ANOMALY_FEATURES:
        z = (float(reading[f]) - b["mean"][f]) / b["std"][f]
        if abs(z) >= 3.5:
            rule_hit = True
        if abs(z) >= 3:
            affected.append(f)
            notes.append(f"{LABELS[f]} = {reading[f]} is unusually {'high' if z > 0 else 'low'} "
                         f"({z:+.1f} standard deviations from the training average)")
    expected_head = float(head_from_level(reading["water_level"]))
    if abs(float(reading["hydraulic_head"]) - expected_head) > 4 * b["head_resid_std"]:
        rule_hit = True
        for f in ("water_level", "hydraulic_head"):
            if f not in affected:
                affected.append(f)
        notes.append(f"hydraulic head ({reading['hydraulic_head']} m) does not match the "
                     f"water level ({reading['water_level']} m); about {expected_head:.1f} m "
                     f"was expected")

    if is_anomaly or rule_hit:
        if not notes:
            notes.append("no single value is extreme, but this COMBINATION of values is unusual "
                         "compared with the training data")
        text = ("Unusual reading detected: " + "; ".join(notes) +
                ". This does not automatically mean equipment failure; it is a reason to check.")
        return {"status": "Anomaly", "score": score, "affected": affected, "explanation": text}
    return {"status": "Normal", "score": score, "affected": [],
            "explanation": "Values look consistent with the normal training pattern."}


if __name__ == "__main__":
    train_anomaly_model()
    print("Anomaly model saved to", ANOMALY_PATH)
