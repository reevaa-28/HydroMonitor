# HydroMonitor – Project Guide for Viva and Demonstration

## A. Project in simple words
A hydropower plant turns falling water into electricity. We have no real sensors, so a **simulator** creates
realistic readings. The app **stores** them (SQLite), **predicts** power (ML), **flags** unusual readings,
**scores** turbine health, **estimates** future power, **shows** uncertainty, **raises** alerts and **reports** (PDF/CSV).
Every screen is labelled: *SIMULATED SENSOR DATA – NO PHYSICAL SENSORS CONNECTED*.

## B. Architecture and data flow
```
 sensor_simulator.py ──► reading ──► pipeline.py ──► database.py (SQLite)
                                        │
        ┌──────────────┬────────────────┼───────────────┬───────────────┐
 prediction.py   prediction_confidence  anomaly_detection  turbine_health  alert_manager
 (Linear / RF)   (lower / upper)        (Isolation Forest) (score 0-100)  (thresholds)
        └──────────────┴──────── results saved ──────────┴───────────────┘
 train_model.py ► models/*.pkl (Joblib)      forecasting.py (scenarios ► models)
 server.py (Flask API) + static/js (13 web pages) reads the database ► charts, digital_twin.py, report_generator.py
```
One reading: simulate → save → predict (2 models + range) → anomaly check → health score → alerts → save → display.

## C. Files and responsibilities
| File | Job |
|---|---|
| server.py | Flask routes (JSON API) |
| templates/, static/ | HTML, CSS, JavaScript front end |
| sensor_simulator.py | synthetic dataset + new readings + abnormal test readings |
| train_model.py | 80:20 split, trains/saves Linear + Random Forest, metrics |
| prediction.py | loads saved models, predicts MW |
| prediction_confidence.py | lower/upper ranges and validation |
| anomaly_detection.py | Isolation Forest + rules, explanation text |
| turbine_health.py | rule-based weighted health score |
| forecasting.py | 1/3/6/24 h scenario estimates |
| alert_manager.py | configurable thresholds, alerts |
| digital_twin.py | Matplotlib plant drawing |
| report_generator.py | PDF (ReportLab) + CSV |
| database.py | all SQLite functions |
| pipeline.py | connects the modules in order |

## D. ML explained simply
- **Linear Regression:** finds weights so that `power ≈ w1·flow + w2·level + … + b`. Like fitting the best straight line through points.
- **Random Forest:** many decision trees each answer with yes/no questions ("flow > 60?"); we average their answers. Handles curved relationships (power = flow × head × efficiency is a product, which a straight line only approximates).
- **Isolation Forest:** randomly cut the data; strange points get separated from the crowd in few cuts → low score → "Anomaly".
- **MAE** average absolute error (MW). **MSE** average squared error (punishes big errors). **RMSE** √MSE, in MW. **R²** share of variation explained (1 = perfect).
- **Feature importance:** how much each input helped the Random Forest's splits.
- **Uncertainty:** RF → disagreement between trees; Linear → typical past errors from cross-validation. An estimate, not a guarantee.
- **Estimated Regression Accuracy (%) – Normalized MAE** = 100 × (1 − MAE / (max − min of test target)). Project-defined, not classification accuracy.

## E. Viva questions and answers
1. **Why this project?** Combines ML, databases, visualization and web development on a real-world topic (renewable energy).
2. **Why is hydropower monitoring important?** Early notice of abnormal conditions, better planning and efficiency.
3. **Why Python?** Simple, with strong ML/data libraries.
4. **Why Flask + HTML/CSS/JS?** Flask exposes the Python ML code as a JSON API; the browser front end (HTML, CSS, JavaScript) gives full control over the design.
5. **Why SQLite?** Built into Python, file-based, permanent, no server needed.
6. **Why Linear Regression?** Simple, fast, easy to explain; a baseline.
7. **Why Random Forest?** Captures non-linear relations; usually more accurate; gives feature importance.
8. **Why Isolation Forest?** Works without labelled "faulty" data; finds unusual points.
9. **What is synthetic data?** Artificially generated data following rules; here created by a simulator.
10. **Simulated vs actual sensor data?** Simulated is computer-made; actual comes from physical instruments. We have only simulated.
11. **Why synthetic data?** No suitable public historical dataset was available.
12. **How is power calculated?** P = ρ·g·Q·H·η / 1,000,000 (MW).
13. **How do you evaluate models?** MAE, MSE, RMSE, R² on the 20% test set, computed from real predictions.
14. **Why are scores so high?** Data comes from the same equation the models learn. Real data would be noisier. We say this openly.
15. **Why not "accuracy"?** Accuracy is for classification; regression uses error metrics. We added a clearly labelled project estimate.
16. **Why the same test rows for both models?** Fair comparison.
17. **What is train/test split?** 80% to learn, 20% unseen to check. random_state=42 makes it repeatable.
18. **Why scale for Linear Regression only?** It is scale-sensitive; trees are not.
19. **What does the digital twin do?** Draws reservoir, penstock, turbine, generator from the latest reading; a software demo, not a plant link.
20. **How is turbine health calculated?** Per-parameter scores (temperature, efficiency, flow, head, status) × configurable weights; stopped turbine is capped at 40.
21. **Is it a real diagnosis?** No, an illustrative academic score.
22. **How does uncertainty work?** See D. Validation shows how often held-out test values fall inside the range.
23. **Does anomaly mean failure?** No, only "unusual; please check".
24. **Why rules next to Isolation Forest?** During testing the forest missed a temperature of 96 °C (far outside training range in one sensor), so we added two simple rules. Both are explained in the app.
25. **How does forecasting work?** Scenario → assumed future sensor values → models predict. Models are not time-series models, so these are scenario estimates.
26. **Are forecasts accurate?** They are not verified measurements; they depend on the scenario assumptions.
27. **How are alerts created?** Each reading is compared with configurable thresholds; severities Warning/Critical; stored and acknowledged.
28. **Are thresholds safety limits?** No, demonstration values.
29. **Why is predicted-vs-actual deviation not shown?** No independent actual measurement exists; simulated power is not independent.
30. **How is data kept after closing?** SQLite file `database/hydromonitor.db` on disk.
31. **How do you avoid retraining each rerun?** Models are saved with Joblib and loaded once; results of slow calculations are cached in memory.
32. **Limitations?** Synthetic data, scenario forecasts, rule-based health, demo thresholds, no real sensors.
33. **Future scope?** Real sensors/SCADA, real historical datasets, LSTM/ARIMA, live APIs, notifications.
34. **What is Joblib?** Saves/loads Python objects (trained models) to files.
35. **What does the pipeline file do?** Runs all steps for one reading in the right order.

## F. Demonstration script (5–8 minutes)
1. `python server.py`; say the disclaimer banner out loud.
2. **Sensor Monitoring** → "Add 24 demo readings", then "Generate new reading"; show cards and history.
3. **Dashboard** → KPIs come from the database (point at total readings).
4. **Digital Twin** → generate a reading, show the picture update.
5. **Power Prediction** → latest reading, Predict with both models; mention the equation value.
6. **Model Comparison** → metrics, actual-vs-predicted, feature importance; mention why scores are high.
7. **Prediction Confidence** → range and coverage; explain it is an estimate.
8. **Anomaly Detection** → inject "High temperature"; show status, score, explanation.
9. **Alert Monitoring** → new alert appeared; click Acknowledge.
10. **Turbine Health** → score, reasons, checks.
11. **Future Forecast** → "Rising inflow", 24 h; explain scenario-based.
12. **Reports** → Generate PDF, download PDF and CSV. Close the app, reopen: data is still there.

## G. Future scope
Connect real sensors via SCADA/IoT (MQTT/OPC-UA) replacing `sensor_simulator.py`; retrain on verified
historical plant data; add time-series models; real-time weather/reservoir APIs; with true measured power,
enable the 10% predicted-vs-actual deviation alert already supported by `alert_manager.power_deviation()`.
