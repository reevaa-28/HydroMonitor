# digital_twin.py
# PURPOSE: Draw a software-based digital twin of a hydropower plant with Matplotlib.
# The drawing changes with the latest SIMULATED readings. No physical plant is connected.

import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, Polygon, FancyArrowPatch

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(BASE_DIR, "assets")
PURPLE, DARK, WATER = "#8050C8", "#5B328F", "#5DA9E9"

DISCLAIMER = ("This is a software-based digital twin DEMONSTRATION. It is drawn from simulated "
              "readings and is not connected to any physical plant.")


def draw_plant(reading=None, predicted_mw=None):
    """Return a Matplotlib figure. `reading` is a dict of sensor values (or None)."""
    fig, ax = plt.subplots(figsize=(11, 5.6))
    ax.set_xlim(0, 12); ax.set_ylim(0, 6.2); ax.axis("off")
    fig.patch.set_facecolor("#F7F5FA")
    ax.add_patch(Rectangle((0, 0), 12, 6.2, color="#F7F5FA"))

    level = float(reading["water_level"]) if reading else 158.0
    flow = float(reading["water_flow"]) if reading else 0.0
    running = (reading is not None and reading["turbine_status"] == "Running")

    # Hill + reservoir
    ax.add_patch(Polygon([[0, 0.6], [0, 5.6], [3.9, 5.6], [3.9, 0.6]], color="#CFC7DA"))
    fill = 0.15 + 0.85 * min(max((level - 135) / (185 - 135), 0), 1)   # fraction 0.15 .. 1
    top = 0.9 + 4.4 * fill * 0.95
    ax.add_patch(Rectangle((0.2, 0.9), 3.5, top - 0.9, color=WATER, alpha=0.9))
    ax.text(1.95, top + 0.12, f"Reservoir level: {level:.1f} m", ha="center",
            fontsize=10, color="#17131F", fontweight="bold")
    # Dam wall
    ax.add_patch(Polygon([[3.7, 0.9], [3.7, 5.6], [4.4, 5.6], [4.4, 0.9]], color="#6E6580"))
    ax.text(4.05, 5.75, "Dam", ha="center", fontsize=9, color="#17131F")

    # Penstock (pipe) from dam to turbine
    p1, p2 = (4.4, 2.3), (7.2, 1.5)
    ax.plot([p1[0], p2[0]], [p1[1], p2[1]], color="#4A4458", lw=18, solid_capstyle="round")
    ax.plot([p1[0], p2[0]], [p1[1], p2[1]], color=WATER if flow > 3 else "#D9D5DF", lw=11,
            solid_capstyle="round")
    ax.text(5.6, 2.25, "Penstock", ha="center", fontsize=9, rotation=-16, color="#17131F")
    n_arrows = int(min(5, max(0, flow // 25 + (1 if flow > 3 else 0))))
    for i in range(n_arrows):
        f = (i + 0.7) / (n_arrows + 0.4)
        x, y = p1[0] + f * (p2[0] - p1[0]), p1[1] + f * (p2[1] - p1[1])
        ax.add_patch(FancyArrowPatch((x - 0.18, y + 0.05), (x + 0.18, y - 0.05),
                                     arrowstyle="-|>", mutation_scale=12, color="white"))

    # Turbine
    tc = "#2E9E5B" if running else "#C0392B"
    ax.add_patch(Circle((7.8, 1.5), 0.75, color="#EFE9F7", ec=tc, lw=3))
    for ang in range(0, 360, 60):
        import math
        a = math.radians(ang + (20 if running else 0))
        ax.plot([7.8, 7.8 + 0.65 * math.cos(a)], [1.5, 1.5 + 0.65 * math.sin(a)], color=tc, lw=3)
    ax.text(7.8, 0.68, "Turbine", ha="center", fontsize=9, fontweight="bold")
    ax.text(7.8, 0.40, "RUNNING" if running else "STOPPED", ha="center", fontsize=9,
            fontweight="bold", color=tc)

    # Shaft + generator
    ax.plot([8.55, 9.2], [1.5, 1.5], color="#4A4458", lw=6)
    ax.add_patch(Rectangle((9.2, 0.95), 1.4, 1.1, color=PURPLE if running else "#9A93A6", ec=DARK, lw=2))
    ax.text(9.9, 1.5, "Generator", ha="center", va="center", fontsize=9, color="white",
            fontweight="bold")

    # Power line
    ax.plot([10.6, 11.6], [1.5, 2.6], color="#17131F", lw=2)
    ax.plot([11.6, 11.6], [0.6, 3.2], color="#17131F", lw=3)
    ax.plot([11.2, 12.0], [3.0, 3.0], color="#17131F", lw=3)
    ax.plot([11.3, 11.9], [2.5, 2.5], color="#17131F", lw=3)

    # Tailrace water
    ax.add_patch(Rectangle((5.5, 0.0), 6.4, 0.14, color=WATER))

    # Info panel
    power_text = f"{predicted_mw:.1f} MW" if predicted_mw is not None else "n/a"
    info = (f"Water flow: {flow:.1f} m³/s\n"
            f"Turbine: {'Running' if running else 'Stopped'}\n"
            f"Predicted power: {power_text}")
    ax.text(5.0, 4.9, info, fontsize=11, color="white", va="top", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.5", fc="#292333", ec=PURPLE, lw=2))
    ax.text(6.0, 6.0, "SIMULATED SENSOR DATA – NO PHYSICAL SENSORS CONNECTED", ha="center",
            fontsize=9, color="#5B328F", fontweight="bold")
    return fig


def create_static_assets():
    """Create assets/hydro_plant_diagram.png and assets/logo.png."""
    os.makedirs(ASSET_DIR, exist_ok=True)
    demo = {"water_level": 165, "water_flow": 70, "turbine_status": "Running"}
    fig = draw_plant(demo, 36.0)
    fig.savefig(os.path.join(ASSET_DIR, "hydro_plant_diagram.png"), dpi=110, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(2, 2))
    ax.axis("off"); fig.patch.set_alpha(0)
    ax.add_patch(Circle((0.5, 0.5), 0.45, color=PURPLE)); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.text(0.5, 0.5, "HM", ha="center", va="center", fontsize=32, color="white", fontweight="bold")
    fig.savefig(os.path.join(ASSET_DIR, "logo.png"), dpi=100, transparent=True)
    plt.close(fig)


if __name__ == "__main__":
    create_static_assets()
    print("Assets created in", ASSET_DIR)
