# prediction.py
# PURPOSE: Load the saved models and predict power generation (MW) for one reading.

import joblib
import pandas as pd

from train_model import (FEATURE_COLUMNS, LINEAR_PATH, FOREST_PATH, MODEL_NAMES,
                         ensure_models, prepare_features)

_cache = {}


def load_models():
    """Load models from disk once and remember them (no retraining, no repeated loading)."""
    if not _cache:
        ensure_models()
        _cache["Linear Regression"] = joblib.load(LINEAR_PATH)
        _cache["Random Forest"] = joblib.load(FOREST_PATH)
    return _cache


def reading_to_frame(reading):
    """Turn a dict of sensor values into a 1-row table with the 7 feature columns."""
    row = {c: reading[c] for c in FEATURE_COLUMNS}
    return prepare_features(pd.DataFrame([row]))


def predict_power(reading, model_name="Random Forest"):
    """Predict MW with one model. Negative values are clipped to 0."""
    model = load_models()[model_name]
    value = float(model.predict(reading_to_frame(reading))[0])
    return max(value, 0.0)


def predict_both(reading):
    return {name: predict_power(reading, name) for name in MODEL_NAMES}
