# server.py  -  HydroMonitor web server (Flask)
# Run with:  python server.py      then open  http://localhost:5000
#
# HOW IT WORKS (simple view)
#   Browser (HTML + CSS + JavaScript)  --JSON over HTTP-->  Flask routes (this file)
#   Flask routes call the SAME Python modules as before (database, pipeline, prediction ...).
#   So the machine-learning part is unchanged; only the front end is new.

import copy
import math
import os
import threading
import webbrowser
from datetime import date, timedelta

import numpy as np
import pandas as pd
from flask import Flask, Response, jsonify, render_template, request

import alert_manager
import database
import forecasting
import pipeline
import prediction
import prediction_confidence as pconf
import report_generator
import sensor_simulator as sim
import train_model
import turbine_health
from train_model import FEATURE_COLUMNS, MODEL_NAMES

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0          # always load the newest CSS/JS while developing

# Settings that the user can change in the browser (kept in memory, single-user demo app)
SETTINGS = {
    "thresholds": copy.deepcopy(alert_manager.DEFAULT_THRESHOLDS),
    "weights": dict(turbine_health.DEFAULT_WEIGHTS),
}

_eval_cache = {}          # model evaluation is slow-ish, so we do it once
_valid_cache = {}


# ----------------------------------------------------------------- helpers
def clean(obj):
    """Make any Python/NumPy/Pandas value safe for JSON (NaN -> None, numpy -> python)."""
    if isinstance(obj, pd.DataFrame):
        return clean(obj.to_dict("records"))
    if isinstance(obj, dict):
        return {str(k): clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return clean(obj.tolist())
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (float, np.floating)):
        return None if (math.isnan(obj) or math.isinf(obj)) else float(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def ok(payload):
    return jsonify(clean(payload))


def fail(message, code=400):
    return jsonify({"error": message}), code


def parse_inputs(raw):
    """Read the 7 model inputs from JSON and check they are numbers."""
    try:
        r = {k: float(raw[k]) for k in FEATURE_COLUMNS if k != "turbine_status"}
    except (KeyError, TypeError, ValueError):
        raise ValueError("Please enter a valid number in every input box.")
    r["turbine_status"] = "Running" if raw.get("turbine_status") == "Running" else "Stopped"
    return r


def date_args():
    start = request.args.get("start") or str(date.today() - timedelta(days=7))
    end = request.args.get("end") or str(date.today())
    return start, end


def sample_indices(n, k):
    """Pick at most k evenly spaced indices (keeps charts fast)."""
    return np.linspace(0, n - 1, min(n, k)).astype(int)


def startup():
    """Create database/dataset/models on first run and add demo readings if DB is empty."""
    pipeline.initialize()
    if database.count_readings() == 0:
        pipeline.generate_history(48, 60, SETTINGS["thresholds"], SETTINGS["weights"])


# ----------------------------------------------------------------- page
@app.route("/")
def index():
    return render_template("index.html")


# ----------------------------------------------------------------- meta
@app.route("/api/meta")
def api_meta():
    return ok({
        "label": sim.DATA_LABEL,
        "defaults": sim.default_state(),
        "abnormal_kinds": sim.ABNORMAL_KINDS,
        "models": MODEL_NAMES,
        "scenarios": list(forecasting.SCENARIOS.keys()),
        "horizons": forecasting.HORIZONS,
        "forecast_explanation": forecasting.EXPLANATION,
        "confidence_method": pconf.METHOD_TEXT,
        "confidence_limits": pconf.LIMITATIONS,
        "twin_disclaimer": ("This is a software-based digital twin DEMONSTRATION. It is drawn from "
                            "simulated readings and is not connected to any physical plant."),
        "health_weights": SETTINGS["weights"],
    })


# ----------------------------------------------------------------- dashboard + readings
@app.route("/api/dashboard")
def api_dashboard():
    latest = database.get_latest_reading()
    series = database.get_readings(limit=100)
    rf = database.get_latest_prediction("Random Forest")
    lin = database.get_latest_prediction("Linear Regression")
    health = database.get_health(limit=1)
    alerts = database.get_alerts(acknowledged=0)
    return ok({
        "count": database.count_readings(),
        "latest": latest,
        "prediction": rf, "prediction_linear": lin,
        "health": None if health.empty else health.iloc[0].to_dict(),
        "anomalies": len(database.get_anomalies(only_anomalies=True)),
        "alerts_open": len(alerts),
        "recent_alerts": alerts.head(5),
        "series": series[["timestamp", "simulated_power", "water_flow", "water_level",
                          "hydraulic_head", "temperature", "rainfall",
                          "turbine_efficiency"]],
    })


@app.route("/api/readings")
def api_readings():
    limit = request.args.get("limit", type=int)
    return ok({"readings": database.get_readings(limit=limit or 100),
               "latest": database.get_latest_reading()})


@app.route("/api/sim/next", methods=["POST"])
def api_sim_next():
    """Generate ONE new reading (normal or abnormal) and run the whole pipeline."""
    kind = (request.get_json(silent=True) or {}).get("kind")
    if kind and kind not in sim.ABNORMAL_KINDS:
        return fail("Unknown abnormal reading type.")
    res = pipeline.generate_and_process(kind, SETTINGS["thresholds"], SETTINGS["weights"])
    return ok(res)


@app.route("/api/sim/history", methods=["POST"])
def api_sim_history():
    n = int((request.get_json(silent=True) or {}).get("n", 24))
    n = max(1, min(n, 200))
    done = pipeline.generate_history(n, 60, SETTINGS["thresholds"], SETTINGS["weights"])
    return ok({"created": done})


# ----------------------------------------------------------------- prediction
@app.route("/api/predict", methods=["POST"])
def api_predict():
    body = request.get_json(silent=True) or {}
    model = body.get("model", "Random Forest")
    if model not in MODEL_NAMES:
        return fail("Unknown model.")
    try:
        inputs = parse_inputs(body.get("inputs", {}))
    except ValueError as e:
        return fail(str(e))
    res = pconf.predict_with_interval(inputs, model)
    both = prediction.predict_both(inputs)
    database.save_prediction(None, model, res["prediction"], res["lower"], res["upper"])
    formula = sim.calculate_power(inputs["water_flow"], inputs["hydraulic_head"],
                                  inputs["turbine_efficiency"], inputs["turbine_status"] == "Running")
    return ok({"result": res, "both": both, "formula": formula})


# ----------------------------------------------------------------- forecast
@app.route("/api/forecast", methods=["POST"])
def api_forecast():
    body = request.get_json(silent=True) or {}
    scenario = body.get("scenario")
    if scenario not in forecasting.SCENARIOS:
        return fail("Unknown scenario.")
    recent = database.get_readings(limit=12)
    if recent.empty:
        return fail("No sensor readings yet. Generate some readings first.")
    f = forecasting.forecast(recent, scenario)
    for _, r in f.iterrows():
        if int(r["hours_ahead"]) in forecasting.HORIZONS:
            database.save_forecast(r["forecast_time"].strftime("%Y-%m-%d %H:%M:%S"),
                                   int(r["hours_ahead"]), scenario,
                                   float(r["linear_power"]), float(r["forest_power"]))
    rows = [{"time": r["forecast_time"].strftime("%Y-%m-%d %H:%M"), "hours": int(r["hours_ahead"]),
             "linear": float(r["linear_power"]), "forest": float(r["forest_power"])}
            for _, r in f.iterrows()]
    return ok({"scenario": scenario, "rows": rows, "based_on": len(recent)})


@app.route("/api/forecast/saved")
def api_forecast_saved():
    return ok({"rows": database.get_forecasts(30)})


# ----------------------------------------------------------------- turbine health
def health_payload():
    latest = database.get_latest_reading()
    if not latest:
        return {"empty": True}
    h = turbine_health.calculate_health(latest, SETTINGS["weights"])
    hist = database.get_health(limit=100).iloc[::-1]
    return {"empty": False, "reading_time": latest["timestamp"], "health": h,
            "weights": SETTINGS["weights"],
            "history": hist[["timestamp", "health_score"]]}


@app.route("/api/health")
def api_health():
    return ok(health_payload())


@app.route("/api/health/weights", methods=["POST"])
def api_health_weights():
    w = (request.get_json(silent=True) or {}).get("weights", {})
    for k in SETTINGS["weights"]:
        if k in w:
            SETTINGS["weights"][k] = max(0.0, min(1.0, float(w[k])))
    return ok(health_payload())


# ----------------------------------------------------------------- anomalies
@app.route("/api/anomalies")
def api_anomalies():
    hist = database.get_anomalies(limit=200)
    return ok({"history": hist,
               "checked": len(hist),
               "count": int((hist.status == "Anomaly").sum()) if not hist.empty else 0})


# ----------------------------------------------------------------- history / reservoir
@app.route("/api/history")
def api_history():
    start, end = date_args()
    df = database.get_readings(start, end)
    return ok({"start": start, "end": end, "readings": df})


@app.route("/api/reservoir")
def api_reservoir():
    source = request.args.get("source", "stored")
    if source == "dataset":
        df = sim.ensure_dataset().tail(500).reset_index(drop=True)
    else:
        df = database.get_readings(limit=500)
    if len(df) < 5:
        return ok({"enough": False, "rows": len(df)})
    cols = ["water_flow", "water_level", "hydraulic_head", "rainfall", "simulated_power"]
    corr = df[cols].corr()["simulated_power"].drop("simulated_power")
    return ok({"enough": True, "rows": len(df),
               "data": df[["timestamp"] + cols], "corr": corr.round(3).to_dict()})


# ----------------------------------------------------------------- model comparison
@app.route("/api/models")
def api_models():
    if "ev" not in _eval_cache:
        _eval_cache["ev"] = train_model.evaluate_models()
    ev = _eval_cache["ev"]
    idx = sample_indices(len(ev["y_test"]), 400)
    y = ev["y_test"]
    return ok({
        "metrics": ev["metrics"], "n_test": ev["n_test"],
        "importance": ev["importance"],
        "actual": y[idx],
        "pred": {n: p[idx] for n, p in ev["predictions"].items()},
    })


# ----------------------------------------------------------------- confidence
@app.route("/api/confidence", methods=["POST"])
def api_confidence():
    body = request.get_json(silent=True) or {}
    model = body.get("model", "Random Forest")
    if model not in MODEL_NAMES:
        return fail("Unknown model.")
    if body.get("source") == "latest":
        reading = database.get_latest_reading()
        if not reading:
            return ok({"empty": True})
    else:
        try:
            reading = parse_inputs(body.get("inputs", {}))
        except ValueError as e:
            return fail(str(e))
    res = pconf.predict_with_interval(reading, model)

    if model not in _valid_cache:
        _valid_cache[model] = pconf.validate_on_test_set(model)
    v = _valid_cache[model]
    idx = np.argsort(v["mean"])[::6][:120]
    return ok({
        "empty": False, "result": res, "reading": {k: reading[k] for k in FEATURE_COLUMNS},
        "method": pconf.METHOD_TEXT[model],
        "validation": {"coverage": v["coverage_percent"], "width": v["average_width"],
                       "n_test": v["n_test"], "mean": v["mean"][idx], "lower": v["lower"][idx],
                       "upper": v["upper"][idx], "actual": v["actual"][idx]},
    })


# ----------------------------------------------------------------- alerts
@app.route("/api/alerts")
def api_alerts():
    al = database.get_alerts()
    return ok({
        "alerts": al.head(200),
        "total": len(al),
        "warning": int((al.severity == "Warning").sum()) if not al.empty else 0,
        "critical": int((al.severity == "Critical").sum()) if not al.empty else 0,
        "acknowledged": int((al.acknowledged == 1).sum()) if not al.empty else 0,
        "open": int((al.acknowledged == 0).sum()) if not al.empty else 0,
    })


@app.route("/api/alerts/<int:alert_id>/ack", methods=["POST"])
def api_alert_ack(alert_id):
    database.acknowledge_alert(alert_id)
    return ok({"done": True})


@app.route("/api/alerts/ack-all", methods=["POST"])
def api_alert_ack_all():
    database.acknowledge_all_alerts()
    return ok({"done": True})


@app.route("/api/thresholds", methods=["GET", "POST", "DELETE"])
def api_thresholds():
    if request.method == "DELETE":
        SETTINGS["thresholds"] = copy.deepcopy(alert_manager.DEFAULT_THRESHOLDS)
    elif request.method == "POST":
        incoming = (request.get_json(silent=True) or {}).get("thresholds", {})
        th = SETTINGS["thresholds"]
        try:
            for key, vals in th.items():
                if key not in incoming:
                    continue
                if isinstance(vals, dict):
                    for k in vals:
                        if k in incoming[key]:
                            vals[k] = float(incoming[key][k])
                else:
                    th[key] = float(incoming[key])
        except (TypeError, ValueError):
            return fail("Thresholds must be numbers.")
    return ok({"thresholds": SETTINGS["thresholds"], "names": alert_manager.NAMES,
               "units": alert_manager.UNITS})


# ----------------------------------------------------------------- reports
@app.route("/api/report/summary")
def api_report_summary():
    start, end = date_args()
    df = database.get_readings(start, end)
    return ok({"start": start, "end": end, "readings": len(df),
               "predictions": len(database.get_predictions(start, end)),
               "alerts": len(database.get_alerts(None, start, end))})


@app.route("/api/report/csv")
def api_report_csv():
    start, end = date_args()
    text = report_generator.readings_csv(start, end)
    if text is None:
        return fail("No readings in this date range.", 404)
    return Response(text, mimetype="text/csv", headers={
        "Content-Disposition": f"attachment; filename=hydromonitor_data_{start}_{end}.csv"})


@app.route("/api/report/pdf")
def api_report_pdf():
    start, end = date_args()
    try:
        pdf = report_generator.build_pdf(start, end)
    except ValueError as e:
        return fail(str(e), 404)
    os.makedirs(os.path.join(BASE_DIR, "reports"), exist_ok=True)
    name = f"hydromonitor_report_{start}_{end}.pdf"
    with open(os.path.join(BASE_DIR, "reports", name), "wb") as fh:
        fh.write(pdf)                                # also keep a copy in the reports folder
    return Response(pdf, mimetype="application/pdf", headers={
        "Content-Disposition": f"attachment; filename={name}"})


# ----------------------------------------------------------------- start
if __name__ == "__main__":
    print("Setting up database, dataset and models (first run takes 10-20 seconds)...")
    startup()
    url = "http://localhost:5000"
    print(f"\nHydroMonitor is running ->  {url}   (press Ctrl+C to stop)\n")
    if os.environ.get("HYDRO_NO_BROWSER") != "1":
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
