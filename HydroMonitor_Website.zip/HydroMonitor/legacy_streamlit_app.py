# app.py  -  HydroMonitor main Streamlit application (13 pages)
# Run with:  streamlit run app.py

import os
from datetime import date, timedelta

import numpy as np
import pandas as pd
import streamlit as st
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import database
import pipeline
import prediction
import prediction_confidence as pconf
import forecasting
import turbine_health
import alert_manager
import digital_twin
import report_generator
import sensor_simulator as sim
import train_model
from train_model import FEATURE_COLUMNS, MODEL_NAMES

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LABEL = sim.DATA_LABEL
PURPLE, DARK, LIGHTP, BLACK = "#8050C8", "#5B328F", "#E9DDF8", "#17131F"

st.set_page_config(page_title="HydroMonitor", page_icon="💧", layout="wide")


# ------------------------------------------------------------------ setup
@st.cache_resource(show_spinner="Setting up database, dataset and models (first run only)...")
def setup():
    pipeline.initialize()
    digital_twin.create_static_assets()
    return True


setup()


@st.cache_data(show_spinner="Evaluating models on the test set...")
def cached_evaluation():
    return train_model.evaluate_models()


@st.cache_data(show_spinner="Validating uncertainty ranges...")
def cached_validation(model_name):
    return pconf.validate_on_test_set(model_name)


@st.cache_data
def cached_dataset():
    return sim.ensure_dataset()


if "thresholds" not in st.session_state:
    import copy
    st.session_state.thresholds = copy.deepcopy(alert_manager.DEFAULT_THRESHOLDS)
if "weights" not in st.session_state:
    st.session_state.weights = dict(turbine_health.DEFAULT_WEIGHTS)
if "sim_running" not in st.session_state:
    st.session_state.sim_running = False

# ------------------------------------------------------------------ styling
st.markdown(f"""
<style>
[data-testid="stSidebar"] {{ background: {BLACK}; }}
[data-testid="stSidebar"] * {{ color: #FFFFFF !important; }}
[data-testid="stSidebar"] [data-testid="stRadio"] label {{ padding: 4px 6px; border-radius: 6px; }}
.stButton>button, .stDownloadButton>button {{ background: {PURPLE}; color: white; border: 0;
    border-radius: 8px; padding: 0.4rem 1rem; }}
.stButton>button:hover, .stDownloadButton>button:hover {{ background: {DARK}; color: white; }}
.mcard {{ background: #292333; border-left: 5px solid {PURPLE}; border-radius: 10px;
    padding: 14px 16px; margin-bottom: 10px; }}
.mcard .l {{ color: #B8ADC7; font-size: 0.78rem; text-transform: uppercase; letter-spacing: .04em; }}
.mcard .v {{ color: #FFFFFF; font-size: 1.55rem; font-weight: 700; }}
.mcard .s {{ color: #B8ADC7; font-size: 0.75rem; }}
.banner {{ background: {LIGHTP}; color: {DARK}; border-radius: 8px; padding: 8px 14px;
    font-weight: 700; font-size: 0.85rem; margin-bottom: 12px; }}
.note {{ background: #FFFFFF; border: 1px solid {LIGHTP}; border-left: 4px solid {PURPLE};
    border-radius: 8px; padding: 10px 14px; font-size: 0.9rem; margin: 8px 0; }}
.sev-Critical {{ color: #C0392B; font-weight: 700; }}
.sev-Warning {{ color: #D68910; font-weight: 700; }}
h1, h2, h3 {{ color: {DARK}; }}
</style>
""", unsafe_allow_html=True)


# ------------------------------------------------------------------ helpers
def header(title, subtitle=""):
    st.title(title)
    if subtitle:
        st.caption(subtitle)
    st.markdown(f'<div class="banner">{LABEL}</div>', unsafe_allow_html=True)


def card(label, value, sub=""):
    st.markdown(f'<div class="mcard"><div class="l">{label}</div><div class="v">{value}</div>'
                f'<div class="s">{sub}</div></div>', unsafe_allow_html=True)


def note(text):
    st.markdown(f'<div class="note">{text}</div>', unsafe_allow_html=True)


def line_plot(df, x, ys, title, ylabel, colors=None, height=3.2):
    fig, ax = plt.subplots(figsize=(8, height))
    colors = colors or [PURPLE, "#5DA9E9", "#C0392B", "#2E9E5B"]
    for i, y in enumerate(ys):
        ax.plot(df[x], df[y], label=y.replace("_", " ").title(), color=colors[i % 4], lw=1.8)
    ax.set_title(title, color=DARK); ax.set_ylabel(ylabel); ax.grid(alpha=0.25)
    step = max(1, len(df) // 6)
    ax.set_xticks(range(0, len(df), step))
    ax.set_xticklabels([str(t)[5:16] for t in df[x].iloc[::step]], rotation=20, fontsize=8)
    if len(ys) > 1:
        ax.legend()
    fig.tight_layout()
    st.pyplot(fig); plt.close(fig)


def empty_state(message="No sensor readings yet."):
    st.info(f"{message} Use the buttons below or open **Sensor Monitoring**.")
    c1, c2 = st.columns(2)
    if c1.button("Generate 1 reading", key=f"e1_{message}"):
        pipeline.generate_and_process(None, st.session_state.thresholds, st.session_state.weights)
        st.rerun()
    if c2.button("Generate 24 hourly demo readings", key=f"e24_{message}"):
        pipeline.generate_history(24, 60, st.session_state.thresholds, st.session_state.weights)
        st.rerun()


def latest_or_none():
    return database.get_latest_reading()


def manual_inputs(defaults, prefix):
    """Number inputs for the 7 features. Returns a dict."""
    c = st.columns(3)
    r = {}
    r["water_flow"] = c[0].number_input("Water flow (m³/s)", 0.0, 200.0, float(defaults["water_flow"]), key=prefix + "f")
    r["water_level"] = c[1].number_input("Water level (m)", 100.0, 220.0, float(defaults["water_level"]), key=prefix + "l")
    r["hydraulic_head"] = c[2].number_input("Hydraulic head (m)", 10.0, 120.0, float(defaults["hydraulic_head"]), key=prefix + "h")
    r["temperature"] = c[0].number_input("Temperature (°C)", 0.0, 150.0, float(defaults["temperature"]), key=prefix + "t")
    r["rainfall"] = c[1].number_input("Rainfall (mm)", 0.0, 200.0, float(defaults["rainfall"]), key=prefix + "r")
    r["turbine_efficiency"] = c[2].number_input("Turbine efficiency (%)", 0.0, 100.0, float(defaults["turbine_efficiency"]), key=prefix + "e")
    r["turbine_status"] = c[0].selectbox("Turbine status", ["Running", "Stopped"],
                                          index=0 if defaults["turbine_status"] == "Running" else 1,
                                          key=prefix + "s")
    return r


# ------------------------------------------------------------------ pages
def page_dashboard():
    header("Dashboard", "Overview of the simulated hydropower plant")
    latest = latest_or_none()
    if not latest:
        empty_state(); return
    pf = database.get_latest_prediction("Random Forest")
    health = database.get_health(limit=1)
    n_anom = len(database.get_anomalies(only_anomalies=True))
    n_alerts = len(database.get_alerts(acknowledged=0))

    c = st.columns(4)
    with c[0]: card("Total readings", database.count_readings(), "stored in SQLite")
    with c[1]: card("Water flow", f"{latest['water_flow']:.1f} m³/s", latest["timestamp"])
    with c[2]: card("Water level", f"{latest['water_level']:.1f} m")
    with c[3]: card("Hydraulic head", f"{latest['hydraulic_head']:.1f} m")
    c = st.columns(4)
    with c[0]: card("Temperature", f"{latest['temperature']:.1f} °C")
    with c[1]: card("Predicted generation", f"{pf['predicted_power']:.1f} MW" if pf else "n/a", "Random Forest")
    with c[2]:
        card("Turbine health", f"{health.health_score.iloc[0]:.0f}/100" if not health.empty else "n/a",
             health.category.iloc[0] if not health.empty else "")
    with c[3]: card("Anomalies / active alerts", f"{n_anom} / {n_alerts}", "total anomalies / unacknowledged alerts")

    df = database.get_readings(limit=100)
    a, b = st.columns(2)
    with a: line_plot(df, "timestamp", ["simulated_power"], "Power generation trend (simulated)", "MW")
    with b: line_plot(df, "timestamp", ["water_flow"], "Water flow trend", "m³/s", [ "#5DA9E9"])
    line_plot(df, "timestamp", ["temperature"], "Temperature trend", "°C", ["#C0392B"])


def page_twin():
    header("Digital Twin", "Software model of the plant, updated from the latest simulated reading")
    note(digital_twin.DISCLAIMER)
    latest = latest_or_none()
    if not latest:
        empty_state(); return
    pf = database.get_latest_prediction("Random Forest")
    fig = digital_twin.draw_plant(latest, pf["predicted_power"] if pf else None)
    st.pyplot(fig); plt.close(fig)
    c = st.columns(4)
    with c[0]: card("Reservoir level", f"{latest['water_level']:.1f} m")
    with c[1]: card("Water flow", f"{latest['water_flow']:.1f} m³/s")
    with c[2]: card("Turbine", latest["turbine_status"])
    with c[3]: card("Predicted power", f"{pf['predicted_power']:.1f} MW" if pf else "n/a")
    if st.button("Generate new reading and update twin"):
        pipeline.generate_and_process(None, st.session_state.thresholds, st.session_state.weights)
        st.rerun()
    st.markdown("**How it works:** water flows from the reservoir through the penstock, spins the "
                "turbine, which drives the generator. The picture changes with the latest values "
                "(water level, flow, running/stopped).")


@st.fragment(run_every=3)
def live_fragment():
    if st.session_state.sim_running:
        pipeline.generate_and_process(None, st.session_state.thresholds, st.session_state.weights)
    show_sensor_cards()


@st.fragment
def static_fragment():
    show_sensor_cards()


def show_sensor_cards():
    latest = latest_or_none()
    if not latest:
        st.info("No readings yet. Click 'Generate new reading'."); return
    st.caption(f"Latest reading time: {latest['timestamp']}  |  Source: {latest['data_source']}")
    c = st.columns(4)
    with c[0]: card("Water flow", f"{latest['water_flow']:.1f} m³/s")
    with c[1]: card("Water level", f"{latest['water_level']:.1f} m")
    with c[2]: card("Hydraulic head", f"{latest['hydraulic_head']:.1f} m")
    with c[3]: card("Temperature", f"{latest['temperature']:.1f} °C")
    c = st.columns(4)
    with c[0]: card("Rainfall", f"{latest['rainfall']:.1f} mm")
    with c[1]: card("Turbine efficiency", f"{latest['turbine_efficiency']:.1f} %")
    with c[2]: card("Turbine status", latest["turbine_status"])
    with c[3]: card("Simulated power", f"{latest['simulated_power']:.1f} MW", "from P = ρ·g·Q·H·η")


def page_sensors():
    header("Sensor Monitoring", "Simulated sensor readings")
    c = st.columns(4)
    if c[0].button("▶ Start simulation", disabled=st.session_state.sim_running):
        st.session_state.sim_running = True; st.rerun()
    if c[1].button("⏹ Stop simulation", disabled=not st.session_state.sim_running):
        st.session_state.sim_running = False; st.rerun()
    if c[2].button("Generate new reading"):
        pipeline.generate_and_process(None, st.session_state.thresholds, st.session_state.weights)
    if c[3].button("Add 24 demo readings"):
        pipeline.generate_history(24, 60, st.session_state.thresholds, st.session_state.weights)
        st.rerun()
    if st.session_state.sim_running:
        st.success("Simulation is RUNNING: a new reading is generated every 3 seconds.")
        live_fragment()
    else:
        st.caption("Simulation stopped.")
        static_fragment()

    df = database.get_readings(limit=100)
    if df.empty:
        return
    st.subheader("Sensor charts (latest 100)")
    a, b = st.columns(2)
    with a: line_plot(df, "timestamp", ["water_flow"], "Water flow (m³/s)", "m³/s", ["#5DA9E9"])
    with b: line_plot(df, "timestamp", ["water_level"], "Water level (m)", "m")
    a, b = st.columns(2)
    with a: line_plot(df, "timestamp", ["temperature"], "Temperature (°C)", "°C", ["#C0392B"])
    with b: line_plot(df, "timestamp", ["hydraulic_head"], "Hydraulic head (m)", "m", ["#2E9E5B"])
    st.subheader("Reading history")
    st.dataframe(df.sort_values("timestamp", ascending=False).head(50), hide_index=True)
    note("All values are generated by a software simulator. No physical sensors are connected.")


def page_prediction():
    header("Power Prediction", "Predict power generation (MW) with Linear Regression or Random Forest")
    latest = latest_or_none()
    default = latest if latest else sim.default_state()
    source = st.radio("Input source", ["Manual input", "Load latest sensor reading"], horizontal=True)
    if source == "Load latest sensor reading" and not latest:
        st.warning("No stored reading yet; showing default values."); 
    inputs = manual_inputs(default, "pp_" + ("l" if source.startswith("Load") else "m"))
    model_name = st.selectbox("Model", MODEL_NAMES)
    if st.button("Predict"):
        res = pconf.predict_with_interval(inputs, model_name)
        both = prediction.predict_both(inputs)
        database.save_prediction(None, model_name, res["prediction"], res["lower"], res["upper"])
        card(f"Predicted power ({model_name})", f"{res['prediction']:.2f} MW",
             f"estimated range {res['lower']:.2f} – {res['upper']:.2f} MW")
        formula = sim.calculate_power(inputs["water_flow"], inputs["hydraulic_head"],
                                      inputs["turbine_efficiency"], inputs["turbine_status"] == "Running")
        st.dataframe(pd.DataFrame({"Model": list(both.keys()), "Predicted MW": [round(v, 3) for v in both.values()]}),
                     hide_index=True)
        fig, ax = plt.subplots(figsize=(6, 2.6))
        ax.barh(list(both.keys()), list(both.values()), color=[PURPLE, DARK])
        ax.axvline(formula, color="#2E9E5B", ls="--", label=f"Equation value {formula:.2f} MW")
        ax.set_xlabel("MW"); ax.legend(); fig.tight_layout(); st.pyplot(fig); plt.close(fig)
        note("The dashed line is the physics equation P = ρ·g·Q·H·η for these inputs (used to create the "
             "synthetic data). It is shown for comparison only.")


def page_forecast():
    header("Future Forecast", "Scenario-based estimates of future power generation")
    note("<b>Important:</b> " + forecasting.EXPLANATION)
    readings = database.get_readings(limit=12)
    if readings.empty:
        empty_state(); return
    c = st.columns(2)
    scenario = c[0].selectbox("Future scenario", list(forecasting.SCENARIOS.keys()))
    horizon = c[1].selectbox("Time horizon (hours)", forecasting.HORIZONS, index=3)
    st.caption(f"Based on the average of the latest {len(readings)} stored readings.")
    if st.button("Generate forecast"):
        f = forecasting.forecast(readings, scenario)
        for _, r in f.iterrows():
            if int(r["hours_ahead"]) in forecasting.HORIZONS:
                database.save_forecast(r["forecast_time"].strftime("%Y-%m-%d %H:%M:%S"),
                                       int(r["hours_ahead"]), scenario, float(r["linear_power"]),
                                       float(r["forest_power"]))
        st.session_state.forecast = (f, scenario, horizon)
    if "forecast" in st.session_state:
        f, scen, hz = st.session_state.forecast
        st.subheader(f"Scenario: {scen}")
        sel = f[f["hours_ahead"] <= hz]
        show = f[f["hours_ahead"].isin([h for h in forecasting.HORIZONS if h <= hz])]
        table = pd.DataFrame({"Forecast time": show["forecast_time"].dt.strftime("%Y-%m-%d %H:%M"),
                              "Hours ahead": show["hours_ahead"],
                              "Linear Regression (MW)": show["linear_power"].round(2),
                              "Random Forest (MW)": show["forest_power"].round(2),
                              "Difference (MW)": (show["linear_power"] - show["forest_power"]).abs().round(2)})
        st.dataframe(table, hide_index=True)
        fig, ax = plt.subplots(figsize=(8, 3.4))
        ax.plot(sel["hours_ahead"], sel["linear_power"], color=PURPLE, marker="o", label="Linear Regression")
        ax.plot(sel["hours_ahead"], sel["forest_power"], color="#17131F", marker="s", label="Random Forest")
        ax.set_xlabel("Hours ahead"); ax.set_ylabel("Estimated power (MW)")
        ax.set_title("Scenario-based future generation estimate", color=DARK); ax.grid(alpha=0.25); ax.legend()
        fig.tight_layout(); st.pyplot(fig); plt.close(fig)
        note("Scenario-based future estimates, NOT verified future plant measurements.")
    with st.expander("Saved forecast records (SQLite)"):
        st.dataframe(database.get_forecasts(30), hide_index=True)


def page_health():
    header("Turbine Health", "Illustrative rule-based score (0–100)")
    note("An academic monitoring score using transparent rules. It is <b>not</b> a certified engineering diagnosis.")
    latest = latest_or_none()
    if not latest:
        empty_state(); return
    with st.expander("Scoring weights (configurable)"):
        cols = st.columns(5)
        for i, k in enumerate(turbine_health.DEFAULT_WEIGHTS):
            st.session_state.weights[k] = cols[i].slider(k.title(), 0.0, 1.0, float(st.session_state.weights[k]), 0.05)
        st.caption("Weights are normalised so they sum to 1. New readings use these weights.")
    h = turbine_health.calculate_health(latest, st.session_state.weights)
    c = st.columns(3)
    with c[0]: card("Health score", f"{h['score']}/100")
    with c[1]: card("Category", h["category"])
    with c[2]: card("Reading time", latest["timestamp"][5:16])
    st.progress(int(h["score"]))
    st.subheader("Parameter-wise status")
    st.dataframe(pd.DataFrame(h["parameters"]), hide_index=True)
    st.subheader("Reasons for score reduction")
    if h["reasons"]:
        for r in h["reasons"]:
            st.write("• " + r)
    else:
        st.success("No reductions: all parameters are inside the ideal ranges.")
    if h["checks"]:
        st.subheader("Suggested checks")
        for ch in dict.fromkeys(h["checks"]):
            st.write("• " + ch)
    hist = database.get_health(limit=100)
    if len(hist) > 1:
        hist = hist.iloc[::-1]
        line_plot(hist, "timestamp", ["health_score"], "Stored health score history", "score")


def page_anomaly():
    header("Anomaly Detection", "Isolation Forest + simple safety rules")
    note("An anomaly means an <b>unusual reading</b>. It does not automatically mean equipment failure.")
    st.subheader("Controlled abnormal test (for demonstration)")
    c = st.columns([2, 1, 1])
    kind = c[0].selectbox("Type of abnormal reading", sim.ABNORMAL_KINDS)
    if c[1].button("Inject abnormal reading"):
        st.session_state.last_anomaly = pipeline.generate_and_process(kind, st.session_state.thresholds, st.session_state.weights)
    if c[2].button("Generate normal reading"):
        st.session_state.last_anomaly = pipeline.generate_and_process(None, st.session_state.thresholds, st.session_state.weights)
    res = st.session_state.get("last_anomaly")
    if res:
        a = res["anomaly"]; r = res["reading"]
        status_color = "#C0392B" if a["status"] == "Anomaly" else "#2E9E5B"
        st.markdown(f"### Status: <span style='color:{status_color}'>{a['status']}</span>", unsafe_allow_html=True)
        st.write(f"**Timestamp:** {r['timestamp']}  |  **Anomaly score:** {a['score']:.3f} "
                 "(lower = more unusual; below 0 = flagged by the forest)")
        st.write("**Affected sensor values:** " + (", ".join(a["affected"]) or "none"))
        st.write("**Explanation:** " + a["explanation"])
        st.dataframe(pd.DataFrame([r]), hide_index=True)
    st.subheader("Detection history")
    hist = database.get_anomalies(limit=200)
    if hist.empty:
        st.info("No detections yet.")
        return
    c = st.columns(3)
    with c[0]: card("Readings checked", len(hist))
    with c[1]: card("Anomalies", int((hist.status == "Anomaly").sum()))
    with c[2]: card("Latest status", hist.status.iloc[0])
    only = st.checkbox("Show only anomalies", value=True)
    show = hist[hist.status == "Anomaly"] if only else hist
    st.dataframe(show.drop(columns=["id"]), hide_index=True)
    hh = hist.iloc[::-1]
    fig, ax = plt.subplots(figsize=(8, 3))
    ax.plot(range(len(hh)), hh["anomaly_score"], color=PURPLE)
    ax.axhline(0, color="#C0392B", ls="--", label="0 = decision boundary")
    ax.scatter([i for i, s in enumerate(hh["status"]) if s == "Anomaly"],
               [v for v, s in zip(hh["anomaly_score"], hh["status"]) if s == "Anomaly"], color="#C0392B", zorder=3)
    ax.set_title("Anomaly score history", color=DARK); ax.legend(); ax.grid(alpha=0.25)
    fig.tight_layout(); st.pyplot(fig); plt.close(fig)


def page_history():
    header("Historical Data", "Readings stored permanently in SQLite")
    c = st.columns(2)
    start = c[0].date_input("From", date.today() - timedelta(days=7))
    end = c[1].date_input("To", date.today())
    df = database.get_readings(str(start), str(end))
    if df.empty:
        st.info("No readings in this date range."); return
    st.write(f"**{len(df)}** readings found.")
    st.dataframe(df, hide_index=True)
    param = st.selectbox("Graph parameter", ["simulated_power", "water_flow", "water_level",
                                             "hydraulic_head", "temperature", "rainfall", "turbine_efficiency"])
    line_plot(df, "timestamp", [param], f"{param.replace('_', ' ').title()} over time", param)
    st.download_button("Download CSV", df.to_csv(index=False), f"hydro_readings_{start}_{end}.csv", "text/csv")


def page_reservoir():
    header("Reservoir Analysis", "Water conditions and their relationship with power")
    src = st.radio("Data source", ["Stored sensor readings (SQLite)", "Training dataset (CSV, 6000 rows)"], horizontal=True)
    if src.startswith("Stored"):
        df = database.get_readings(limit=500)
        if len(df) < 5:
            empty_state("Need at least 5 stored readings for analysis."); return
    else:
        df = cached_dataset().tail(500).reset_index(drop=True)
    a, b = st.columns(2)
    with a: line_plot(df, "timestamp", ["water_level"], "Water level trend", "m")
    with b: line_plot(df, "timestamp", ["water_flow"], "Water flow trend", "m³/s", ["#5DA9E9"])
    a, b = st.columns(2)
    with a:
        fig, ax = plt.subplots(figsize=(8, 3.2))
        ax.bar(range(len(df)), df["rainfall"], color="#5DA9E9")
        ax.set_title("Rainfall (mm)", color=DARK); ax.grid(alpha=0.25); fig.tight_layout()
        st.pyplot(fig); plt.close(fig)
    with b: line_plot(df, "timestamp", ["hydraulic_head"], "Hydraulic head trend", "m", ["#2E9E5B"])
    st.subheader("Relationship with power generation")
    a, b = st.columns(2)
    for col, ax_title, holder in [("water_flow", "Water flow vs power", a), ("hydraulic_head", "Hydraulic head vs power", b)]:
        with holder:
            fig, ax = plt.subplots(figsize=(6, 3.4))
            ax.scatter(df[col], df["simulated_power"], s=10, color=PURPLE, alpha=0.6)
            ax.set_xlabel(col); ax.set_ylabel("Simulated power (MW)"); ax.set_title(ax_title, color=DARK)
            ax.grid(alpha=0.25); fig.tight_layout(); st.pyplot(fig); plt.close(fig)
    corr = df[["water_flow", "water_level", "hydraulic_head", "rainfall", "simulated_power"]].corr()["simulated_power"].drop("simulated_power")
    st.write("**Correlation with simulated power** (+1 = rise together, 0 = no linear relationship):")
    st.dataframe(corr.round(3).rename("correlation").to_frame())


def page_comparison():
    header("Model Comparison", "Linear Regression vs Random Forest (same 20% test rows)")
    ev = cached_evaluation()
    m = ev["metrics"]
    table = pd.DataFrame(m).T.rename(columns={"EstAccuracy": "Est. Regression Accuracy (%)"}).round(4)
    st.dataframe(table)
    st.caption(f"Test rows: {ev['n_test']} (80:20 split, random_state=42). Values are calculated from real test predictions.")
    names = list(m.keys())
    cols = st.columns(4)
    for col, key in zip(cols, ["MAE", "MSE", "RMSE", "R2"]):
        fig, ax = plt.subplots(figsize=(3.2, 3))
        ax.bar(names, [m[n][key] for n in names], color=[PURPLE, DARK])
        ax.set_title(key, color=DARK); ax.set_xticks([0, 1]); ax.set_xticklabels(["Linear", "Forest"])
        for i, n in enumerate(names):
            ax.text(i, m[n][key], f"{m[n][key]:.3f}", ha="center", va="bottom", fontsize=8)
        fig.tight_layout(); col.pyplot(fig); plt.close(fig)
    y = ev["y_test"]
    a, b = st.columns(2)
    with a:
        fig, ax = plt.subplots(figsize=(6, 4.2))
        for n, c in zip(names, [PURPLE, "#17131F"]):
            ax.scatter(y, ev["predictions"][n], s=7, alpha=0.5, color=c, label=n)
        ax.plot([y.min(), y.max()], [y.min(), y.max()], "r--", label="Perfect prediction")
        ax.set_xlabel("Actual (simulated) MW"); ax.set_ylabel("Predicted MW"); ax.legend()
        ax.set_title("Actual vs predicted", color=DARK); fig.tight_layout(); st.pyplot(fig); plt.close(fig)
    with b:
        fig, ax = plt.subplots(figsize=(6, 4.2))
        for n, c in zip(names, [PURPLE, "#17131F"]):
            ax.scatter(ev["predictions"][n], y - ev["predictions"][n], s=7, alpha=0.5, color=c, label=n)
        ax.axhline(0, color="r", ls="--"); ax.set_xlabel("Predicted MW"); ax.set_ylabel("Error (actual − predicted)")
        ax.legend(); ax.set_title("Residual / error plot", color=DARK); fig.tight_layout(); st.pyplot(fig); plt.close(fig)
    imp = pd.Series(ev["importance"]).sort_values()
    fig, ax = plt.subplots(figsize=(8, 3.4))
    ax.barh(imp.index, imp.values, color=PURPLE); ax.set_title("Random Forest feature importance", color=DARK)
    fig.tight_layout(); st.pyplot(fig); plt.close(fig)
    st.subheader("Estimated Regression Accuracy (%) – Normalized MAE")
    c = st.columns(2)
    for col, n in zip(c, names):
        with col: card(n, f"{m[n]['EstAccuracy']:.2f} %")
    note("Project-defined estimate = 100 × (1 − MAE / (max test target − min test target)), clipped to 0–100. "
         "It is <b>not</b> classification accuracy and <b>not</b> R². Because the data is synthetic and "
         "created from the same equation the models learn, scores are high and do not show real-plant accuracy.")


def page_confidence():
    header("Prediction Confidence", "Estimated lower and upper prediction range")
    latest = latest_or_none()
    model_name = st.selectbox("Model", MODEL_NAMES)
    use = st.radio("Input", ["Latest sensor reading", "Manual input"], horizontal=True)
    if use == "Latest sensor reading":
        if not latest:
            empty_state(); reading = None
        else:
            reading = latest
    else:
        reading = manual_inputs(latest or sim.default_state(), "pc_")
    if reading is not None:
        r = pconf.predict_with_interval(reading, model_name)
        c = st.columns(4)
        with c[0]: card("Model", model_name)
        with c[1]: card("Predicted power", f"{r['prediction']:.2f} MW")
        with c[2]: card("Lower estimate", f"{r['lower']:.2f} MW")
        with c[3]: card("Upper estimate", f"{r['upper']:.2f} MW")
        fig, ax = plt.subplots(figsize=(8, 1.9))
        ax.hlines(0, r["lower"], r["upper"], color=PURPLE, lw=10, alpha=0.5)
        ax.plot([r["prediction"]], [0], "o", color="#17131F", ms=10)
        ax.set_yticks([]); ax.set_xlabel("MW"); ax.set_title("Prediction (dot) and estimated range (bar)", color=DARK)
        fig.tight_layout(); st.pyplot(fig); plt.close(fig)
    st.subheader("How the range is calculated")
    note(pconf.METHOD_TEXT[model_name])
    v = cached_validation(model_name)
    st.subheader("Validation on held-out synthetic test data")
    c = st.columns(3)
    with c[0]: card("Test rows inside range", f"{v['coverage_percent']:.1f} %")
    with c[1]: card("Average range width", f"{v['average_width']:.2f} MW")
    with c[2]: card("Test rows", v["n_test"])
    idx = np.argsort(v["mean"])[::6][:120]
    fig, ax = plt.subplots(figsize=(8, 3.4))
    x = np.arange(len(idx))
    ax.fill_between(x, v["lower"][idx], v["upper"][idx], color=PURPLE, alpha=0.3, label="Estimated range")
    ax.plot(x, v["mean"][idx], color=DARK, label="Prediction")
    ax.scatter(x, v["actual"][idx], s=8, color="#C0392B", label="Actual (simulated)")
    ax.set_title(f"{model_name}: test rows sorted by prediction", color=DARK); ax.legend(); ax.grid(alpha=0.25)
    fig.tight_layout(); st.pyplot(fig); plt.close(fig)
    note(pconf.LIMITATIONS)


def page_alerts():
    header("Alert Monitoring", "Threshold-based alerts (academic demonstration thresholds)")
    note("Thresholds are demonstration values, <b>not</b> certified plant safety limits. "
         "The 10% predicted-vs-actual deviation check is only used when an independent actual power "
         "measurement exists; simulator power is not an independent measurement, so it is not applied here.")
    al = database.get_alerts()
    c = st.columns(5)
    with c[0]: card("Total alerts", len(al))
    with c[1]: card("Warning", int((al.severity == "Warning").sum()) if not al.empty else 0)
    with c[2]: card("Critical", int((al.severity == "Critical").sum()) if not al.empty else 0)
    with c[3]: card("Acknowledged", int((al.acknowledged == 1).sum()) if not al.empty else 0)
    with c[4]: card("Unacknowledged", int((al.acknowledged == 0).sum()) if not al.empty else 0)

    with st.expander("Configure thresholds"):
        th = st.session_state.thresholds
        for key, vals in th.items():
            if key == "power_deviation_percent":
                th[key] = st.number_input("Power deviation % (only with independent actual measurement)", 1.0, 50.0, float(vals))
                continue
            st.write(f"**{alert_manager.NAMES[key]}** ({alert_manager.UNITS[key]})")
            cols = st.columns(len(vals))
            for i, (k, v) in enumerate(vals.items()):
                th[key][k] = cols[i].number_input(k, value=float(v), key=f"th_{key}_{k}")
        if st.button("Reset to defaults"):
            import copy
            st.session_state.thresholds = copy.deepcopy(alert_manager.DEFAULT_THRESHOLDS); st.rerun()

    if al.empty:
        st.info("No alerts yet. Generate readings (or an abnormal test reading) to create alerts."); return
    if st.button("Acknowledge all"):
        database.acknowledge_all_alerts(); st.rerun()
    show_ack = st.checkbox("Show acknowledged alerts too", value=False)
    view = al if show_ack else al[al.acknowledged == 0]
    st.write(f"Showing {min(len(view), 30)} of {len(view)} alerts")
    for _, r in view.head(30).iterrows():
        c = st.columns([2, 1.4, 1.2, 5, 1.3])
        c[0].write(r["timestamp"])
        c[1].write(r["parameter"])
        c[2].markdown(f"<span class='sev-{r['severity']}'>{r['severity']}</span>", unsafe_allow_html=True)
        c[3].write(r["message"])
        if r["acknowledged"]:
            c[4].write("✔ Acknowledged")
        elif c[4].button("Acknowledge", key=f"ack_{r['id']}"):
            database.acknowledge_alert(r["id"]); st.rerun()


def page_reports():
    header("Reports", "Generate a PDF report and download CSV data")
    c = st.columns(2)
    start = c[0].date_input("From", date.today() - timedelta(days=7), key="rs")
    end = c[1].date_input("To", date.today(), key="re")
    if start > end:
        st.error("The start date must be before the end date."); return
    csv = report_generator.readings_csv(str(start), str(end))
    if csv is None:
        st.info("No readings in this date range. Generate readings first or change the dates."); return
    if st.button("Generate PDF report"):
        with st.spinner("Building PDF..."):
            pdf = report_generator.build_pdf(str(start), str(end))
        os.makedirs(os.path.join(BASE_DIR, "reports"), exist_ok=True)
        path = os.path.join(BASE_DIR, "reports", f"hydromonitor_report_{start}_{end}.pdf")
        with open(path, "wb") as fh:
            fh.write(pdf)
        st.session_state.pdf = (pdf, f"hydromonitor_report_{start}_{end}.pdf")
        st.success("PDF created and saved in the 'reports' folder.")
    if "pdf" in st.session_state:
        st.download_button("Download PDF report", st.session_state.pdf[0], st.session_state.pdf[1], "application/pdf")
    st.download_button("Download CSV (readings + predictions)", csv, f"hydromonitor_data_{start}_{end}.csv", "text/csv")


# ------------------------------------------------------------------ navigation
PAGES = {
    "Dashboard": page_dashboard, "Digital Twin": page_twin, "Sensor Monitoring": page_sensors,
    "Power Prediction": page_prediction, "Future Forecast": page_forecast,
    "Turbine Health": page_health, "Anomaly Detection": page_anomaly,
    "Historical Data": page_history, "Reservoir Analysis": page_reservoir,
    "Model Comparison": page_comparison, "Prediction Confidence": page_confidence,
    "Alert Monitoring": page_alerts, "Reports": page_reports,
}

logo = os.path.join(BASE_DIR, "assets", "logo.png")
with st.sidebar:
    if os.path.exists(logo):
        st.image(logo, width=70)
    st.markdown("## HydroMonitor")
    st.caption("ML-Based Hydropower Plant Monitoring")
    choice = st.radio("Navigation", list(PAGES.keys()), label_visibility="collapsed")
    st.markdown("---")
    st.caption("SIMULATED SENSOR DATA – NO PHYSICAL SENSORS CONNECTED")

PAGES[choice]()
