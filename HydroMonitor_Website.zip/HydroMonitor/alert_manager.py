# alert_manager.py
# PURPOSE: Check each reading against configurable thresholds and create alerts.
# Thresholds are ACADEMIC DEMONSTRATION values, not certified plant safety limits.

import math
import database

# For "range" parameters: warning_low/high and critical_low/high. Edit in the app too.
DEFAULT_THRESHOLDS = {
    "water_flow":         {"warn_low": 30, "warn_high": 105, "crit_low": 15, "crit_high": 120},
    "water_level":        {"warn_low": 142, "warn_high": 178, "crit_low": 138, "crit_high": 182},
    "temperature":        {"warn_high": 65, "crit_high": 80},
    "hydraulic_head":     {"warn_low": 44, "warn_high": 75, "crit_low": 40, "crit_high": 80},
    "turbine_efficiency": {"warn_low": 85, "crit_low": 75},
    "power_deviation_percent": 10,
}
UNITS = {"water_flow": "m3/s", "water_level": "m", "temperature": "°C",
         "hydraulic_head": "m", "turbine_efficiency": "%"}
NAMES = {"water_flow": "Water flow", "water_level": "Water level", "temperature": "Temperature",
         "hydraulic_head": "Hydraulic head", "turbine_efficiency": "Turbine efficiency"}


def _valid(value):
    try:
        return value is not None and not math.isnan(float(value))
    except (TypeError, ValueError):
        return False


def check_reading(reading, anomaly_result=None, thresholds=None):
    """Return a list of alerts: [{parameter, message, severity}]. Empty list = all Normal."""
    th = thresholds or DEFAULT_THRESHOLDS
    alerts = []

    # 1) invalid or missing readings
    for key in NAMES:
        if not _valid(reading.get(key)) or float(reading[key]) < 0:
            alerts.append({"parameter": NAMES[key], "severity": "Critical",
                           "message": f"{NAMES[key]} reading is missing or invalid."})
    if alerts:
        return alerts   # no point comparing thresholds with bad numbers

    running = reading.get("turbine_status") == "Running"
    if not running:
        alerts.append({"parameter": "Turbine status", "severity": "Warning",
                       "message": "Turbine is stopped; power generation is 0 MW."})

    # 2) range checks (skip flow/efficiency limits while the turbine is stopped)
    for key, t in th.items():
        if key not in NAMES:
            continue
        if not running and key in ("water_flow", "turbine_efficiency", "temperature"):
            continue
        v, unit = float(reading[key]), UNITS[key]
        sev, limit, side = None, None, None
        if "crit_high" in t and v > t["crit_high"]:
            sev, limit, side = "Critical", t["crit_high"], "above"
        elif "crit_low" in t and v < t["crit_low"]:
            sev, limit, side = "Critical", t["crit_low"], "below"
        elif "warn_high" in t and v > t["warn_high"]:
            sev, limit, side = "Warning", t["warn_high"], "above"
        elif "warn_low" in t and v < t["warn_low"]:
            sev, limit, side = "Warning", t["warn_low"], "below"
        if sev:
            alerts.append({"parameter": NAMES[key], "severity": sev,
                           "message": f"{NAMES[key]} is {v:.1f} {unit}, {side} the {sev.lower()} "
                                      f"demo threshold of {limit} {unit}."})

    # 3) anomaly detected by Isolation Forest
    if anomaly_result and anomaly_result.get("status") == "Anomaly":
        alerts.append({"parameter": "Anomaly detection", "severity": "Warning",
                       "message": "Anomaly detected: " + anomaly_result["explanation"][:200]})
    return alerts


def power_deviation(predicted, actual_independent, threshold_percent=10):
    """Deviation check. ONLY valid when an independent actual measurement exists.
    Returns None if actual is missing/zero (cannot divide safely)."""
    if not _valid(actual_independent) or not _valid(predicted) or float(actual_independent) == 0:
        return None
    pct = abs(float(predicted) - float(actual_independent)) / abs(float(actual_independent)) * 100
    return {"deviation_percent": pct, "exceeds": pct > threshold_percent}


def save_alerts(reading_id, alerts, timestamp=None):
    for a in alerts:
        database.save_alert(reading_id, a["parameter"], a["message"], a["severity"], timestamp)
    return len(alerts)
