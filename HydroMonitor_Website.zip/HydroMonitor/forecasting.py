# forecasting.py
# PURPOSE: Scenario-based estimates of FUTURE power generation (1, 3, 6, 24 hours).
# IMPORTANT: Our models are NOT time-series models. They predict power from sensor
# VALUES. So we first build assumed future sensor values (a "scenario") from recent
# readings, then ask the trained models what power those values would give.
# The results are scenario estimates, NOT verified future plant measurements.

import numpy as np
import pandas as pd
from datetime import datetime, timedelta

from prediction import load_models
from train_model import prepare_features
from sensor_simulator import efficiency_from_flow, temperature_from_flow, head_from_level

HORIZONS = [1, 3, 6, 24]

# flow_change = % change of flow by the end of 24 h; level_change = metres; rain = mm per hour
SCENARIOS = {
    "Steady (recent average continues)": {"flow_change": 0.0, "level_change": 0.0, "rain": 0.0},
    "Rising inflow (heavy rain)": {"flow_change": 0.25, "level_change": 4.0, "rain": 8.0},
    "Dry spell (falling inflow)": {"flow_change": -0.25, "level_change": -5.0, "rain": 0.0},
}


def build_future_features(recent_df, scenario_name, now=None):
    """Create 24 hourly future feature rows from the recent readings + scenario."""
    sc = SCENARIOS[scenario_name]
    run = recent_df[recent_df["turbine_status"] == "Running"]
    base = run if len(run) else recent_df
    base_flow = float(base["water_flow"].mean())
    base_level = float(base["water_level"].mean())
    now = now or datetime.now()

    rows = []
    for h in range(1, 25):
        frac = h / 24.0
        t = now + timedelta(hours=h)
        flow = base_flow * (1 + sc["flow_change"] * frac) + 3 * np.sin(2 * np.pi * t.hour / 24)
        flow = float(np.clip(flow, 15, 125))
        level = float(np.clip(base_level + sc["level_change"] * frac, 135, 185))
        rows.append({"forecast_time": t, "hours_ahead": h,
                     "water_flow": flow, "water_level": level,
                     "hydraulic_head": float(head_from_level(level)),
                     "temperature": float(temperature_from_flow(flow)),
                     "rainfall": sc["rain"],
                     "turbine_efficiency": float(efficiency_from_flow(flow)),
                     "turbine_status": "Running"})
    return pd.DataFrame(rows)


def forecast(recent_df, scenario_name, now=None):
    """Return a 24-row table with Linear Regression and Random Forest estimates (MW)."""
    future = build_future_features(recent_df, scenario_name, now)
    X = prepare_features(future)
    models = load_models()
    future["linear_power"] = np.clip(models["Linear Regression"].predict(X), 0, None)
    future["forest_power"] = np.clip(models["Random Forest"].predict(X), 0, None)
    return future


EXPLANATION = (
    "The regression models do not look at time. They answer: 'if flow, level, head, "
    "temperature... have THESE values, how much power results?'. To estimate the future we "
    "(1) take the average of recent simulator readings, (2) apply a clearly defined scenario "
    "(for example +25% inflow), (3) feed those assumed future values to both trained models. "
    "So the output is a scenario-based estimate, not a verified future measurement."
)
